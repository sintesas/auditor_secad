<?php $__env->startSection('title'); ?>
Ver Costos H/H
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('card-content'); ?>
<?php $__env->startSection('card-title'); ?>
<?php echo e(Breadcrumbs::render('costoshh')); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('card-content'); ?>


<div class="col-lg-12">
	<div class="table-responsive">
		<table id="datatable1" class="table table-striped table-hover">
			<thead>
				<tr>
					<th><b>Abreviatura</b></th>
					<th><b>Grado</b></th>
					<th><b>Salario</b></th>
					<th><b>Costos H/H</b></th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $costos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $costo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($permiso->consultar == 1): ?>
				<tr>
					<td><?php echo e($costo->Abreviatura); ?></td>
					<td><?php echo e($costo->NombreGrado); ?></td>
					<td>$ <?php echo e($costo->Salario); ?></td>
					<td>$ <?php echo e($costo->hh); ?></td>
				</tr>
				<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		
	</div><!--end .table-responsive -->
</div><!--end .col -->

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>

<script>
	$(document).ready(function(){
		$('#datatable1').DataTable();
	});
</script>

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/gestionRecursos/recursoHumano/informacionPersonal/ver_costoshh.blade.php ENDPATH**/ ?>