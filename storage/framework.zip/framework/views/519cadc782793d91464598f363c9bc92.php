<?php $__env->startSection('title'); ?>
	Informe Ofertas Sector Aeronautico
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>

		<?php $__env->startSection('form-tag'); ?>

	    <?php echo Form::model($cantidadesTotalPais); ?>

        <?php echo e(csrf_field()); ?>


		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-title'); ?>
			
            <?php echo e(Breadcrumbs::render('informe_capacidad_total_pais')); ?>

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>       

		<div class="card-body floating-label">
		<!-- BEGIN BASE-->
		<div id="">

			<!-- BEGIN OFFCANVAS LEFT -->
			<div class="offcanvas">
			</div><!--end .offcanvas-->
			<!-- END OFFCANVAS LEFT -->

			<!-- BEGIN CONTENT-->
            <div id="">
                <section>                   
                    <div class="section-body">
                      

			<div class="row encabezadoPlanInspeccion">

                    <!-- titulo Formulario -->
                    <div class="col-xs-12 text-center">
                        <h3>OFICINA CERTIFICACION AERONAUTICA DE LA DEFENSA - SECAD</h3>
                        <div>
                            <h4>Listado de empresas Colombianas Capacidad Aeronáutica</h4>
                        </div>                        
                   </div>                              
               </div>
<!--end .row -->
                                                
                    
                    
                        <!-- PRIMER BLOQUE DE INFOMACION -->
                        <div class="row">                            
                            <!-- Proceso -->
                            <div class="col-xs-12 fondoAzulClaro">
                                <div class="col-xs-8 " >
                                    <div class="col-xs-12">
                                        <div class="col-xs-4 azul175">
                                        Capacidad u Oferta:
                                        </div>
                                        <div class="col-xs-8">
                                        ...
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xs-4">
                                     <div class="col-xs-12">
                                        <div class="col-xs-4 azul175">
                                        Total:
                                        </div>
                                        <div class="col-xs-8">
                                        ...
                                        </div>
                                    </div>
                                </div>   
                            </div>
                            <!-- FIN Div-->                       
                            <!-- Responsable Proceso -->
                            <div class="col-xs-12 filaFormulario table-fixed">
                                <table class="table  table-x ">
                                  <tr class="fondoAzulOscuro blanco">
                                        <th class="th-x"> Nombre Empresa</th>
                                      
                                        <th class="th-x" >  Nit</th>
                                      
                                        <th class="th-x" > Ciudad </th>

                                        <th class="th-x" > Teléfono </th>
                                  </tr>
                                  <?php if($permiso->consultar == 1): ?>
                                   <?php if(count($cantidadesTotalPais) != 1): ?>
                                   <?php $ofertaOld = 0;?>
                                   <?php $__currentLoopData = $cantidadesTotalPais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cantidadesTotalPaisR): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                 
                                   <?php $oferta = $cantidadesTotalPaisR->IdOfertaComercial;?> 
                                   <?php if((($oferta) != ($ofertaOld)) || (($ofertaOld) === 0)): ?>
                                   <tr class="line-bt">  
                                      <th><?php echo e($cantidadesTotalPaisR->OfertaComercial); ?></th> 
                                      <th></th> 
                                      <th></th>    
                                      <th></th>                                                                       
                                   </tr>
                                   <tr class="line-a">  
                                        <th class=""><?php echo e($cantidadesTotalPaisR->NombreEmpresa); ?></th>                                       
                                        <th class=""><?php echo e($cantidadesTotalPaisR->Nit); ?></th>
                                        <th class=""><?php echo e($cantidadesTotalPaisR->Ciudad); ?></th>
                                        <th class=""><?php echo e($cantidadesTotalPaisR->Telefono); ?></th>
                                    </tr>
                                   <?php else: ?>
                                    <tr class="line-a">  
                                        <th class=""><?php echo e($cantidadesTotalPaisR->NombreEmpresa); ?></th>                                       
                                        <th class=""><?php echo e($cantidadesTotalPaisR->Nit); ?></th>
                                        <th class=""><?php echo e($cantidadesTotalPaisR->Ciudad); ?></th>
                                        <th class=""><?php echo e($cantidadesTotalPaisR->Telefono); ?></th>
                                    </tr>
                                   <?php endif; ?>     
                                   <?php $ofertaOld = $cantidadesTotalPaisR->IdOfertaComercial;?> 
                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   <?php endif; ?>
                                   <?php endif; ?>
                                </table>
                            </div>
                        </div><!--end .row -->
                        <div class="col-xs-12">                            
                            <div class="col-xs-6 azul175">
                                <p>Total Capacidades x Empresas:</p>
                                <p>...</p>
                            </div>
                        
                        </div>                        
                    </div><!--end .section-body -->                   
                </section>
            </div><!--end #content-->
            <!-- END CONTENT -->
            <?php if($permiso->consultar == 1): ?>
             <a href="<?php echo e(route('informecapacidadtotalpais.create')); ?>" style="width: 150px; font-style: Roboto;" class="btn btn-primary btn-block editbutton pull-left"><span class="fa fa-download">    Descargar PDF</span></a>
             <?php endif; ?>
        </div>
    </div>

		<?php echo Form::close(); ?>

		<?php $__env->stopSection(); ?>

	<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/fomento/sectorAeronautico/informes/visual_informe_capacidad_total_pais.blade.php ENDPATH**/ ?>