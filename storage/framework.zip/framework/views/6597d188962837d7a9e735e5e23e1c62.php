<body style="background-color: white;">

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('card-content'); ?>

<?php $__env->startSection('form-tag'); ?>

<?php echo Form::model($informeHistorialPrograma); ?>

<?php echo e(csrf_field()); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('card-content'); ?>

<div class="">
    <!-- BEGIN BASE-->
    <div id="">

        <!-- BEGIN OFFCANVAS LEFT -->
        <div class="offcanvas">
        </div><!--end .offcanvas-->
        <!-- END OFFCANVAS LEFT -->

        <!-- BEGIN CONTENT-->
        <div id="">
            <section style="padding: 10px !important;">
              <div class="">
                <div class="row encabezadoPlanInspeccion">

                    <!-- titulo Formulario -->
                    <div class="col-xs-12">
                        <h3>OFICINA CERTIFICACION AERONAUTICA DE LA DEFENSA - SECAD</h3>
                        <div class="col-xs-5">
                            <h4>FICHA DE CONTROL DE SEGUIMIENTO HISTORICO</h4>
                        </div>
                   </div>
                    <div class="col-xs-12">
                        <div class="col-xs-5">
                            <h4><strong> Programa </strong> <?php echo e($informeHistorialPrograma[0]->Proyecto); ?></h4>
                        </div>
                        <div class="col-xs-3">
                            <h5> <strong> No Control </strong> <?php echo e($informeHistorialPrograma[0]->Consecutivo); ?></h5>
                       </div>
                       <div class="col-xs-4">
                            <h5> <strong> Tipo Programa </strong><?php echo e($informeHistorialPrograma[0]->TipoPrograma); ?> </h5>
                       </div>
                   </div>
               </div>
               

            <!-- Segundo BLOQUE DE INFOMACION -->
            <div class="row">                            
                <!-- Proceso -->
                <div class="col-xs-12 filaFormulario table-fixed">
                    <table class="table  table-x">
                        <tr class="line-b">
                            

                            <th class="th-x" > N. </th>

                            <th class="th-x" colspan="5"> Actividad </th>

                           

                            <th class="th-x" > Responsable</th>                        
                        </tr>
                        <tr class="line-b">
                            

                            <th class="th-x" ></th>

                            <th class="th-x" > Situacion </th>

                            <th class="th-x" style="width: 75px;">Fecha</th>

                            <th class="th-x" > Observaciones </th>

                            <th class="th-x"> Evidencias</th>

                            <th class="th-x"> HH </th>

                            <th class="th-x" ></th>                        
                        </tr>
                        
                        <?php if(count($informeHistorialPrograma) != 0): ?>
                            <?php $idactividad = 0; $cntactividad = 1?> 
                            <?php $__currentLoopData = $informeHistorialPrograma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $informeHistorialProgramaR): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                               <?php if(($idactividad) == ($informeHistorialProgramaR->IdActividad) && ($idactividad) != 0): ?>
                                <tr class="line-ct">  
                                    <td class="lighterFont"></td>
                                    <td class="lighterFont"><?php echo e($informeHistorialProgramaR->Situacion); ?></td>
                                    <td class="lighterFont"><?php echo e($informeHistorialProgramaR->Fecha); ?></td>
                                    <td class="lighterFont"><?php echo e($informeHistorialProgramaR->Evidencias); ?></td>
                                    <td class="lighterFont"><a href="<?php echo e(asset($informeHistorialProgramaR->Documentos)); ?>" target="_blank">Descargar</a></td>
                                    <td class="lighterFont"><?php echo e($informeHistorialProgramaR->Horas); ?></td>
                                    <td class="lighterFont"></td>
                                </tr>                        
                                <?php else: ?>
                                <tr class="line-bt">  
                                    <td class="lighterFont"><?php echo e($cntactividad); ?></td>
                                    <td class="lighterFont" colspan="5"><?php echo e($informeHistorialProgramaR->Actividad); ?></td>
                                    <td class="lighterFont"><?php echo e($informeHistorialProgramaR->Responsable); ?></td>
                                </tr>
                                <?php if($informeHistorialProgramaR->IdListaSeguimiento != null): ?>
                                 <tr class="">  
                                    <td class="lighterFont"></td>
                                    <td class="lighterFont"><?php echo e($informeHistorialProgramaR->Situacion); ?></td>
                                    <td class="lighterFont"><?php echo e($informeHistorialProgramaR->Fecha); ?></td>
                                    <td class="lighterFont"><?php echo e($informeHistorialProgramaR->Evidencias); ?></td>
                                    <td class="lighterFont"><a href="<?php echo e(asset($informeHistorialProgramaR->Documentos)); ?>" target="_blank">Descargar</a></td>
                                    <td class="lighterFont"><?php echo e($informeHistorialProgramaR->Horas); ?></td>
                                    <td class="lighterFont"></td>
                                </tr>
                                <?php endif; ?>
                                <?php $cntactividad = $cntactividad+1; ?> 
                                <?php $idactividad = $informeHistorialProgramaR->IdActividad; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr class="">  
                                    <td class="lighterFont"></td>
                                    <td class="lighterFont"></td>
                                    <td class="lighterFont"></td>
                                    <td class="lighterFont"></td>
                                    <td class="lighterFont">Suma Total H/H</td>
                                    <td class="lighterFont"><?php echo e($totalHoras->TotalHoras); ?></td>
                                    <td class="lighterFont"></td>
                                </tr>
                        <?php else: ?>
                            <div class="section-body">
                                <div class="text-center">
                                    <h3>No hay datos para mostrar informe</h3>
                                </div>
                            </div>
                        <?php endif; ?>
                    </table>
                </div>
                <!-- FIN Div-->
            </div><!--end .row -->                                            
        </div><!--end .section-body -->  
    </section>
</div><!--end #content-->
<!-- END CONTENT -->

</div>
</div>


<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

</body>
<?php echo $__env->make('partials.pdf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card_big', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS-PC\Desktop\SINTE DESARROLLO - 1 de Julio\Auditor Secad\auditor_secad\resources\views/certificacion/programasSECAD/informes/pdf_informe_historial_programa.blade.php ENDPATH**/ ?>