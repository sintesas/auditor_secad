<?php $__env->startSection('title'); ?>
Crear Programa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('card-content'); ?>

<?php $__env->startSection('form-tag'); ?>

<?php echo Form::open(array('route' => 'detalleprograma.store')); ?>


<?php echo e(csrf_field()); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('card-title'); ?>
<?php echo e(Breadcrumbs::render('detalleprograma')); ?>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('card-content'); ?>

<div class="card-body floating-label">

                
                
					
					<h2><b>Crear Programa</b></h2>
					<hr>
					<br><br>

                
                
                <div class="tab-content">
                	<div id="home" class="tab-pane active">
                		<div class="row">
                			<div class="col-lg-4">	
                				<div class="form-group floating-label">	
                					<input type="text" class="form-control" id="NoPrograma" name="NoPrograma" value="<?php echo e(old('NoPrograma', $consecutivo)); ?>" required>
                					<label for="NoPrograma">No Programa</label>
                				</div>
                			</div>

						<div class="col-lg-4">	
							<div class="form-group floating-label">
								<?php echo e(Form::select('IdTipoPrograma', $TipoProgramas->pluck('Tipo', 'IdTipoPrograma'), null, ['class' => 'form-control', 'required' => ''])); ?>

								<?php echo e(Form::label('IdTipoPrograma', 'Tipo')); ?>

							</div>									
						</div>
						<div class="col-lg-4">	
							<div class="form-group floating-label">
								<?php echo e(Form::select('IdAeronave', $Aeronaves->pluck('Aeronave', 'IdAeronave'), null, ['class' => 'form-control', 'required' => ''])); ?>

								<?php echo e(Form::label('IdAeronave', 'Equipo')); ?>

							</div>															
						</div>
					</div>		
					<div class="row">
						<div class="col-lg-3">	
							<div class="form-group floating-label">
								<?php echo e(Form::select('IdUnidad', $Unidades->pluck('NombreUnidad', 'IdUnidad'), null, ['class' => 'form-control', 'required' => ''])); ?>

								<?php echo e(Form::label('IdUnidad', 'Unidad')); ?>

							</div>
						</div>
						<div class="col-lg-3">	
							<div class="form-group floating-label">
								<?php echo e(Form::select('IdEmpresa', $Empresas->pluck('NombreEmpresa', 'IdEmpresa'), null, ['class' => 'form-control', 'required' => ''])); ?>

								<?php echo e(Form::label('IdEmpresa', 'Empresa')); ?>

							</div>
						</div>															
						<div class="col-lg-3">	
							<div class="form-group floating-label">
								<?php echo e(Form::select('IdEstadoPrograma', $Estados->pluck('Descripcion', 'IdEstadoPrograma'), null, ['class' => 'form-control', 'required' => ''])); ?>

								<?php echo e(Form::label('IdEstadoPrograma', 'Estado')); ?>

							</div>
						</div>
						<div class="col-lg-3">	
							<div class="form-group floating-label">
								<?php echo e(Form::select('AccionSECAD', $areas, null, ['class' => 'form-control', 'required' => ''])); ?>

								<?php echo e(Form::label('Area', 'Area')); ?>

							</div>
						</div>							
					</div>	
					<div class="row">
						<div class="col-lg-6">	
							<div class="form-group floating-label">
								<textarea name="Proyecto" id="Proyecto" class="form-control" rows="3" required=""></textarea>
								<label for="Proyecto">Descripción proyecto</label>
							</div>
						</div>	
						<div class="col-lg-6">	
							<div class="form-group floating-label">
								<?php echo e(Form::select('Alcance', $alcances, null, ['class' => 'form-control', 'required' => ''])); ?>

								<?php echo e(Form::label('Alcance', 'Alcance')); ?>

							</div>		
						</div>			
					</div>
					<div class="row">
						<div class="col-lg-3">	
							<div class="form-group floating-label">
								<?php echo e(Form::select('IdProductoServicio', $Productos->pluck('Nombre', 'IdDemandaPotencial'), null, ['class' => 'form-control', 'required' => ''])); ?>

								<?php echo e(Form::label('IdProductoServicio', 'Producto Aeronautico')); ?>

							</div>
						</div>	
						<div class="col-lg-3">	
							<div class="form-group floating-label">
								<input type="text" class="form-control" name="IdHorasTipoPrograma" id="IdHorasTipoPrograma" placeholder="" required="">
								<label for="IdHorasTipoPrograma">Horas Tipo Programa</label>
							</div>
						</div>
						<div class="col-lg-3">	
							<div class="form-group floating-label">
								<?php echo e(Form::select('IdPersonalJefePrograma', $Personal->pluck('Nombres', 'IdPersonal'), null, ['class' => 'form-control', 'required' => '', 'id' => 'IdPersonalJefePrograma'])); ?>

								<?php echo e(Form::label('IdPersonalJefePrograma', 'Jefe Programa')); ?>

							</div>
						</div>
						<div class="col-lg-3">	
							<div class="form-group floating-label">
								<?php echo e(Form::select('IdPersonalJefeSuplente', $Personal->pluck('Nombres', 'IdPersonal'), null, ['class' => 'form-control', 'required' => '', 'id' => 'IdPersonalJefeSuplente'])); ?>

								<?php echo e(Form::label('IdPersonalJefeSuplente', 'Suplente')); ?>

							</div>
						</div>
					</div>
					<div class="row">	
						<div class="col-lg-3">	
							<div class="form-group control-width-normal">
								<div class="input-group date" id="demo-date-format">
									<div class="input-group-content">
										<?php echo e(Form::text('FechaInicio', null, array('class' => 'form-control', 'required' => '' ))); ?>

										<?php echo e(Form::label('FechaInicio', 'Fecha Inicio')); ?>	
									</div>
									<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
								</div>	
							</div>	
						</div>
						<div class="col-lg-3">	
							<div class="form-group control-width-normal">
								<div class="input-group date" id="demo-date-format">
									<div class="input-group-content">
										<?php echo e(Form::text('FechaTermino', null, array('class' => 'form-control', 'required' => '' ))); ?>

										<?php echo e(Form::label('FechaTermino', 'Fecha de Certificación')); ?>	
									</div>
									<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
								</div>	
							</div>	
						</div>
						<div class="col-lg-3">	
							<div class="form-group floating-label">
								<?php echo e(Form::select('IdRespuestoModificacion', $Repuesto->pluck('Descripcion', 'IdRepuesto'), null, ['class' => 'form-control', 'required' => ''])); ?>

								<?php echo e(Form::label('IdRespuestoModificacion', 'Repuesto/Modif')); ?>

							</div>
						</div>
						<div class="col-lg-3">	
							<div class="form-group floating-label">
								<?php echo e(Form::select('IdAReferenciaPrograma', $Referencia->pluck('Descripcion', 'IdReferencia'), null, ['class' => 'form-control', 'required' => ''])); ?>

								<?php echo e(Form::label('IdAReferenciaPrograma', 'Referencia')); ?>

							</div>
						</div>	
					</div>												
					<div class="row">													
																	
						<div class="col-lg-3">	
							<div class="checkbox checkbox-styled">
								<label>
									<input type="checkbox" id="Finalizado" value="">
									<span>Finalizado</span>
								</label>
							</div>
						</div>

						<div class="col-lg-3">
							<div class="form-group floating-label">
								<?php echo e(Form::input('number', 'AnioCertificacion', null, array('class' => 'form-control' ))); ?>

								<?php echo e(Form::label('AnioCertificacion', 'Año de Certificación')); ?>

							</div>
						</div>

						<div class="col-lg-3">	
							<div class="form-group floating-label">
								<?php echo e(Form::select('IdEstadoCertificacion', $estadosc->pluck('EstadoCertificacion', 'IdEstadoCertificacion'), null, ['class' => 'form-control'])); ?>

								<?php echo e(Form::label('IdEstadoCertificacion', 'Estado de Certificación')); ?>

							</div>
						</div>

					</div>															
					<div class="row">
						<div class="col-sm-6">	
							<?php echo e(Form::submit('Guardar', ['class' => 'btn btn-info btn-block'])); ?>	
						</div>	
						<div class="col-sm-6">	
							<?php echo e(Form::button('Cancelar', ['class' => 'btn btn-danger btn-block'])); ?>	
						</div>										
					</div>
				</div>
			
			<?php echo Form::close(); ?>

			<script type="text/javascript">
				$('select').select2();
			</script>
			<script type="text/javascript">
				$('#IdPersonalJefeSuplente').change(function(event) {
	                var espP = $('#IdPersonalJefePrograma').val();
	                var espS = event.target.value;
	                if(espP == espS)
	                {
	                    toastr.warning('Seleccione otro(a) Suplente');
	                    $('#select2-chosen-14').text('');
	                    $('#IdPersonalJefeSuplente').val($("#IdPersonalJefeSuplente option:first").val());
	                }
	            });

	            $('#IdPersonalJefePrograma').change(function(event) {
	                var espS = $('#IdPersonalJefeSuplente').val();
	                var espP = event.target.value;
	                if(espP == espS)
	                {
	                    toastr.warning('Seleccione otro(a) Jefe de Programa');
	                    $('#select2-chosen-13').text('');
	                    $('#IdPersonalJefePrograma').val($("#IdPersonalJefePrograma option:first").val());
	                }
	            });
            </script>
			<?php $__env->stopSection(); ?>

			<?php $__env->stopSection(); ?>

			<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/programasSecad/controlProgramas/ver_tablas_detallePrograma.blade.php ENDPATH**/ ?>