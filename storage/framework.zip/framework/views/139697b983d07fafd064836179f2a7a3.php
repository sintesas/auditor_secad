<?php $__env->startSection('title'); ?>
	OFICINA CERTIFICACIÓN AERONAÚTICA DE LA DEFENSA - CONTROL PROGRAMAS SECAD
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addcss'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.5.2/css/buttons.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>
		<?php $__env->startSection('card-title'); ?>
		<?php echo e(Breadcrumbs::render('programa')); ?>

		<!-- Begin Modal -->
		
		
		


		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>

		<div class="total-card">
			<div class="row encabezadoPlanInspeccion">

                    <!-- titulo Formulario -->
                    <div class="col-xs-12 text-center">
                        <h3>OFICINA CERTIFICACION AERONAUTICA DE LA DEFENSA - SECAD</h3>
                        <div>
                            <h4>CONTROL DE OBSERVACIONES</h4>
                        </div>                        
                   </div>                              
               </div>

		<div class="col-lg-12" style="overflow: scroll; overflow-y:hidden;  height:100%; width:100%;" >
			<div class="table-responsive">
								<table id="example" 
				class="table table-striped table-hover " style="font-size: 10px; width:100%;" >

					<thead  style="font-size: 11px;">
						<tr>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>No Control </b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Año</b></th>
							<th style="width: 49.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Tipo</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Equipo</b></th>
							<th style="width: 50.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Unidad</b></th>
							<th style="width: 50.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Empresa</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Proyecto</b></th>
							<th style="width: 50.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Estado</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Observación</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Avance</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Responsable de Programa</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Suplente</b></th>
						</tr>
					</thead>
					
					<tbody id="data_table" name="data_table">
						 <?php $__currentLoopData = $programa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						 <?php if($permiso->consultar == 1): ?>
						<tr>
							<td style="font-size: 9px;"><?php echo e($programas->Consecutivo); ?></td>
							<td style="font-size: 9px;"><?php echo e($programas->Anio); ?></td>
							<td style="font-size: 8px;"><?php echo e($programas->Tipo); ?></td>
							<td style="font-size: 9px;"><?php echo e($programas->Equipo); ?></td>
							<td style="font-size: 9px;"><?php echo e($programas->NombreUnidad); ?></td>
							<td style="font-size: 9px;"><?php echo e($programas->NombreEmpresa); ?></td>
							<td style="font-size: 9px;"><?php echo e($programas->Proyecto); ?></td>
							<td style="font-size: 8px;"><?php echo e($programas->Estado); ?></td>
							<td style="font-size: 8px;"><?php echo e($programas->Observacion); ?></td>
							<td style="font-size: 8px;"><?php echo e(round($programas->PorcentajeAvance,2)); ?></td>
							<td style="font-size: 8px;"><?php echo e($programas->Jefe); ?></td>
							<td style="font-size: 8px;"><?php echo e($programas->ApellidosSuplente); ?> <?php echo e($programas->NombresSuplente); ?></td>
						</tr>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
					</tbody>
					<tfoot  style="font-size: 10px;">
						<tr>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>No Control</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Año</b></th>
							<th style="width: 49.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Tipo</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Equipo</b></th>
							<th style="width: 50.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Unidad</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Proyecto</b></th>
							<th style="width: 50.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Estado</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: justify;"><b>Última Observación</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Avance</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Jefe de Programa</b></th>
						</tr>
					</tfoot>
				</table>
				<h5 id="conteo"></h5>
				<input type="hidden" id="tablehtml">
				<?php if($permiso->consultar == 1): ?>
				<form id="miFormulario" action="<?php echo e(route('controlObservaciones.create')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <!-- Otros campos del formulario aquí -->
    <button type="submit" style="width: 150px; font-family: 'Roboto';" class="btn btn-primary btn-block editbutton pull-left">
        <span class="fa fa-download"></span> Generar PDF
    </button>
</form>


				
				
<?php endif; ?>
				</div><!--end .table-responsive -->
				
</form>

			</div><!--end .col -->
		</div>
<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.flash.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.print.min.js"></script>


<script>
document.getElementById("miFormulario").addEventListener("submit", function (event) {
    var estados = obtenerEstados();
	var consecutivos = obtenerConsecutivo();

    var inputEstados = document.createElement("input");
    inputEstados.type = "hidden";
    inputEstados.name = "estados";
    inputEstados.value = estados;
    this.appendChild(inputEstados);

	var inputConsecutivo = document.createElement("input");
    inputConsecutivo.type = "hidden";
    inputConsecutivo.name = "consecutivos";
    inputConsecutivo.value = consecutivos;
    this.appendChild(inputConsecutivo);

	
});

function obtenerEstados() {
    var estados = "";
    var tabla = document.getElementById("data_table");

    if (tabla.rows.length > 0) {
        for (var i = 0, row; row = tabla.rows[i]; i++) {
            var estado = row.cells[7].innerHTML;
            estados += estado + ",";
        }
        estados = estados.slice(0, -1);
    }

    return estados;
}

function obtenerConsecutivo() {
    var consecutivos = "";

    var tabla = document.getElementById("data_table");

    if (tabla.rows.length > 0) {
        for (var i = 0, row; row = tabla.rows[i]; i++) {
            var consecutivo = row.cells[0].innerHTML; // Usar una variable diferente aquí
            consecutivos += consecutivo + ","; // Agregar el valor al string
        }
        consecutivos = consecutivos.slice(0, -1);
    }

    return consecutivos;
}





</script>

  
<script type="text/javascript">

$(document).ready(function() {
		
	    $('#example').DataTable({
	    	paging: false,
		 	info:false,
		 	ordering: false,
	        initComplete: function () {
	            this.api().columns().every( function () {
	                var column = this;
	                if (true) {
		                var select = $('<br><select style="color:#000; width:90%;"><option value=""></option></select>')
	                    .appendTo( $(column.header()) )
	                    .on( 'change', function () {
	                        var val = $.fn.dataTable.util.escapeRegex(
	                            $(this).val(),
	                            filtros.push($(this).val()));

	                        column.search( val ? '^'+val+'$' : '', true, false ).draw();
	                        var pdfexport = $('#data_table').html().trim();
	                        var cantidad = ($('#datatable1').rowCount());
	                    } );
		 
		                column.data().unique().sort().each( function ( d, j ) {
		                    select.append( '<option value="'+d+'">'+d+'</option>' )
		                	});
	            	}
	           });	    		
	        }


	    });
})


</script>


		<?php $__env->stopSection(); ?>


	<?php $__env->stopSection(); ?>

<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>


<script>
	var filtros = [];
	var pdfexport;
	$(document).ready(function() {
		
	    $('#datatable1').DataTable({
	    	paging: false,
		 	info:false,
		 	ordering: false,
	        initComplete: function () {
	            this.api().columns().every( function () {
	                var column = this;
	                if (column[0] != 6 && column[0] != 7) {
		                var select = $('<br><select style="color:#000; width:90%;"><option value=""></option></select>')
	                    .appendTo( $(column.header()) )
	                    .on( 'change', function () {
	                        var val = $.fn.dataTable.util.escapeRegex(
	                            $(this).val(),
	                            filtros.push($(this).val()));

	                        column.search( val ? '^'+val+'$' : '', true, false ).draw();
	                        var pdfexport = $('#data_table').html().trim();
	                        savedataPDf(pdfexport);
	                        console.log($('#datatable1').rowCount());
	                        $('#conteo').html('Cantidad de Programas ' + $('#datatable1').rowCount());
	                    } );
		 
		                column.data().unique().sort().each( function ( d, j ) {
		                    select.append( '<option value="'+d+'">'+d+'</option>' )
		                	});
	            	}
	           });	    		
	        }


	    });

	 //    var table = $('#datatable1').DataTable();
 
		if ( ! $('#datatable1').rowCount() ) {
			$('#conteo').html('0');
		}
		else
		{
			console.log($('#datatable1').rowCount());
			$('#conteo').html('Cantidad de Programas ' + $('#datatable1').rowCount());
		}

	    // $('#datatable1').tablesorter({sortList: [[7,1], [0,1]]});

	    //ajax setup
	});



	$(window).bind("load", function() {
	   var pdfexport = $('#data_table').html().trim();
		savedataPDf(pdfexport);
	});

	$.fn.rowCount = function() {
	    return $('tr', $(this).find('tbody')).length;
	};


	function savedataPDf(pdfexport){
        $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
        });

        $.ajax({

    		type: 'post',
    		url: 'pdftodb',
    		data: {
    			'table' : pdfexport
    		},
    		success: function(data){
    			// alert("Saved to db");
    		}
    	});
	}

</script>



<?php $__env->stopSection(); ?>|
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card_big', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/certificacion/programasSECAD/informes/ver_informe_controlObservacion.blade.php ENDPATH**/ ?>