<?php $__env->startSection('title'); ?>
	Programas - Informe Resumen Programa 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addcss'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

		<?php $__env->startSection('card-content'); ?>
		<?php $__env->startSection('card-title'); ?>
		<?php echo e(Breadcrumbs::render('programa')); ?>

		<!-- Begin Modal -->
		
		
		


		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>

		<div class="total-card">
			<div class="row encabezadoPlanInspeccion">

                    <!-- titulo Formulario -->
                    <div class="col-xs-12 text-center">
                        <h3>OFICINA CERTIFICACION AERONAUTICA DE LA DEFENSA - SECAD</h3>
                        <div>
                            <h4>CONTROL DE PROGRAMAS</h4>
                        </div>                        
                   </div>                              
               </div>

			<div class="col-lg-12">	
			<div class="table-responsive">
				<table id="datatable1" class="table table-striped table-hover" style="font-size: 10px;">
					<thead  style="font-size: 9.5px;">
						<tr>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>No Control</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Año</b></th>
							<th style="width: 49.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Tipo</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Equipo</b></th>
							<th style="width: 50.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Unidad</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Empresa</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Proyecto</b></th>
							<th style="width: 54.6px;padding-left: 55px; padding-right: 55px; text-align: center;"><b>Alcance</b></th>
							<th style="width: 50.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Estado</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Producto</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Avance%</b></th>
							
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Jefe Programa</b></th>
							<th style="width: 51.6px;padding-left: 0px; padding-right: 0px; text-align: center;"><b>Recursos</b></th>
						</tr>
					</thead>
					
					<tbody id="data_table" name="data_table">
						 <?php $__currentLoopData = $programa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=> $programas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						 <?php if($permiso->consultar == 1): ?>
						<tr>
							<td style="font-size: 9px;"><?php echo e($programas[0]->Consecutivo); ?></td>
							<td style="font-size: 9px;"><?php echo e($programas[0]->Anio); ?></td>
							<td style="font-size: 8px;"><?php echo e($programas[0]->Tipo); ?></td>
							<td style="font-size: 9px;"><?php echo e($programas[0]->Equipo); ?></td>
							<td style="font-size: 9px;"><?php echo e($programas[0]->NombreUnidad); ?></td>
							<td style="font-size: 9px;"><?php echo e($programas[0]->NombreEmpresa); ?></td>
							<td style="font-size: 9px;"><?php echo e($programas[0]->Proyecto); ?></td>
							<td><p align="justify" style="margin: 0;"><?php echo e($programas[0]->Alcance); ?></p></td>
							<td style="font-size: 8px;"><?php echo e($programas[0]->Estado); ?></td>
							<td style="font-size: 9px;"><?php echo e($programas[0]->NombreProductoServicio); ?></td>
							<td style="font-size: 9px;"><?php echo e(number_format($programas[0]->PorcentajeAvance,2)); ?></td>
							<td style="font-size: 8px;"><?php echo e($programas[0]->Nombres.' '.$programas[0]->Apellidos); ?></td>
							<td style="font-size: 8px;"><?php echo e($programas[0]->NombresSuplente.' '.$programas[0]->ApellidosSuplente); ?></td>
						</tr>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
					</tbody>
				</table>
				<?php if($permiso->consultar == 1): ?>
				<h5 id="conteo"></h5>
				<input type="hidden" id="tablehtml">

				<a id="pdfAction" href="<?php echo e(route('informeresumenprograma.create')); ?>"  style="width: 150px; font-style: Roboto;" class="btn btn-primary btn-block editbutton pull-left"><span class="fa fa-download">    Descargar PDF</span></a>
				
				

				</div><!--end .table-responsive -->
				<?php endif; ?>
			</div><!--end .col -->
		</div>
			 

		<?php $__env->stopSection(); ?>


	<?php $__env->stopSection(); ?>

<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>


<script>
	var filtros = [];
	var pdfexport;
	$(document).ready(function() {
		
	    $('#datatable1').DataTable({
	    	paging: false,
		 	info:false,
		 	ordering: false,
	        initComplete: function () {
	            this.api().columns().every( function () {
	                var column = this;
	                if (column[0] != 6 && column[0] != 7) {
		                var select = $('<br><select style="color:#000; width:90%;"><option value=""></option></select>')
	                    .appendTo( $(column.header()) )
	                    .on( 'change', function () {
	                        var val = $.fn.dataTable.util.escapeRegex(
	                            $(this).val(),
	                            filtros.push($(this).val()));

	                        column.search( val ? '^'+val+'$' : '', true, false ).draw();
	                        var pdfexport = $('#data_table').html().trim();
	                        var cantidad = ($('#datatable1').rowCount());
	                        savedataPDf(pdfexport,cantidad);
	                        $('#conteo').html('Cantidad de Programas ' + $('#datatable1').rowCount());
	                    } );
		 
		                column.data().unique().sort().each( function ( d, j ) {
		                    select.append( '<option value="'+d+'">'+d+'</option>' )
		                	});
	            	}
	           });	    		
	        }


	    });

	 //    var table = $('#datatable1').DataTable();
 
		if ( ! $('#datatable1').rowCount() ) {
			$('#conteo').html('0');
		}
		else
		{
			console.log($('#datatable1').rowCount());
			$('#conteo').html('Cantidad de Programas ' + $('#datatable1').rowCount());
		}

	    // $('#datatable1').tablesorter({sortList: [[7,1], [0,1]]});

	    //ajax setup
	});



	$(window).bind("load", function() {
	   var pdfexport = $('#data_table').html().trim();
	    var cantidad = ($('#datatable1').rowCount());
		savedataPDf(pdfexport,cantidad);
	});

	$.fn.rowCount = function() {
	    return $('tr', $(this).find('tbody')).length;
	};


	function savedataPDf(pdfexport,cantidad){
        $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
        });

        $.ajax({

    		type: 'post',
    		url: 'pdftodb',
    		data: {
    			'table' : pdfexport,
    			'cantidad':cantidad,
    		},
    		success: function(data){
    			// alert("Saved to db");
    		}
    	});
	}

</script>



<?php $__env->stopSection(); ?>|
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card_big', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jcmor\Desktop\SINTE DESARROLLO\Auditor Secad\auditor_secad\resources\views/certificacion/programasSECAD/informes/ver_informe_resumen_programa.blade.php ENDPATH**/ ?>