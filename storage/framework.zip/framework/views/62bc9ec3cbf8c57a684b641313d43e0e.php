<?php $__env->startSection('title'); ?>
	Tablas Crear Plan De Certificación Anual
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>
		<?php $__env->startSection('card-title'); ?>
			<?php echo e(Breadcrumbs::render('pca')); ?>


		<!-- The Modal -->
		<?php if($permiso->crear == 1): ?>
		<button type="button" onclick="window.location='<?php echo e(route("PlanCertificacion.create")); ?>'" class="btn btn-info ink-reaction btn-primary addbutton" id="myBtn"><span class="fa fa-plus"></span></button>
		<?php endif; ?>

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>


			<div class="col-lg-12">
			<div class="table-responsive">
				<table id="datatable1" class="table table-striped table-hover">
					<thead>
						<tr>
							<th><b>Año</b></th>
							<th><b>Edición</b></th>
							<th><b>PDF</b></th>
							
							<th style="width: 200px;"><b>Acción</b></th>
							
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $pca; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pca_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($permiso->consultar == 1): ?>
						<tr>
							<td><?php echo e($pca_item->anio); ?></td>
							<td><?php echo e($pca_item->edicion); ?></td>
							<td>
								<a class="btn btn-primary" href="<?php echo e(URL::asset('pdf/' . $pca_item->id)); ?>">Descargar</a>
							</td>
							
							<td>
							<?php if($permiso->eliminar == 1): ?>
								<div class="col-sm-4">
									<?php if($pca_item->Activo): ?>
									<?php echo Form::open(['route' => ['PlanCertificacion.destroy', $pca_item->id], 'method' => 'DELETE']); ?>


									<?php echo Form::submit('x', ['class' => 'btn btn-danger deleteButton', 'title' =>'Eliminar']); ?>


									<?php echo Form::close(); ?>

									<?php else: ?>
									<?php echo Form::open(['route' => ['PlanCertificacion.show', $pca_item->id], 'method' => 'GET']); ?>


									<?php echo Form::submit('✓', ['class' => 'btn btn-success','style'=>'height: 36px;width: 36px;', 'title' =>'Mostrar']); ?>


									<?php echo Form::close(); ?>

									
								</div>
							<?php endif; ?>							


							<?php if($permiso->actualizar == 1): ?>
								<div class="col-sm-4">

									<a href="<?php echo e(route('PlanCertificacion.edit', $pca_item->id)); ?>" class="btn btn-primary btn-block editbutton" title="Editar"><div class="gui-icon"><i class="fa fa-pencil"></i></div></a>

								</div>
							<?php endif; ?>
								<div class="col-sm-4">

									<a href="<?php echo e(route('PlanCertificacion.notas', $pca_item->id)); ?>" class="btn btn-primary btn-block editbutton" title="Ver notas"><div class="gui-icon"><i class="fa fa-clipboard"></i></div></a>

								</div>

							</td>
							<?php endif; ?>

						</tr>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div><!--end .table-responsive -->
		</div><!--end .col -->
		<?php $__env->stopSection(); ?>

	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>
<script>
	$(document).ready(function(){
		$('#datatable1').DataTable();
	});
</script>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/certificacion/planCertificacionAnual/ver_certificacion.blade.php ENDPATH**/ ?>