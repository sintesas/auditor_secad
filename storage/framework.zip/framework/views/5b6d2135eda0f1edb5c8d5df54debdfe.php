<?php $__env->startSection('title'); ?>
	Crear Listas Valores
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startSection('card-content'); ?>

        <?php $__env->startSection('form-tag'); ?>
			<?php echo Form::open(['route' => 'listasvalores.store']); ?>


            <?php echo e(csrf_field()); ?>

		
        <?php $__env->stopSection(); ?>				

        <?php $__env->startSection('card-title'); ?>
			
            <?php echo e(Breadcrumbs::render('crear_lista_dinamica')); ?>


		<?php $__env->stopSection(); ?>

        <?php $__env->startSection('card-content'); ?>

            <div class="card-body floating-label">
                <div class="card">
                    <div class="card-head card-head-sm style-primary">
                        <header>
                            Crear Listas Valores
                        </header>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <input type="text" class="form-control" id="lista_dinamica" name="lista_dinamica" required>
                                    <label for="lista_dinamica">Lista Valor</label>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <input type="text" class="form-control" id="codigo" name="codigo">
                                    <label for="codigo">Código</label>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" id="descripcion" name="descripcion">
                                    <label for="descripcion">Descripción</label>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="form-group">
                                    <select id="lista_dinamica_padre_id" name="lista_dinamica_padre_id" class="form-control">
                                        <option value="0">Seleccione...</option>
                                        <?php $__currentLoopData = $listas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->lista_dinamica_id); ?>"><?php echo e($item->lista_dinamica); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <label for="lista_dinamica_padre_id">Lista Padre</label>
                                </div>
                            </div>
                            <div class="col-sm-3">
                                <div class="form-group">
                                    <input type="checkbox" id="activo" name="activo" checked>
                                    <label for="activo">Activo</label>                            
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col-sm-6">
                            <button type="submit" style="" class="btn btn-info btn-block">Crear</button>
                        </div>
                        <div class="col-sm-6">
                            <button type="button" onclick="window.location='<?php echo e(route("listasvalores.indice", $nombre_lista_id)); ?>'" style="" class="btn btn-danger btn-block">Cancelar</button>
                        </div>
                    </div>
                </div>
            </div>

        <?php $__env->stopSection(); ?>

    <?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/param/crear_listas_dinamicas.blade.php ENDPATH**/ ?>