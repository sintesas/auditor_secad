<?php $__env->startSection('title'); ?>
	Programas - Informe Resumen Programa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addcss'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>
		<?php $__env->startSection('card-title'); ?>
		<?php echo e(Breadcrumbs::render('programa')); ?>

		<!-- Begin Modal -->
		
		
		


		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>

		<div class="total-card">
			<div class="row encabezadoPlanInspeccion">

                    <!-- titulo Formulario -->
                    <div class="col-xs-12 text-center">
                        
                        <div>
                            <h4>Observaciones del Programa</h4>
                            <h5><?php echo e($programa->Consecutivo); ?></h5>
                            <h5><?php echo e($programa->Proyecto); ?></h5>
                        </div>                        
                   </div>                              
               </div>

			<div class="col-lg-12">	
			<div class="table-responsive">
				<table id="datatable1" class="table table-striped table-hover" style="font-size: 10px;">
					<thead  style="font-size: 9.5px;">
						<tr>
							<th style="width:10%; padding-left: 0px; padding-right: 0px; text-align: center;"><b>Fecha</b></th>
							<th style="width: 90%; padding-left: 0px; padding-right: 0px; text-align: center;"><b>Observacion</b></th>
						</tr>
					</thead>
					
					<tbody id="data_table" name="data_table">
						<?php $__currentLoopData = $observaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $observacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td style="font-size: 8px;"><?php echo e($observacion->Fecha); ?></td>
							<td style="font-size: 9px;"><?php echo e($observacion->Observacion); ?></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
				
				<input type="hidden" id="tablehtml">

				<a id="pdfAction" href="<?php echo e(route('obsercavionesProgramafr212.edit', $programa->IdPrograma)); ?>"  style="width: 150px; font-style: Roboto;" class="btn btn-primary btn-block editbutton pull-left"><span class="fa fa-download">    Descargar PDF</span></a>

				

				</div><!--end .table-responsive -->
			</div><!--end .col -->
		</div>
			 

		<?php $__env->stopSection(); ?>


	<?php $__env->stopSection(); ?>

<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>


<script>
	var filtros = [];
	var pdfexport;
	$(document).ready(function() {
		
	    $('#datatable1').DataTable();
	});



	$(window).bind("load", function() {
	   var pdfexport = $('#data_table').html().trim();
		savedataPDf(pdfexport);
	});




	function savedataPDf(pdfexport){
        $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
        });

        $.ajax({

    		type: 'post',
    		url: 'pdftodb',
    		data: {
    			'table' : pdfexport
    		},
    		success: function(data){
    			// alert("Saved to db");
    		}
    	});
	}

</script>



<?php $__env->stopSection(); ?>|
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card_big', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/certificacion/programasSECAD/seguimientoProgramas/ver_InformeObservacionesLAFR212Progamas.blade.php ENDPATH**/ ?>