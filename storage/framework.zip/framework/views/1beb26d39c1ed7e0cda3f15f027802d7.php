<?php $__env->startSection('title'); ?>
Convenios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('card-content'); ?>
<?php $__env->startSection('card-title'); ?>
<?php echo e(Breadcrumbs::render('convenios')); ?>

<!-- Begin Modal -->
<?php if($permiso->crear == 1): ?>
<button type="button" onclick="document.getElementById('id1').style.display='block'" style="margin-left:800px;" class="btn btn-info ink-reaction btn-primary addbutton" id="myBtn"><span class="fa fa-plus"></span></button>
<?php endif; ?>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('card-content'); ?>



<div class="col-lg-12">
	<div class="table-responsive">
		<!-- BEGIN STRUCTURE  -->
		<div class="row">
			<div class="col-md-12">
				<div class="panel-group" id="accordion1">
					<div class="card panel">
						<div class="card-head expanded" data-toggle="collapse" data-parent="#accordion1" data-target="#accordion1-1">
							<header>Convenios</header>
							<div class="tools">
								<a class="btn btn-icon-toggle"><i class="fa fa-angle-down"></i></a>
							</div>
						</div>
						
						<div id="accordion1-1" class="collapse in">


							<div class="col-lg-12">
								<div class="table-responsive">
									<table id="datatable1" class="table table-striped table-hover">
										<thead>
											<tr>
												<th><b>Nombre</b></th>
												<th><b>Entidad</b></th>
												<th><b>Fecha</b></th>
												<th><b>Vigencia</b></th>
												<th><b>Objeto</b></th>
												<th><b>Responsable</b></th>
												<th><b>Acción</b></th>

											</tr>
										</thead>
										<tbody>
											<?php $__currentLoopData = $convenios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $convenio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($permiso->consultar == 1): ?>
											<tr>
												<td><?php echo e($convenio->NombreConv); ?></td>
												<td><?php echo e($convenio->Entidad); ?></td>
												<td><?php echo e(date('M j, Y ',strtotime($convenio->Fecha))); ?></td>
												<td><?php echo e(date('M j, Y ', strtotime($convenio->Vigencia))); ?></td>
												<td><?php echo e($convenio->Objeto); ?></td>
												<td><?php echo e($convenio->Responsable); ?></td>


												<td>
												<?php if($permiso->eliminar == 1): ?>
													<div class="col-sm-6">

														<?php echo Form::open(['route' => ['convenio.destroy', $convenio->IdConvenios], 'method' => 'DELETE']); ?>


														<?php echo Form::submit('x', ['class' => 'btn btn-danger deleteButton']); ?>


														<?php echo Form::close(); ?>

													</div>
												<?php endif; ?>
												<?php if($permiso->actualizar == 1): ?>
													<div class="col-sm-6">

														<a href="<?php echo e(route('convenio.edit', $convenio->IdConvenios)); ?>" class="btn btn-primary btn-block editbutton" ><div class="gui-icon"><i class="fa fa-pencil"></i></div></a>

													</div>
												<?php endif; ?>

												</td>

											</tr>
											<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tbody>
									</table>
								</div><!--end .table-responsive -->
							</div><!--end .col -->

						</div>

						<?php echo Form::close(); ?>


					</div>
				</div><!--end .panel -->
			</div><!--end .panel-group -->
		</div><!--end .col -->
	</div><!--end .row -->
	<!-- END STRUCTURE -->
</div><!--end .table-responsive -->

















<div id="id1" class="modal" style="padding-top:80px;">

	<div class="modal-content" style="width:60%;">

		<div class="card-head style-primary">
			<header>Crear Nuevo Convenio</header>
			<span style="margin-right: 20px;" onclick="document.getElementById('id1').style.display='none'"
			class="close">x</span>
		</div>

		<div class="card">
			<div class="card-body floating-label">

				<?php echo Form::open(array('route' => 'convenio.store')); ?>


				<?php echo e(csrf_field()); ?>


				<div class="card">
					<div class="card-body">

						<div class="row">
							<div class="col-sm-6">
								<div class="form-group">
									<input type="text" class="form-control" id="Nombre" name="NombreConv" required>
									<label for="Nombre">Nombre Convenio</label>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-group">
									<input type="text" class="form-control" id="Entidad" name="Entidad" required>
									<label for="Entidad">Entidad</label>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-6">
								<div class="form-group">
									<div class="input-group date" id="demo-date-format">
										<div class="input-group-content">
											<input type="text" class="form-control" id="Fecha" name="Fecha" required >
											<label for="Fecha">Fecha</label>
										</div>
										<span class="input-group-addon"></span>
									</div>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-group">
									<div class="input-group date" id="demo-date-format">
										<div class="input-group-content">
											<input type="text" class="form-control" id="Vigencia" name="Vigencia" required >
											<label for="Vigencia">Vigencia</label>
										</div>
										<span class="input-group-addon"></span>
									</div>
								</div>
							</div>
						</div>

						<div class="row">
							<div class="col-sm-6">
								<div class="form-group">
									<?php echo e(Form::select('IdCaracterConvenio', $caraterConvenios->pluck('NombreCaracterConvenio' , 'IdCaracterConvenio'), null, ['class' => 'form-control', 'id' => 'IdCaracterConvenio'])); ?>

									<label for="IdCaracterConvenio">Caracter Convenio</label>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-group">
									<?php echo e(Form::select('IdEstadoConvenio', $estadoConvenios->pluck('NombreEstadoConvenio' , 'IdEstadoConvenio'), null, ['class' => 'form-control', 'id' => 'IdEstadoConvenio'])); ?>

									<label for="Entidad">Estado Convenio</label>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<textarea class="form-control" id="Objeto" name="Objeto" rows="2" required> </textarea>
									<label for="Observaciones">Objeto</label>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-12">
								<div class="form-group">
									<textarea class="form-control" id="Antecedente" name="Antecedente" rows="2" required> </textarea>
									<label for="Antecedente">Antecedente</label>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-group">
									<input type="text" class="form-control" id="Responsable" name="Responsable" required>
									<label for="Responsable">Responsable</label>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-6">
								<div class="form-group">
									<input type="text" class="form-control" id="Contacto" name="Contacto" required>
									<label for="Contacto">Contacto</label>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-group">
									<input type="text" class="form-control" id="Celular" name="Celular" required>
									<label for="Celular">Celular</label>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-6">
								<div class="form-group">
									<input type="text" class="form-control" id="Email" name="Email" required>
									<label for="Email">Email</label>
								</div>
							</div>
							<div class="col-sm-6">
								<div class="form-group">
									<input type="text" class="form-control" id="Pendiente" name="Pendiente" required>
									<label for="Pendiente">Pendientes</label>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-sm-6">
								<div class="form-group">
									<input type="text" class="form-control" id="DSDS"  name="DSDS" required>
									<label for="DSDS">DSDS</label>
								</div>
							</div>
							<div class="col-sm-6" style ="visibility: hidden">
								<div class="form-group">
									<?php echo e(Form::select('IdTipoConvenio', $TipoConvenio->pluck('NombreTipoConvenio' , 'IdTipoConvenio'), null, ['class' => 'form-control', 'id' => 'IdTipoConvenio'])); ?>

									<label for="IdTipoConvenio">Tipo Convenio</label>
								</div>
							</div>
						</div>
					</div>
				</div>


				<div class="row">
					<div class="col-sm-6">
						<button type="submit" style="" class="btn btn-info btn-block">Crear</button>
					</div>
					<div class="col-sm-6">
						<button type="button" onclick="document.getElementById('id1').style.display='none'" style="" class="btn btn-danger btn-block">Cancelar</button>
					</div>
				</div>


			</div>
		</div>

	</div>
</div>






	</center>



	<?php echo Form::close(); ?>


</div>
</div>

</div>





</div>
</div>



<?php $__env->stopSection(); ?>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>

<script>
	$(document).ready(function(){
		$('#datatable1').DataTable();
	});
</script>

<?php $__env->stopSection(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/fomento/convenios/convenios.blade.php ENDPATH**/ ?>