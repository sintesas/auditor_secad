<?php $__env->startSection('title'); ?>
Usuarios Empresa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addcss'); ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"> </script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('card-content'); ?>

<?php $__env->startSection('card-title'); ?>


Crear Usuarios Empresas

<!-- The Modal -->

		<button type="button" onclick="window.location='<?php echo e(route("asignarusuarioEmpresa.create")); ?>'" class="btn btn-info ink-reaction btn-primary addbutton" id="myBtn"><span class="fa fa-plus"></span></button>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('card-content'); ?>

<div class="col-lg-12">
	<div class="table-responsive">
		
		
		<table id="datatable1" class="table table-striped table-hover">
			<thead>
				<tr>
					<th><b>Empresa</b></th>
					<th><b>Nombre</b></th>
					<th><b>Email</b></th>
					
						<th style="width: 160px;"><b>Acción</b></th>
						
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $userComamies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($user->NombreEmpresa); ?></td>

					<td><?php echo e($user->name); ?></td>

					<td><?php echo e($user->email); ?></td>
					
					
						<td>
							
							<div class="col-sm-4">

								<?php echo Form::open(['route' => ['asignarusuarioEmpresa.destroy', $user->id], 'method' => 'DELETE']); ?>

	
								<?php echo Form::submit('x', ['class' => 'btn btn-danger deleteButton']); ?>

	
								<?php echo Form::close(); ?>

							</div>
	
	
							<div class="col-sm-4">
	
								<a href="<?php echo e(route('asignarusuarioEmpresa.edit', $user->id)); ?>" class="btn btn-primary btn-block editbutton" ><div class="gui-icon"><i class="fa fa-pencil"></i></div></a>
	
							</div>
						
						</td>
				
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		
	</div><!--end .table-responsive -->
</div><!--end .col -->





<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('addjs'); ?>


<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>

<script src="<?php echo e(URL::asset('js/edit.js')); ?>"></script>
 
<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>



<script>
	$(document).ready(function(){
		$('#datatable1').DataTable();
	});


	
	
</script>



<?php $__env->stopSection(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card_big', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/gestionRecursos/recursoHumano/ver_empresa_asignar.blade.php ENDPATH**/ ?>