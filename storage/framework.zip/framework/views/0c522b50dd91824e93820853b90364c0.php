<?php $__env->startSection('title'); ?>
	Informe Resumen Cluster
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>

		<?php $__env->startSection('form-tag'); ?>

	    <?php echo Form::model($cluster); ?>

        <?php echo e(csrf_field()); ?>


		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-title'); ?>
          Informe Resumen Cluster
		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>       

		<div class="card-body floating-label">
		<!-- BEGIN BASE-->
		<div id="">

			<!-- BEGIN OFFCANVAS LEFT -->
			<div class="offcanvas">
			</div><!--end .offcanvas-->
			<!-- END OFFCANVAS LEFT -->

			<!-- BEGIN CONTENT-->
            <div id="">
                <section>                   
                    <div class="section-body">
                       <!-- PRIMER BLOQUE DE INFOMACION -->
                       <div class="row encabezadoPlanInspeccion">
                            
                            <!-- titulo Formulario -->
              <div class="col-xs-12 text-center">
                                <div class="total-card">
			<div class="row encabezadoPlanInspeccion">

                    <!-- titulo Formulario -->
                    <div class="col-xs-12 text-center">
                        <h3>OFICINA CERTIFICACION AERONAUTICA DE LA DEFENSA - SECAD</h3>
                        <div>
                            <h4>INFORME AFILIADOS POR CLUSTER</h4>
                        </div>                        
                   </div>                              
               </div>
                            </div>                                         
                            
            </div><!--end .row -->                                          
                        <!-- PRIMER BLOQUE DE INFOMACION -->
                        <div class="row">                            
                            <div class="col-xs-12 text-center">
                                <h5> <span>Nombre Cluster</span><span> Asociacion Colombiana de Productores Aeronauticos</span> </h5>
                            </div>                            
                            
                            <!-- Responsable Proceso -->
                            <div class="col-xs-12 filaFormulario table-fixed">
                                <table class="table  table-x">
                                  <tr>
                                    
                                      <th class="th-x text-center"> ID</th>
                                      <th class="th-x text-center" > Ciudad</th>  
                                      <th class="th-x text-center" > Region</th>
                                      <th class="th-x text-center" > Repres Legal</th>    
                                      <th class="th-x text-center" > Dirección</th>       
                                      <th class="th-x text-center" > Telefono </th>    
                                      <th class="th-x text-center" > Email</th>       
                                      <th class="th-x text-center" > Sigla </th>                                                                                      
                                      
                                  </tr>                                  
                                   <?php if(count($cluster) != 1): ?>
                                   <?php $__currentLoopData = $cluster; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clusterR): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                   <?php if($permiso->consultar == 1): ?>               
                                    <tr class="line-b">                                                                    
                                        <th class="text-center"><?php echo e($clusterR->IdCluster); ?></th>
                                        <th class="text-center"><?php echo e($clusterR->Ciudad); ?></th>                             
                                        <th class="text-center"><?php echo e($clusterR->Region); ?></th>
                                        <th class="text-center"><?php echo e($clusterR->RepresLegal); ?></th>                             
                                        <th class="text-center"><?php echo e($clusterR->Direccion); ?></th>
                                        <th class="text-center"><?php echo e($clusterR->Telefono); ?></th>
                                        <th class="text-center"><?php echo e($clusterR->Email); ?></th>
                                        <th class="text-center"><?php echo e($clusterR->Sigla); ?></th>
                                  </tr>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                      <div class="section-body">
                                        <div class="text-center">
                                            <h3>No hay datos para mostrar informe</h3>
                                        </div>
                                      </div>
                                    <?php endif; ?>
                                    <!--<tr class="line-b" id="filaFinal">  
                                        <th class="">TOTAL(Capacidades x Empresas)=</th>               <th class="">...</th>
                                                                          
                                  </tr>-->
                                </table>
                            </div>
            </div><!--end .row -->       
                    </div><!--end .section-body -->                   
                </section>
            </div><!--end #content-->
            <!-- END CONTENT -->
            <?php if($permiso->consultar == 1): ?>
            <a href="<?php echo e(route('informeresumencluster.create')); ?>" style="width: 150px; font-style: Roboto;" class="btn btn-primary btn-block editbutton pull-right"><span class="fa fa-download">    Descargar PDF</span></a>
            <?php endif; ?>
        </div>
    </div>

        

		<?php echo Form::close(); ?>

		<?php $__env->stopSection(); ?>

	<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/fomento/agremiaciones/informes/visual_informe_resumen_cluster.blade.php ENDPATH**/ ?>