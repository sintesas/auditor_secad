<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-4 col-md-offset-4">
            <div class="panel panel-default">            
                <div class="panel-heading" style="background-color: #0f1f31; color:#cccccc;">
                    <center><h1 class="panel-title">Login</h1></center>
                </div>                
                <div class="panel-body">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo e(csrf_field()); ?>                                    
                        <div class="form-group <?php echo e($errors->has('usuario') ? 'has-error' : ''); ?>">
                            <label for="Usuario">Usuario</label>
                                <input class="form-control" type="text" name="usuario" value="<?php echo e(old('usuario')); ?>" placeholder="Ingrese su correo">
                                <?php echo $errors->first('usuario', '<span class="help-block">:message </span>'); ?>

                        </div>
                        <div class="form-group <?php echo e($errors->has('password') ? 'has-error' : ''); ?>" >
                            <label for="password">Contraseña </label>
                            <input class="form-control" type="password" name="password" placeholder="Ingrese su contraseña">
                            <?php echo $errors->first('password', '<span class="help-block">:message </span>'); ?>

                        </div>
                        <button type="submit" class="btn btn-primary btn-block">Ingreso</button>
                        <br>
                        <a href="javascript:void(0)">Olvidó Su Contraseña?</a>
                    </form>
                </div>
            </div>
        </div>
    </div>    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SINTE DESARROLLO - 5 de Junio\Auditor Secad\auditor_secad\resources\views/auth/login.blade.php ENDPATH**/ ?>