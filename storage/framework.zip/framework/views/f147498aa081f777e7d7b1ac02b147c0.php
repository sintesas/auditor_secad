<?php $__env->startSection('title'); ?>
	Seguimiento Actividades
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('card-content'); ?>
<?php $__env->startSection('card-title'); ?>
<?php echo e(Breadcrumbs::render('verseguimientoEmp', $programa->IdPrograma,  $actividad->IdActividad.'&'.$programa->IdPrograma)); ?>

<button type="button" onclick="window.location='<?php echo e(route("seguimientoEmp.show", "$programa->IdPrograma" . "&" ."$actividad->IdActividad")); ?>'" class="btn btn-info ink-reaction btn-primary addbutton" id="myBtn"><span class="fa fa-plus"></span></button>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('card-content'); ?>

<div class="col-lg-12">
	<div class="table-responsive">
		<h4><strong>Programa:</strong> <?php echo e($programa->Consecutivo); ?> / <strong>Tipo Programa:</strong> <?php echo e($tipoPrograma->Tipo); ?></h4>
		<h4><strong>Actividad:</strong> <?php echo e($actividad->Actividad); ?></h4>
		<table id="datatable1" class="table table-striped table-hover">
			<thead>
				<tr>
					<th><b>Fecha</b></th>
					<th><b>Usuario</b></th>
					<th><b>Observaciones</b></th>
					<th style="width: 120px;"><b>Acciones</b></th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $seguimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seguimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($seguimiento->Fecha); ?></td>
					<td><?php echo e($seguimiento->Usuario); ?></td>
					<td><?php echo e($seguimiento->Observaciones); ?></td>
					<td>
						<div class="col-sm-6">

							<?php echo Form::open(['route' => ['seguimientoEmp.destroy', $seguimiento->IdListaSeguimientoEmp], 'method' => 'DELETE']); ?>


							<?php echo Form::submit('x', ['class' => 'btn btn-danger deleteButton']); ?>


							<?php echo Form::close(); ?>

						</div>


						

					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div><!--end .table-responsive -->
</div><!--end .col -->

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>

<script>
	$(document).ready(function(){
		$('#datatable1').DataTable();
	});
</script>

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/certificacion/programasSECAD/seguimientoProgramas/seguimientoEmpresa/ver_lista_seguimiento_emp.blade.php ENDPATH**/ ?>