<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body class="menubar-hoverable header-fixed ">

	<?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>	
	<!-- BEGIN BASE-->
	<div id="base">
		<!-- BEGIN LOADING -->
		<div id="status" class="modalFAC" style="display: none">
		    <div class="centerModalFAC">
		    	<img src="<?php echo e(URL::asset('img/Ripple.svg')); ?>" alt="">
		        <div style="text-align:center; color: #ffffff;">
		            Cargando...
		        </div>
		    </div>
		</div>
		<!-- END LOADING -->		
		<!-- BEGIN OFFCANVAS LEFT -->
		<div class="offcanvas">
		</div><!--end .offcanvas-->
		<!-- END OFFCANVAS LEFT -->
		
		
		<?php echo $__env->yieldContent('content'); ?>
		

		<?php echo $__env->make('partials.menu', ['menus' => Session::get('menus')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div><!--end #base-->
	<!-- END BASE -->	
	<?php echo $__env->make('partials.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	
</body>
</html><?php /**PATH C:\Users\ASUS-PC\Desktop\SINTE DESARROLLO - 1 de Julio\Auditor Secad\auditor_secad\resources\views/layout.blade.php ENDPATH**/ ?>