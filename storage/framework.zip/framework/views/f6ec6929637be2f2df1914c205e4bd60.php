<?php $__env->startSection('title'); ?>
	Consolidado NUE, REP, ADIC
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>

		<?php $__env->startSection('form-tag'); ?>

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-title'); ?>
			Consolidado NUE, REP, ADIC
		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>

			<div class="card-body floating-label">
				<div style="overflow-x: auto;" id="output"></div>
			</div>

			 <script type="text/javascript">

			 	/*REVISAR CON LA CAPITAN ESL MISMO AL ANTERIOR*/
			 	var derivers = $.pivotUtilities.derivers;
		        var renderers = $.extend($.pivotUtilities.renderers, $.pivotUtilities.plotly_renderers);

			    // This example is the most basic usage of pivotUI()
				$.get('apacAuditoria/vistaAuditorias/', function(response, state){
				// console.log(response);
					//console.log('entra', state, response);
					$("#output").pivotUI(
			            response,
			            {
			            	renderers: renderers,
			                rows: ["Codigo", "Empresa", "Proceso"],
			                cols: ["TipoAnotacion"],
			                aggregatorName: "List Unique Values",
                			vals: ["NoAnota"],
                			hideTotals: 'true',
			            }
			        );
				});

			    $(function(){
			        
			     });
        	</script>
		<?php $__env->stopSection(); ?>

	<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card_big', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/auditoria/tablasDinamicas/TDINConsolidadoNEREPADIC.blade.php ENDPATH**/ ?>