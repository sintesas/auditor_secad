<?php $__env->startSection('title'); ?>
Tablas Crear Empresa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('card-content'); ?>
<?php $__env->startSection('card-title'); ?>
<?php echo e(Breadcrumbs::render('empresa')); ?>



	<!-- The Modal -->
	<?php if($permiso->crear == 1): ?>
	<button type="button" onclick="window.location='<?php echo e(route("empresa.create")); ?>'" class="btn btn-info ink-reaction btn-primary addbutton" id="myBtn"><span class="fa fa-plus"></span></button>
	<?php endif; ?>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('card-content'); ?>


<div class="col-lg-12">
	<div class="table-responsive">
		<table id="datatable1" class="table table-striped table-hover">
			<thead>
				<tr>
					<th><b>Nombre</b></th>
					<th><b>Email</b></th>
					<th><b>Ciudad</b></th>
				
						<th><b>Capacidades</b></th>
					
					<th><b>Funcionarios</b></th>
					
						<th style="width: 120px;"><b>Acción</b></th>
						
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $vwempresa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($permiso->consultar == 1): ?>
				<tr>
					<td><?php echo e($empresa->NombreEmpresa); ?></td>
					<td><?php echo e($empresa->Email); ?></td>
					<td><?php echo e($empresa->Ciudad); ?></td>
					
						<td>
						
							<div class="col-sm-1">
								<a href="<?php echo e(route('capacidadesEmpresa.show', $empresa->IdEmpresa)); ?>" class="btn btn-default btn-group-xs"><span class="fa fa-gear"></span></a>
							</div>	
							
						</td>
					
					<td>

						<div class="col-sm-1">
							<a href="<?php echo e(route('funcionariosEmpresa.show', $empresa->IdEmpresa)); ?>" class="btn btn-default btn-group-xs"><span class="fa fa-users"></span></a>
						</div>
					</td>
					
						<td>
						<?php if($permiso->eliminar == 1): ?>
							<div class="col-sm-6">
	
								<?php echo Form::open(['route' => ['empresa.destroy', $empresa->IdEmpresa], 'method' => 'DELETE']); ?>

	
								<?php echo Form::submit('x', ['class' => 'btn btn-danger deleteButton']); ?>

	
								<?php echo Form::close(); ?>

							</div>
						<?php endif; ?>
						<?php if($permiso->actualizar == 1): ?>
							<div class="col-sm-6">
	
								<a href="<?php echo e(route('empresa.edit', $empresa->IdEmpresa)); ?>" class="btn btn-primary btn-block editbutton" ><div class="gui-icon"><i class="fa fa-pencil"></i></div></a>
	
							</div>
						<?php endif; ?>
						</td>
						
				</tr>
				<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
		
	</div><!--end .table-responsive -->
</div><!--end .col -->
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>

<script>
	$(document).ready(function(){
		$('#datatable1').DataTable();
	});
</script>



<?php $__env->stopSection(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card_big', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/fomento/empresas/ver_tablas_empresas.blade.php ENDPATH**/ ?>