<?php $__env->startSection('title'); ?>
Actividades Tipos Programa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addcss'); ?>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"> </script>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('card-content'); ?>
<?php $__env->startSection('card-title'); ?>
<?php echo e(Breadcrumbs::render('activ_tiposprograma')); ?>

<!-- The Modal -->
<button type="button" onclick="document.getElementById('id1').style.display='block'" style="margin-left:800px;" class="btn btn-info ink-reaction btn-primary addbutton" id="myBtn"><span class="fa fa-plus"></span></button>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('card-content'); ?>
<div class="col-lg-12">
	<h4><strong>Tipo Programa:</strong> <?php echo e($tipoPrograma->Tipo); ?></h4>
	<div class="table-responsive">
		<table id="datatable1" class="table table-striped table-hover">
			<thead>
				<tr>
					<th><b>Orden</b></th>
					<th><b>Actividad</b></th>
					<th><b>Responsable</b></th>
					<th style="width: 120px;"><b>Acción</b></th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($actividad->Orden); ?></td>
					<td><?php echo e($actividad->Actividad); ?></td>
					<td><?php echo e($actividad->Responsable); ?></td>
					
					<td>
						<div class="col-sm-6">

							<?php echo Form::open(['route' => ['actividadesTipoProg.destroy', $actividad->IdActividad], 'method' => 'DELETE']); ?>


							<?php echo Form::submit('x', ['class' => 'btn btn-danger deleteButton']); ?>


							<?php echo Form::close(); ?>

						</div>

						<div class="col-sm-6">
							<button class="btn btn-primary btn-default edit-modal" data-id="<?php echo e($actividad->IdActividad); ?>" data-actividad="<?php echo e($actividad->Actividad); ?>" data-responsable="<?php echo e($actividad->Responsable); ?>" data-orden="<?php echo e($actividad->Orden); ?>">
                    			<span class="glyphicon glyphicon-edit"></span>
                			</button>
						</div>

						

					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div><!--end .table-responsive -->
</div><!--end .col -->


<div id="id1" class="modal" style="padding-top:135px;">
	<div class="modal-content">
		<div class="card-head style-primary">
			<header>Creación Actividad Tipo Programa</header>
			<span style="margin-right: 20px;" onclick="document.getElementById('id1').style.display='none'"
			class="close">x</span> 
		</div>	
		<div class="card">
			<div class="card-body floating-label">
				<?php echo Form::open(array('route' => 'actividadesTipoProg.store')); ?>

				<?php echo e(csrf_field()); ?>

				<div class="row">
					<div class="col-sm-12">
						<div class="form-group">											
							<?php echo e(Form::text('Actividad', null, array('class' => 'form-control', 'required' => '' ))); ?>

							<?php echo e(Form::label('Actividad', 'Actividad')); ?>

						</div>
					</div>
					
				</div>
				<div class="row">
					<div class="col-sm-6">
						<div class="form-group">										
							<?php echo e(Form::text('Responsable', null, array('class' => 'form-control','required' => '' ))); ?>

							<?php echo e(Form::label('Responsable', 'Responsable')); ?>

						</div>
					</div>
					<div class="col-sm-6">
						<div class="form-group">										
							<?php echo e(Form::number('Orden', null, array('class' => 'form-control','required' => '' ))); ?>

							<?php echo e(Form::label('Orden', 'Orden')); ?>

						</div>
					</div>
				</div>
				<input type="hidden" value="<?php echo e($tipoPrograma->IdTipoPrograma); ?>" name="IdTipoPrograma">
				<div class="form-group">
					<div class="row">
						<div class="col-sm-6">
							<button type="submit" style="" class="btn btn-info btn-block">Crear</button>
						</div>
						<div class="col-sm-6">
							<button type="button" onclick="document.getElementById('id1').style.display='none'" style="" class="btn btn-danger btn-block">Cancelar</button>
						</div>
					</div>
				</div>	
				<?php echo Form::close(); ?>			
			</div>
		</div>	
		<script>
			$(".delete").on("submit", function(){
				return confirm("Esta seguro que desea borrar este codigo?");
			});
		</script>			
	</div>
</div>





<div id="myModal" class="modal" style="padding-top:80px;">

	<div class="modal-content" style="width:60%;">

		<div class="card-head style-primary">
			<header>Editar Tipo Programa</header>
		</div>

		<div class="card">
			<div class="card-body floating-label">


				<form class="form-horizontal" role="form">

					<div class="card">
						<div class="card-body">
							
								
							<input type="hidden" id="IdActividad" name="IdActividad">	

							<div class="row">
								<div class="col-sm-12">
									<div class="form-group">
										<input type="text" class="form-control" id="Actividad" name="Actividad" required>
										<label for="Actividad">Actividad</label>
									</div>
								</div>
									
							</div>
							<div class="row">
								<div class="col-sm-6">
									<div class="form-group">
										<input type="text" class="form-control" id="Responsable" name="Responsable" required>
										<label for="Responsable">Responsable</label>
									</div>
								</div>
								<div class="col-sm-6">
									<div class="form-group">
										<input type="number" class="form-control" id="Orden" name="Orden" required>
										<label for="Orden">Orden</label>
									</div>
								</div>
							</div>

						</div>  
					</div>

				</form>

				<div class="modalfooter">
					<div class="col-sm-6">
						<button type="button" class="btn actionBtn" data-dismiss="modal">
							<span id="footer_action_button" class="glyphicon"></span>
						</button>
					</div>
					<div class="col-sm-6">
						<button type="button" class="btn cancelBtn" data-dismiss="modal">
							<span class="glyphicon glyphicon-remove"></span>
						</button>
					</div>
				</div>


			</div>
		</div>

	</div>
</div>






<?php $__env->stopSection(); ?>

<?php $__env->startSection('button'); ?>
Imprimir Tabla
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>


<script>

	$(document).ready(function(){

		function RefreshTable() {
				$("#datatable1").load("<?php echo e(route('actividadesTipoProg.show', $tipoPrograma->IdTipoPrograma)); ?> #datatable1");
		}

		$(document).on('click', '.edit-modal', function(){
	        $('#footer_action_button').text("Actualizar");
	        $('#footer_action_button').addClass('glyphicon-check');
	        $('#footer_action_button').removeClass('glyphicon-trash');
	        $('.actionBtn').addClass('btn-info');
	        $('.actionBtn').addClass('btn-block');    
	        $('.actionBtn').removeClass('btn-danger');
	        $('.actionBtn').addClass('edit');
	        $('.cancelBtn').addClass('btn-danger');
	        $('.cancelBtn').addClass('btn-block');    
	        $('.modal-title').text('Edit');
	        $('.deleteContent').hide();
	        $('.form-horizontal').show();

	        $('#IdActividad').val($(this).data('id'));
	        $('#Actividad').val($(this).data('actividad'));
	        $('#Responsable').val($(this).data('responsable'));
	        $('#Orden').val($(this).data('orden'));
	        $('#myModal').modal('show');
	         

	    });


	$('.modalfooter').on('click', '.edit', function(){

        $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
        });

    	$.ajax({

    		type: 'post',
    		url: '/editactividad',
    		data: {
    			
			'id': $("#IdActividad").val(),
			'actividad': $("#Actividad").val(),
			'responsable': $("#Responsable").val(),
			'orden': $("#Orden").val(),
    		},
    		success: function(data){
                toastr.success("Información Actualizada");
				RefreshTable();
    	}

    });

	});

	});

</script>


<script>
	$(document).ready(function(){
		$('#datatable1').DataTable();
	});
</script>

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/certificacion/variables/ver_tipo_programa_actividades.blade.php ENDPATH**/ ?>