<?php $__env->startSection('title'); ?>
	Informe Ofertas Sector Aeronautico
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>

		<?php $__env->startSection('form-tag'); ?>

	    <?php echo Form::model($ofertasSectorAeronautico); ?>

        <?php echo e(csrf_field()); ?>


		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-title'); ?>
			
            <?php echo e(Breadcrumbs::render('informe_ofertas_sector_aeronautico')); ?>

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>       

		<div class="card-body floating-label">
		<!-- BEGIN BASE-->
		<div id="">

			<!-- BEGIN OFFCANVAS LEFT -->
			<div class="offcanvas">
			</div><!--end .offcanvas-->
			<!-- END OFFCANVAS LEFT -->

			<!-- BEGIN CONTENT-->
            <div id="">
                <section>                   
                    <div class="section-body">
                       <div class="row encabezadoPlanInspeccion">
                            <div class="col-xs-10">
                                <!-- titulo Formulario -->
                                <div class="col-xs-12 text-center gris57 LetraBold">
                                    <h2> FUERZA AÉREA COLOMBIANA </h2>
                                </div>
                                <!-- titulo Formulario -->
                                <div class="col-xs-12 text-center gris57 LetraBold">
                                    <h3> JEFATURA LOGÍSTICA</h3>
                                </div>
                                <!-- titulo Formulario -->
                                <div class="col-xs-12 text-center azul8080">
                                    <h4> OFICINA CERTIFICACIÓN AERONÁUTICA DE LA DEFENSA</h4>
                                </div>
                            </div>
                            <div class="col-xs-2 logoSecad">
                                <img src="../img/logo_secad.png"/>
                            </div>
                        </div><!--end .row -->
                                                
                        <?php if($permiso->consultar == 1): ?>
                    
                        <!-- PRIMER BLOQUE DE INFOMACION -->
                        <div class="row">                            
                            <div class="col-xs-12 text-center gris57">
                                <h4> Informe Capacidades Aeronáuticas Empresas Colombianas</h4>
                            </div>                           
                            <!-- Responsable Proceso -->
                            <div class="col-xs-12 filaFormulario table-fixed">
                                <table class="table  table-x ">
                                  <tr class="azul8080">
                                        <th class="th-x" style="text-align: center;"> Capacidad u Oferta Sector Aeronáutico</th>
                                      
                                        <th class="th-x" style="text-align: center;">  Cantidad Empresas</th>
                                      
                                        <th class="th-x" style="text-align: center;"> Porcentaje % </th>
                                  </tr>
                                   <?php if(count($ofertasSectorAeronautico) != 1): ?>
                                   <?php $__currentLoopData = $ofertasSectorAeronautico; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ofertasSectorAeronauticoR): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="line-a">
                                        <td class="th-x"><?php echo e($ofertasSectorAeronauticoR->OfertaComercial); ?></td>
                                        <td class="th-x" style="text-align: center;"><?php echo e($ofertasSectorAeronauticoR->Cantidad); ?></td>
                                        <td class="th-x" style="text-align: center;"><?php echo e($ofertasSectorAeronauticoR->Porcentaje); ?> %</td>
                                    </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   <?php endif; ?>
                                   <tr class="azul8080">
                                        <th class="th-x" style="text-align: center;"> TOTAL (Capacidades x Empresas) = </th>
                                      
                                        <th class="th-x" style="text-align: center;"> <?php echo e($total); ?> </th>
                                      
                                        <th class="th-x" style="text-align: center;"> 100% </th>
                                  </tr>
                                </table>
                            </div>
                        </div><!--end .row -->
                        <br>
                        
                        

                        <br><br>

                        <a href="<?php echo e(route('informeofertassectoraeronautico.create')); ?>" style="width: 150px; font-style: Roboto;" class="btn btn-primary btn-block editbutton pull-left"><span class="fa fa-download">    Descargar PDF</span></a>
                        <?php endif; ?>
                        
                    </div><!--end .section-body -->                   
                </section>
            </div><!--end #content-->
            <!-- END CONTENT -->

            	
        </div>
    </div>

        

		<?php echo Form::close(); ?>

		<?php $__env->stopSection(); ?>

	<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/fomento/sectorAeronautico/informes/visual_informe_ofertas_sector_aeronautico.blade.php ENDPATH**/ ?>