<?php $__env->startSection('title'); ?>
	Informe Costo H/H
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>

		<?php $__env->startSection('form-tag'); ?>

	    <?php echo Form::model($personalhh); ?>

        <?php echo e(csrf_field()); ?>


		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-title'); ?>
			
            <?php echo e(Breadcrumbs::render('informecostohh')); ?>

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>       

		<div class="card-body floating-label">
		<!-- BEGIN BASE-->
		<div id="">

			<!-- BEGIN OFFCANVAS LEFT -->
			<div class="offcanvas">
			</div><!--end .offcanvas-->
			<!-- END OFFCANVAS LEFT -->

			<!-- BEGIN CONTENT-->
            <div id="">
                <section>                   
                    <div class="section-body">
                       <div class="row encabezadoPlanInspeccion">
                            
                            <!-- titulo Formulario -->
                            <div class="col-xs-12 text-center gris57 LetraBold">
                                <h2> FUERZA AÉREA COLOMBIANA </h2>
                            </div>
                            <!-- titulo Formulario -->
                            <div class="col-xs-12 text-center gris57 LetraBold">
                                <h3> JEFATURA DE OPERACIONES LOGÍSTICAS AERONÁUTICAS</h3>
                            </div>
                            <!-- titulo Formulario -->
                            <div class="col-xs-12 text-center azul8080">
                                <h4> SECCION DE CERTIFICACIÓN AERONAUTICO DE LA DEFENSA</h4>
                            </div>
                            
                        </div><!--end .row -->
                                                
                    
                    
                        <!-- PRIMER BLOQUE DE INFOMACION -->
                        <div class="row">                            
                            <div class="col-xs-12 text-center gris57">
                                <h4> Total Personal</h4>
                            </div>                            
                            <!-- FIN Div-->                       
                            <!-- Responsable Proceso -->
                            <div class="col-xs-12 filaFormulario table-fixed">
                                <table class="table  table-x ">
                                  <tr class="fondoAzulOscuro blanco">
                                        <th class="th-x"> Grado </th>
                                      
                                        <th class="th-x" > Apellido </th>
                                      
                                        <th class="th-x" > Nombre </th>
                                      
                                        <th class="th-x" > CC </th>
                                        
                                        <th class="th-x" > Costo H/H  </th>
                                  </tr>
                                   <?php if(count($personalhh) != 0): ?>
                                   <?php $__currentLoopData = $personalhh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personalR): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                   <?php if($permiso->consultar == 1): ?>                          
                                    <tr class="line-a">  
                                        <th class=""><?php echo e($personalR->Abreviatura); ?></th>                                       
                                        <th class=""><?php echo e($personalR->Apellidos); ?></th>
                                        <th class=""><?php echo e($personalR->Nombres); ?></th>
                                        <th class=""><?php echo e($personalR->Cedula); ?></th>                                        
                                        <th class=""><?php echo e($personalR->H_H); ?></th>
                                    </tr>  
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                      <?php else: ?>
                                      <div class="section-body">
                                        <div class="text-center">
                                            <h3>No hay datos para mostrar informe</h3>
                                        </div>
                                      </div>
                                    <?php endif; ?>                               
                                </table>
                            </div>
                        </div><!--end .row -->                                                            
                    </div><!--end .section-body -->                   
                </section>
            </div><!--end #content-->
            <!-- END CONTENT -->
            <?php if($permiso->consultar == 1): ?>
            <input name="Imprimir"  type="submit" id="btnExportToPDF" value="Descargar PDF" onclick="pdfToHTML()"/>			
            <?php endif; ?>
        </div>
    </div>

        <script>            
            function pdfToHTML (){
                $('html, body').animate({scrollTop:0}, 'fast');
                setTimeout("pdfToHTML2()",50);
                
            }
            function pdfToHTML2(){                                
                var pdf = new jsPDF('p', 'pt', 'letter');
                var options = {
                     pagesplit: true
                };
                 pdf.addHTML($('#contentReport')[0], options, function () {
                     pdf.save('INFORME DE INSPECCION.pdf');
                 });
            }       
        </script>

		<?php echo Form::close(); ?>

		<?php $__env->stopSection(); ?>

	<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/gestionRecursos/recursoHumano/informes/visual_informe_personal_hh.blade.php ENDPATH**/ ?>