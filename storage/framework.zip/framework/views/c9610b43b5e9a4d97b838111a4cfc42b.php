<?php $__env->startSection('title'); ?>
	Programas - Informe LA-FR 212
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>
		<?php $__env->startSection('card-title'); ?>
		<?php echo e(Breadcrumbs::render('programa')); ?>

		<!-- Begin Modal -->
		
		


		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>

		<div class="col-lg-12 text-center" >
			 <div class="row encabezadoPlanInspeccion">
                            
				<div class="col-xs-12 text-center">
                        <h3>OFICINA CERTIFICACION AERONAUTICA DE LA DEFENSA - SECAD</h3>
                        <div> 
                            <h4>SEGUIMIENTO PROGRAMAS </h4>
                        </div>                        
				</div>
			<div class="col-lg-12">
			<div class="table-responsive">
				<table id="example" class="table table-striped table-hover">
					<thead>
						<tr>
							<th><b>Consecutivo</b></th>
							<th><b>Proyecto</b></th>
							
							<th><b>Observaciones</b></th>

							

							<th style="width: 120px;" colspan = "1" class="text-center"><b>Ver Informe</b></th>
							<th style="width: 100px;" colspan = "1" class="text-center"><b>Descargar Evidencias</b></th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $programa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($permiso->consultar == 1): ?>
						<tr>
							<td><?php echo e($programas->Consecutivo); ?></td>
							<td><?php echo e($programas->Proyecto); ?></td>
							
							<td>
								<div class="col-sm-6">

									<a href="<?php echo e(route('obsercavionesfr212.show', $programas->IdPrograma)); ?>" class="btn btn-primary btn-block editbutton"><div class="gui-icon"><i class="fa fa-search"></i></div></a>

								</div>
							</td>
							
							<td>
								


								

								<div class="col-sm-6">
									<button type="button" class="btn btn-primary btn-block editbutton" onclick="informe(<?php echo e($programas->IdPrograma); ?>)"><div class="gui-icon"><i class="fa fa-search"></i></div></button>

								</div>
								

							</td>
							<td style="padding-left: 30px;">
    <div class="col-sm-6">
        <form id="copyFolderForm" action="<?php echo e(route('descargar-carpeta-directa', ['consecutivo' => $programas->Consecutivo])); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="button" class="btn btn-primary btn-block editbutton" onclick="descargarCarpeta('<?php echo e($programas->Consecutivo); ?>')">
                <div class="gui-icon"><i class="fa fa-download"></i></div>
            </button>
        </form>
    </div>
</td>


							
						</tr>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>

				<div class="text-center">
				
				</div>



			</div><!--end .table-responsive -->
		</div><!--end .col -->

		<div id="lafr212Modal" class="modal-box">
			<div class="modal-box-inner">
				<div class="modal-box-content modal-box-lg1 modal-box-h95">
					<div class="modal-box-header">
						<h3 class="modal-box-title">Informe</h3>
						<span class="close-modal" onclick="document.getElementById('lafr212Modal').style.display='none'"><i class="fa fa-times-circle"></i></span>
					</div>
					<div class="modal-box-body">
						<iframe id="iframe" width="100%"></iframe>
					</div>
					<div class="modal-box-footer">
        				<button type="button" class="btn btn-danger" onclick="document.getElementById('lafr212Modal').style.display='none'">Cerrar</button>
        				<button type="button" class="btn btn-primary"><a id="larfr212Descargar" href="" style="text-decoration: none;">Descargar</a></button>
    				</div>
				</div>
			</div>
		</div>

		<?php $__env->stopSection(); ?>


	<?php $__env->stopSection(); ?>

	<style>
		#iframe {
    		height: calc(100% - 2px);
		}
    </style>

<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

<script>
     function descargarCarpeta(consecutivo) {
        // Puedes usar Ajax para manejar la respuesta del controlador
        $.ajax({
            url: `/descargar-carpeta-zip/${consecutivo}`,
            type: 'GET',
            success: function(response) {
                // Verificar si hay un error en la respuesta
                if (response.status == false) {
                    Swal.fire({
                                        icon: 'error',
                                        title: 'INFO',
                                        html: response.mensaje,
                                        confirmButtonText: 'Aceptar',
                                        confirmButtonColor: "#3085d6"
                                    });
                } else {
                    // Lógica para manejar la respuesta exitosa
                    // Por ejemplo, podrías redirigir o realizar otras acciones
					window.location.href = `/descargar-carpeta-zip/${consecutivo}`;
                }
            },
            error: function(error) {
                console.error('Error en la solicitud Ajax:', error);
            }
        });
    }
	
</script>
<script>
	$(document).ready(function(){
		$('#example').DataTable({
			"order": [[ 0, "desc" ]]
		});
	});
</script>
<script>
	function informe(id) {
		var url = '<?php echo e(route("lafr212.informe.preview", ":id")); ?>';
      	url = url.replace(':id', id) + '#zoom=100&toolbar=0';
		document.getElementById('iframe').src = url;

		var url_descargar = '<?php echo e(route("lafr212.informe", ":id")); ?>'
		url_descargar = url_descargar.replace(':id', id);
		document.getElementById('larfr212Descargar').href = url_descargar;

		document.getElementById('lafr212Modal').style.display = 'block';
	};
</script>

<script>
	function informe(id) {
		var url = '<?php echo e(route("lafr212.informe.preview", ":id")); ?>';
      	url = url.replace(':id', id) + '#zoom=100&toolbar=0';
		document.getElementById('iframe').src = url;
		var url_descargar = '<?php echo e(route("lafr212.informe", ":id")); ?>'
		url_descargar = url_descargar.replace(':id', id);
		document.getElementById('larfr212Descargar').href = url_descargar;
		document.getElementById('lafr212Modal').style.display = 'block';
	};
</script>

<?php $__env->stopSection(); ?>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/certificacion/programasSECAD/seguimientoProgramas/ver_informe_LA_FR_212.blade.php ENDPATH**/ ?>