<?php $__env->startSection('title'); ?>
Asignar Usuarios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addcss'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"> </script>
<style media="screen">
.floating-label h2 {
	border-bottom: solid 1px #2a2a2a2a;
	padding-bottom: 1rem;
	text-transform: uppercase;
	font-weight: 500;
	color: #295484;
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('card-content'); ?>

<?php $__env->startSection('card-title'); ?>

<?php echo e(Breadcrumbs::render('asignar_usuario')); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('card-content'); ?>

<h2>
	<div class="form-group">
		<b><?php echo e($persona->Nombres); ?>  <?php echo e($persona->Apellidos); ?> </b>
	</div>
</h2>

<?php echo Form::open(array('route' => 'asignarusuario.store')); ?>


		<?php echo e(csrf_field()); ?>


		<input type="hidden" name="nombres" value="<?php echo e($persona->Nombres); ?>" >
		<input type="hidden" name="apellidos" value="<?php echo e($persona->Apellidos); ?>">
		<input type="hidden" name="email" value="<?php echo e($persona->Email); ?>">
		<input type="hidden" name="IdPersonal" value="<?php echo e($persona->IdPersonal); ?>">


<div class="row">

	<div style="margin-top: 60px; margin-bottom: 60px;" class="card-body floating-label">

		<div class="row">
			<div class="col-lg-12" style="font-size: 1.5rem;padding-bottom: 2rem;">
				<h2>Asignar Roles</h2>
					Selecciona o elimina los roles a asignar para el usuario:
			</div>

			<div class="col-sm-4">
				<div class="form-group">
					<?php echo e(Form::select('idrole', $roles->prepend('none')->pluck('name', 'id'), null, ['class' => 'form-control', 'id' => 'rol'])); ?>

					<label for="roles">Roles</label>
				</div>
			</div>

		<div class="col-sm-8">
			<div class="form-group">
				<?php ($json_cadena = json_encode($cadena)); ?>
				<input type="hidden" name="roles" id="roles" value="<?php echo e($json_cadena); ?>">
				<button type="button" class="btn btn-primary" style="margin-bottom:2rem;" id="add_rol" onclick="addrol()">Agregar</button>
			</div>
		</div>

		<div class="col-sm-12">
			<ul id="list_roles">
			 <?php ($cant = count($cadena)); ?>
				 <?php if($cant>0): ?>
				 <?php for($i=0; $i < $cant; $i++): ?>
				 <li id="rol_<?php echo e($cadena[$i]['nn']); ?>"><pre><?php echo e($cadena[$i]['texto']); ?></pre><button type="button" class="close remove_item" onclick="list_remove('rol_<?php echo e($cadena[$i]['nn']); ?>')" aria-label="Close"><span aria-hidden="true">&times;</span></button></li>
				 <?php endfor; ?>
				<?php else: ?>
					Aún no hay roles.
				<?php endif; ?>
			</ul>
		</div>

		<div class="col-lg-12">
			<h2>Cambiar Contraseña</h2>
		</div>

			<div class="col-sm-4">
				<div class="form-group">
					<input class="form-control" type="password" name="password">
					<label for="password">Contraseña</label>
				</div>
			</div>

			<div class="col-sm-4">
				<div class="form-group">
					<input class="form-control" type="password" name="passwordverify">
					<label for="password">Verificar Contraseña</label>
				</div>
			</div>
		</div>

	</div>

	<div  class="row">
		<div class="col-sm-6">
			<?php echo e(Form::submit('Guardar', ['class' => 'btn btn-info btn-block'])); ?>

		</div>
		<div class="col-sm-6">
			<button type="button" onclick="window.location='<?php echo e(route("asignarusuario.index")); ?>'" style="" class="btn btn-danger btn-block">Cancelar</button>
		</div>
	</div>

</div>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('addjs'); ?>


<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>

<script src="<?php echo e(URL::asset('js/edit.js')); ?>"></script>

<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>



<script>
	$(document).ready(function(){
		$('#datatable1').DataTable();
	});

	//AGREGAR BASE DE CERTIFICACIÓ

	function addrol(){
		console.log('si coge');
		var titulo = $('select[id=rol]');

		var cadena = $('#roles').val();

		if (titulo.val() == '') {
			var html = '<div class="alert alert-warning alert-dismissible show" role="alert" id="alert_rol"><strong>Cuidado!</strong> Faltan campos por llenar.<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>';
			$('#add_rol').after(html);

		} else {
			var texto = $('#rol option[value='+titulo.val()+']').html();
			if (cadena == '')
			{
					cadena = [];
			}
			else {
					cadena = JSON.parse(cadena);
			}
			var sw=0;
			$.each(cadena, function(index, value){
				if(value['id']==titulo.val()){
					sw=1;
				}
			})
			if(sw==1){
				alert('El rol '+texto+' ya se encuentra asignado.')
			}
			else{
				var dato = {nn: cadena.length+1 ,id:titulo.val(), texto:texto};
				cadena.push(dato);
			}

			$('#roles').val(JSON.stringify(cadena));
			var html = '';
			$.each(cadena, function(index, value){

				var tx = value['texto'];
				var id = value['nn'];
					var item = '<li id="rol_'+id+'"><pre>'+tx+'</pre><button type="button" class="close remove_item" onclick="list_remove(\'rol_'+id+'\')" aria-label="Close"><span aria-hidden="true">&times;</span></button></li>';
					html = html+item;
			})
			$('#list_roles').html(html);
			titulo.val('');
			$('#alert_rol').remove();
		}
	}
	function list_remove(valor) {
		var ini = valor.split('_');
		var item_remove = parseInt(ini[1]);
		var old_list = $('#roles').val();
		var new_list = [];
		var cadena = JSON.parse(old_list);
		var i = 1;
		var html = '';
		$.each(cadena, function(index, value){

			if(parseInt(value['nn']) == item_remove){
				console.log('Removido item: '+item_remove+' '+value['texto']);
			}else{
				var tx = value['texto'];
				var tt = value['id'];
				var id = i;
				var item = '<li id="rol_'+id+'"><pre>'+tx+'</pre><button type="button" class="close remove_item" onclick="list_remove(\'rol_'+id+'\')" aria-label="Close"><span aria-hidden="true">&times;</span></button></li>';
				html = html+item;
				i++;
				var dato = {nn:id ,id:tt, texto:tx};
				new_list.push(dato);
			}
		})
		$('#roles').val(JSON.stringify(new_list));
		$('#list_roles').html(html);

		if ($('#list_roles li').length == 0) {
			$('#list_roles').html('Aún no hay roles.');
		}
	}




</script>



<?php $__env->stopSection(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/gestionRecursos/recursoHumano/asignar_usuarios.blade.php ENDPATH**/ ?>