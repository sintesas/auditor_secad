<?php $__env->startSection('title'); ?>
Actividades Tipos Programa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('card-content'); ?>
<?php $__env->startSection('card-title'); ?>
<?php echo e(Breadcrumbs::render('actividadesSeguimiento', $programa->IdPrograma)); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('card-content'); ?>

<div class="col-lg-12">
	<div class="table-responsive">
		<h4><strong>Programa:</strong> <?php echo e($programa->Consecutivo); ?> / <strong>Tipo Programa:</strong> <?php echo e($tipoPrograma->Tipo); ?></h4>
		<table id="datatable1" class="table table-striped table-hover">
			<thead>
				<tr>
					<th style="display: none;"><b>Id</b></th>							
					<th><b>Actividad</b></th>
					<th><b>Responsable</b></th>
					<th style="width: 120px;"><b>Evidencias</b></th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $actividades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td style="display: none;"><?php echo e($actividad->IdActividad); ?></td>
					<td><?php echo e($actividad->Actividad); ?></td>
					<td><?php echo e($actividad->Responsable); ?></td>
					
					<td>						
						<div class="col-sm-6">
							<a href="<?php echo e(route('seguimientoActividades.show', $actividad->IdActividad . '&' . $programa->IdPrograma)); ?>" class="btn btn-primary btn-block editbutton" ><div class="gui-icon"><i class="fa fa-pencil"></i></div></a>
						</div>

						

					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div><!--end .table-responsive -->
</div><!--end .col -->

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>

<script>
	$(document).ready(function(){
		$('#datatable1').DataTable();
	});
</script>

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/certificacion/programasSECAD/seguimientoProgramas/ver_lista_seguimiento_actividades.blade.php ENDPATH**/ ?>