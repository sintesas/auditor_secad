<?php $__env->startSection('title'); ?>
    Criterios
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('card-content'); ?>
<?php $__env->startSection('card-title'); ?>
<?php echo e(Breadcrumbs::render('criterios')); ?>

<!-- Begin Modal -->
<?php if($rol): ?>
<?php if($permiso->crear == 1): ?>
  <button type="button" onclick="document.getElementById('id1').style.display='block'"
        style="margin-left:800px;" class="btn btn-info ink-reaction btn-primary addbutton" id="myBtn">
<?php endif; ?>
<?php endif; ?>
  <span class="fa fa-plus"></span></button>


<!-- Section Dowload-->

<!-- END  Section Dowload-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('card-content'); ?>

<div class="col-lg-12">
  <div class="table-responsive">
    <!-- BEGIN STRUCTURE  -->
    <div class="row">
      <div class="col-md-12">
        <div class="panel-group" id="accordion1">
          <div class="">
            
            <div id="accordion1-1" class="collapse in">
              <div class="col-lg-12">
                <div class="table-responsive">
                  <table id="datatable1" class="table table-striped table-hover">
                    <thead>
                      <tr>
                        <th style="width: 150px;"><b>Nombre Criterio</b></th>
                        <th style="width: 150px;"><b>Proceso</b></th>
                        <th style="width: 150px;"><b>Sub-Proceso</b></th>
                        <th style="width: 120px;"><b>Acción</b></th>

                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $criterios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($permiso->consultar == 1): ?>
                      <tr>
                        <td><?php echo e($item->Norma); ?></td>
                        <td><?php echo e($item->Proceso); ?></td>
                        <td><?php echo e($item->SubProceso); ?></td>
                        <td>
                        <?php if($permiso->eliminar == 1): ?>
                            <div class="col-sm-6">

                            <?php echo Form::open(['route' => ['criteriosAuditoria.destroy', $item->IdCriterio], 'method' => 'DELETE']); ?>


                            <?php echo Form::submit('x', ['class' => 'btn btn-danger deleteButton']); ?>


                            <?php echo Form::close(); ?>

                          </div>
                        <?php endif; ?>
                        <?php if($permiso->actualizar == 1): ?>
                          <div class="col-sm-6">
                            <a href="<?php echo e(route('criteriosAuditoria.edit', $item->IdCriterio)); ?>" class="btn btn-primary btn-block editbutton">
                              <div class="gui-icon"><i class="fa fa-pencil"></i></div>
                            </a>
                          </div>
                        <?php endif; ?>
                        </td>
                      </tr>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                </div>
                <!--end .table-responsive -->
              </div>
              <!--end .col -->
            </div>
            <?php echo Form::close(); ?>

          </div>
        </div>
        <!--end .panel -->
      </div>
      <!--end .panel-group -->
    </div>
    <!--end .col -->
  </div>
  <!--end .row -->
  <!-- END STRUCTURE -->
</div>
<!--end .table-responsive -->




<div id="id1" class="modal" style="padding-top:80px;">

  <div class="modal-content" style="width:60%;">

    <div class="card-head style-primary">
      <header>Crear Nuevo Proyecto</header>
      <span style="margin-right: 20px;" onclick="document.getElementById('id1').style.display='none'" class="close">x</span>
    </div>

    <div class="card">
      <div class="card-body floating-label">

        <?php echo Form::open(array('route' => 'criteriosAuditoria.store')); ?>


        <?php echo e(csrf_field()); ?>


        <div class="card">
          <div class="card-body">

            <div class="row">
               <div class="col-sm-12">
                    <div class="form-group">
                    <input type="text" class="form-control" id="Norma" name="Norma" required>
                    <label for="Norma">Norma *</label>
                    </div>
               </div>
                <div class="col-sm-12">
                    <div class="form-group">
                        <input type="text" class="form-control" id="Proceso" name="Proceso" required>
                        <label for="Proceso">Proceso *</label>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="form-group">
                        <input type="text" class="form-control" id="SubProceso" name="SubProceso" required>
                        <label for="SubProceso">Sub-Proceso *</label>
                    </div>
                </div>
            </div>

          </div>
        </div>
        
        <div class="row">
          <div class="col-sm-6">
            <button type="submit" style="" class="btn btn-info btn-block">Crear</button>
          </div>
          <div class="col-sm-6">
            <button type="button" onclick="document.getElementById('id1').style.display='none'" style="" class="btn btn-danger btn-block">Cancelar</button>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>




<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>
<script>
  $(document).ready(function() {
    $('#datatable1').DataTable();
  });
</script>

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/auditoria/crear_criterios.blade.php ENDPATH**/ ?>