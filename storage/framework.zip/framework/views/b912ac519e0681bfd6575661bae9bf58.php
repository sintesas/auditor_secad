<?php $__env->startSection('title'); ?>
	Programas - Informe Contratos por Año
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>
		<?php $__env->startSection('card-title'); ?>
		
		<!-- Begin Modal -->
		
		


		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>
			<div class="col-lg-12 text-center" >
			 <div class="row encabezadoPlanInspeccion">
                            
				<div class="col-xs-12 text-center">
                        <h3>OFICINA CERTIFICACIÓN AERONÁUTICA DE LA DEFENSA - SECAD</h3>
                        <div>
                            <h4>CONTRATACIÓN ANUAL</h4>
                        </div>                        
				</div>
			<div class="col-lg-12">
			<div class="table-responsive">
				<table id="example" class="table table-striped table-hover" border="1">
					<thead>
						<tr>
							<th class="text-center"><b>AÑO</b></th>
							<th class="text-center"><b>CANTIDAD CONTRATOS</b></th>
							<th class="text-center"><b>PRESUPUESTO ANUAL</b></th>
							<th class="text-center"><b>ACCIÓN</b></th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $contrat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vwcontra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($permiso->consultar == 1): ?>
						<tr>
							<td class="text-center"><?php echo e($vwcontra->Vigencia); ?></td>
							<td class="text-center"><?php echo e($vwcontra->CANT); ?></td>
							<td class="text-center"><?php echo e($vwcontra->VATOPRE); ?></td>
							
							<td class="text-right">
								<div class="col-lg-6 text-right">

									<a href="<?php echo e(route('InformeContratosA.show', $vwcontra->Vigencia)); ?>" class="btn btn-primary btn-block editbutton text-center" alt="Ir al Detalle"><div class="gui-icon" ><i class="fa fa-search"></i></div></a>

								</div>
							</td>
						
						 </tr>
						 <?php endif; ?>
						 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>

				<div class="text-center">
				
				</div>



			</div><!--end .table-responsive -->
		</div><!--end .col -->

		<?php $__env->stopSection(); ?>


	<?php $__env->stopSection(); ?>

<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>

<script>
	$(document).ready(function(){
		$('#datatable1').DataTable({
			"order": [[ 0, "desc" ]]
		});
		
	});
</script>

<?php $__env->stopSection(); ?>
	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/Normogramaycontratos/Contratos/ver_informe_contratoAnual.blade.php ENDPATH**/ ?>