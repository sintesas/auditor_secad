<?php $__env->startSection('title'); ?>
	Editar Personal
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>

		<?php $__env->startSection('form-tag'); ?>

			<?php echo Form::model($personal, ['route' => ['personal.update', $personal->IdPersonal], 'method' => 'PUT', 'files' =>true ]); ?>


			<?php echo e(csrf_field()); ?>


		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-title'); ?>
			<?php echo e(Breadcrumbs::render('editar_personal')); ?>

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>

			<div class="card-body floating-label">
				<div class="card">
                <div class="card-head card-head-sm style-primary">
                    <header>
                        Información Personal
                    </header>
                </div><!--end .card-head -->
                <div class="card-body">
                   <div class="row">
                        <div class="col-sm-4">
                            <div class="foto-personal">
                                
                                <img id="image_upload_preview" src="<?php echo e(URL::asset('secad/Personal/Fotos/' . $personal->Cedula . '/' . $personal->Foto)); ?>" alt="profile Pic">
                            </div>

                        </div>
                        <div class="col-sm-8">
                            <div class="form-group">
                                <label for="foto">Foto</label>
                               <?php echo Form::file('foto', array('class' => 'form-control', 'id' => 'inputFile')); ?>

                               
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" class="form-control" id="Nombres" name="Nombres" required value="<?php echo e(old('Nombres', $personal->Nombres)); ?>">
                                <label for="Nombres">Nombres</label>
                            </div>
                        </div>                        
                        <div class="col-sm-6">
                            <div class="form-group">
                                <input type="text" class="form-control" id="Apellidos" name="Apellidos" required value="<?php echo e(old('Apellidos', $personal->Apellidos)); ?>">
                                <label for="Apellidos">Apellidos</label>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-sm-4">
                            <div class="form-group">
                                <?php echo e(Form::select('IdTipoDoc', $tipodoc->pluck('NombreTipoDoc', 'IdTipoDoc'), null, ['class' => 'form-control', 'id' => 'IdTipoDoc'])); ?>

                                <label for="IdTipoDoc">Tipo Documento </label>
                            </div>
                        </div> 
                        <div class="col-sm-4">
                            <div class="form-group">
                                <input type="text" class="form-control" id="Cedula" name="Cedula" required value="<?php echo e(old('Cedula', $personal->Cedula)); ?>">
                                <label for="Cedula">Número de Documento</label>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="form-group">
                                <input type="text" class="form-control" id="LugarExpedicion" name="LugarExpedicion" required value="<?php echo e(old('Lugarexpedicion', $personal->Lugarexpedicion)); ?>">
                                <label for="LugarExpedicion"> Lugar de Expedición</label>
                            </div>
                        </div>  
                    </div>

                    <div class="row">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input type="text" class="form-control" id="LugarNacim" name="LugarNacim" required value="<?php echo e(old('LugarNacim', $personal->LugarNacim)); ?>">
                                <label for="LugarNacim"> Lugar de nacimiento </label>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <div class="input-group date" id="demo-date-format">
                                    <div class="input-group-content">
                                        <input type="text" class="form-control" id="FechaNacim" name="FechaNacim" required value="<?php echo e(old('FechaNacim', $personal->FechaNacim)); ?>">
                                        <label for="FechaNacim"> Fecha de nacimiento </label>
                                    </div>
                                    <span class="input-group-addon"></span>
                                </div>  
                            </div>
                        </div>
                        <div class="col-xs-3">
                            <div class="form-group">
                                <input type="text" class="form-control" id="Edad" name="Edad" required readonly value="<?php echo e(old('Edad', $personal->Edad)); ?>">
                                <label for="Edad"> Edad </label>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <input type="Email" class="form-control" id="Email" name="Email" required value="<?php echo e(old('Email', $personal->Email)); ?>">
                                <label for="Email"> Email FAC</label>
                            </div>
                        </div>
                    </div>

                     <div class="row">
                         <div class="col-sm-3">
                            <div class="form-group">
                                <input type="Email" class="form-control" id="EmailPersonal" name="EmailPersonal" required value="<?php echo e(old('EmailPersonal', $personal->EmailPersonal)); ?>">
                                <label for="EmailPersonal"> Email Personal</label>
                            </div>
                        </div>   
                        <div class="col-sm-3">
                            <div class="form-group">                                
                                <?php echo e(Form::select('Categoria', [
                                                        '' => '',
                                                        'Civil' => 'Civil',
                                                        'Militar' => 'Militar'
                                                    ], null, ['class' => 'form-control', 'id' => 'Categoria'])); ?>

                                <label for="Categoria">Tipo Personal</label>
                            </div>
                        </div> 
                        <div class="col-sm-6">
                                <div class="form-group">
                                    <input type="checkbox" id="TodosProgramas" name="TodosProgramas" <?php if($personal->TodosProgramas == 1): ?> checked <?php endif; ?>>
                                    <label for="TodosProgramas">Ve todos los programas</label>                            
                                </div>
                            </div>
                    </div> 
                </div><!--end .card-body -->
            </div>

            <div class="card" id="infoCivil">
                <div class="card-head card-head-sm style-primary">
                    <header>
                        Información Civil
                    </header>
                </div><!--end .card-head -->
                <div class="card-body">                                                                                
                    <div class="row">
                        <div class="col-xs-6">
                            <div class="form-group">
                                <?php echo e(Form::select('IdEmpresa', $empresa->pluck('NombreEmpresa', 'IdEmpresa'), null, ['class' => 'form-control', 'id' => 'IdEmpresa'])); ?>

                                <label for="IdEmpresa">Organización </label>
                            </div>
                        </div>
                        <div class="col-xs-6">
                            <div class="form-group">
                                <input type="text" class="form-control" id="DependeciaFacultad" name="DependeciaFacultad" value="<?php echo e(old('DependeciaFacultad', $personal->DependeciaFacultad)); ?>">
                                <label for="DependeciaFacultad">Dependencia/Facultad</label>
                            </div>
                        </div>
                                               
                        
                    </div>

                    <div class="row">
                        <div class="col-xs-6">
                            <div class="form-group">
                                <?php echo e(Form::select('IdCarreraProfesion', $profesiones->pluck('CarreraProfesion', 'IdCarreraProfesion'), null, ['class' => 'form-control', 'id' => 'IdCarreraProfesion'])); ?>

                                <label for="IdCarreraProfesion">Profesion/Carrera</label>
                            </div>
                        </div> 
                        <div class="col-xs-6">
                            <div class="form-group">
                                <input type="text" class="form-control" id="Escolaridad" name="Escolaridad" value="<?php echo e(old('Escolaridad', $personal->Escolaridad)); ?>">
                                <label for="Escolaridad"> Escolaridad </label>
                            </div>
                        </div>
                    </div>

                    <div class="row">

                         
                        <div class="col-xs-6">
                            <div class="form-group">
                                <?php echo e(Form::select('IdCargo', $cargos->pluck('Cargo', 'IdCargo'), null, ['class' => 'form-control', 'id' => 'IdCargo'])); ?>

                                <label for="IdCargo"> Cargo </label>
                            </div>
                        </div> 
                        <div class="col-xs-6">
                            <div class="form-group">
                                <?php echo e(Form::select('IdNivelCompetencia', $nivelCompetencias->pluck('Denominacion', 'IdNivelCompetencia'), null, ['class' => 'form-control', 'id' => 'IdNivelCompetencia'])); ?>

                                <label for="IdNivelCompetencia"> Nivel Competencia SECAD </label>
                            </div>
                        </div> 

                    </div>
                    
                    <div class="row">
                        <div class="col-xs-6">
                            <div class="form-group">
                                
                                <textarea type="text" class="form-control" id="Experiencia" name="Experiencia"><?php echo e(old('Experiencia', $personal->Experiencia)); ?></textarea>
                                <label for="Experiencia"> Experiencia </label>
                            </div>
                        </div>
                        <div class="col-xs-6">
                            <div class="form-group">
                                <div class="input-group date" id="demo-date-format">
                                    <div class="input-group-content">
                                        <input type="text" class="form-control" id="FechaIncorporacionSecad" name="FechaIncorporacionSecad" value="<?php echo e(old('FechaIncorporacionSecad', $personal->FechaIncorporacionSecad)); ?>">
                                        <label for="FechaIncorporacionSecad">Fecha Incorporación SECAD</label>
                                    </div>
                                    <span class="input-group-addon"></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">                        
                        
                        <div class="col-xs-6">
                            <div class="form-group">
                                <?php echo e(Form::select('IdAreaExperiencia', $areasExperiencia->pluck('AreaExperiencian', 'IdAreaExperiencia'), null, ['class' => 'form-control', 'id' => 'IdAreaExperiencia'])); ?>

                                <label for="AreaSecad"> Area SECAD </label>
                            </div>
                        </div>
                        <div class="col-xs-6">
                            <div class="form-group">
                                <?php echo e(Form::select('IdSupervisor', $personal->pluck('Nombres' , 'IdPersonal'), null, ['class' => 'form-control', 'id' => 'IdSupervisor'])); ?>

                                <label for="IdSupervisor"> Supervisor SECAD </label>
                            </div>
                        </div>
                                              
                                                
                    </div>

                    <div class="row">                        
                        
                        <div class="col-xs-4">
                            <div class="form-group">
                                <input type="text" class="form-control" id="Celular" name="Celular" value="<?php echo e(old('Celular', $personal->Celular)); ?>">
                                <label for="Celular">Celular</label>
                            </div>
                        </div>                        
                        <div class="col-xs-4">
                            <div class="form-group">
                                <input type="text" class="form-control" id="Fijo" name="Fijo" value="<?php echo e(old('Fijo', $personal->Fijo)); ?>">
                                <label for="Fijo">Fijo</label>
                            </div>
                        </div>
                        <div class="col-xs-4">
                            <div class="form-group">
                                <input type="text" class="form-control" id="Oficina" name="Oficina" value="<?php echo e(old('Oficina', $personal->Oficina)); ?>">
                                <label for="Oficina"> Oficina </label>
                            </div>
                        </div>
                    </div>

                    <div class="row">                        
                        <div class="col-xs-4">
                            <div class="form-group">
                                <input type="text" class="form-control" id="PaisResidencia" name="PaisResidencia" value="<?php echo e(old('PaisResidencia', $personal->PaisResidencia)); ?>">
                                <label for="PaisResidencia">Pais</label>
                            </div>
                        </div>                            
                        <div class="col-xs-4">
                            <div class="form-group">
                                <div class="input-group date" id="demo-date-format">
                                <div class="input-group-content">
                                    <input type="text" class="form-control" id="FechaTermino" name="FechaTermino" value="<?php echo e(old('FechaTermino', $personal->FechaTermino)); ?>">
                                    <label for="FechaTermino">Fecha termino</label>
                                </div>
                                <span class="input-group-addon"></span>
                            </div>
                            </div>
                        </div> 
                        <div class="col-xs-4">
                            <div class="form-group">
                                <?php echo e(Form::select('EstadoCivil', [
                                                        '' => '',
                                                        'Soltero' => 'Soltero',
                                                        'Casado' => 'Casado',
                                                        'Union Libre' => 'Union Libre'
                                                    ], null, ['class' => 'form-control', 'id' => 'EstadoCivil'])); ?>

                                <label for="EstadoCivil"> Estado Civil </label>
                            </div>
                        </div>                
                    </div>

                    <div class="row">                        
                        
                        <div class="col-xs-6">
                            <div class="form-group">
                                <input type="text" class="form-control" id="DireccionResi" name="DireccionResi" value="<?php echo e(old('DireccionResi', $personal->DireccionResi)); ?>">
                                <label for="DireccionResi">Direccion Residencia</label>
                            </div>
                        </div>  
                        <div class="col-xs-6">
                            <div class="form-group">
                                <input type="text" class="form-control" id="Barrio" name="Barrio" value="<?php echo e(old('Barrio', $personal->Barrio)); ?>">
                                <label for="Barrio">Barrio</label>
                            </div>
                        </div>                        
                                                
                    </div>
                </div> 
            </div> 

            <div class="card" id="infoMilitar">
                <div class="card-head card-head-sm style-primary">
                    <header>
                        Información Militar
                    </header>
                </div><!--end .card-head -->
                <div class="card-body">  

                    <div class="row">
                        <div class="col-xs-3">
                            <div class="form-group">
                                 <?php echo e(Form::select('IdGrado', $grados->pluck('NombreGrado', 'IdGrado'), null, ['class' => 'form-control', 'id' => 'IdGrado'])); ?>

                                <label for="IdGrado">Grado </label>
                            </div>
                        </div>
                        <div class="col-xs-3">
                            <div class="form-group">
                                <input type="text" class="form-control" id="CodigoMilitar" name="CodigoMilitar" value="<?php echo e(old('CodMilitar', $personal->CodMilitar)); ?>">
                                <label for="CodigoMilitar">Codigo Militar</label>
                            </div>
                        </div>
                        <div class="col-xs-3">
                            <div class="form-group">
                                <input type="text" class="form-control" id="NFolio" name="NFolio" value="<?php echo e(old('NoFolioVida', $personal->NoFolioVida)); ?>">
                                <label for="NFolio">N. Folio de Vida</label>
                            </div>
                        </div>                        
                        
                    </div>



                    <div class="row">

                        <div class="col-xs-3">
                            <div class="form-group">
                                <?php echo e(Form::select('IdFuerza', $fuerzas->pluck('NombreFuerza', 'IdFuerza'), null, ['class' => 'form-control', 'id' => 'IdFuerza'])); ?>

                                <label for="IdFuerza"> Fuerza </label>
                            </div>
                        </div>
                        <div class="col-xs-3">
                            <div class="form-group">
                                
                                 <!--<select name="IdCuerpo" id="IdCuerpo" class="form-control"></select>-->
                                 <label id="lblCuerpo" for="IdCuerpo"> Cuerpo </label> 
                            </div>
                        </div> 

                        <div class="col-xs-3">
                            <div class="form-group">
                                <?php echo e(Form::select('IdEspecialidad1', $especialidades->pluck('NombreEspecialidad', 'IdEspecialidad'), null, ['class' => 'form-control', 'id' => 'IdEspecialidad1'])); ?>

                                <label for="EspPrimaria"> Esp. Primaria </label>
                            </div>
                        </div>
                        <div class="col-xs-3">
                            <div class="form-group">
                                <?php echo e(Form::select('IdEspecialidad2', $especialidades->pluck('NombreEspecialidad', 'IdEspecialidad'), null, ['class' => 'form-control', 'id' => 'IdEspecialidad2'])); ?>

                                <label for="EspSecundaria"> Esp. Secundaria </label>
                            </div>
                        </div>

                    </div>

                    <div class="row">
                        <div class="col-xs-6">
                            <div class="form-group">
                                <div class="input-group date" id="demo-date-format">
                                    <div class="input-group-content">
                                        <input type="text" class="form-control" id="FechaIncorporacion" name="FechaIncorporacion" value="<?php echo e(old('FechaIncorporacion', $personal->FechaIncorporacion)); ?>">
                                        <label for="FechaIncorporacion">Fecha Incorporación</label>
                                    </div>
                                    <span class="input-group-addon"></span>
                                </div>
                            </div>
                        </div>                        
                        <div class="col-xs-6">
                            <div class="form-group">
                                <div class="input-group date" id="demo-date-format">
                                    <div class="input-group-content">
                                        <input type="text" class="form-control" id="FechaAsense" name="FechaAsense" value="<?php echo e(old('FechaAsense', $personal->FechaAsense)); ?>">
                                        <label for="FechaAsense">Fecha Último Ascenso</label>
                                    </div>
                                    <span class="input-group-addon"></span>
                                </div>
                            </div>
                        </div>   
                    </div>

                    <div class="row">
                        <div class="col-xs-3">
                            <div class="form-group">
                                <?php echo e(Form::select('IdUnidad', $unidades->pluck('NombreUnidad', 'IdUnidad'), null, ['class' => 'form-control', 'id' => 'IdUnidad'])); ?>

                                <label for="IdUnidad"> Unidad </label>
                            </div>
                        </div>
                        <div class="col-xs-3">
                            <div class="form-group">
                                <?php echo e(Form::select('IdGrupo', $grupos->pluck('NombreGrupo', 'IdGrupo'), null, ['class' => 'form-control', 'id' => 'IdGrupo'])); ?>

                                <label for="GrupoJefa"> Grupo/Jefatura </label>
                            </div>
                        </div>
                         <div class="col-xs-3">
                            <div class="form-group">
                                <?php echo e(Form::select('IdTaller', $talleres->pluck('NombreTaller', 'IdTaller'), null, ['class' => 'form-control', 'id' => 'IdTaller'])); ?>

                                <label for="DependenciaTaller"> Dependencia/ Taller </label>
                            </div>
                        </div>
                        <div class="col-xs-3">
                            <div class="form-group">
                                <?php echo e(Form::select('IdEscuadron', $escuadrones->pluck('NombreEscuadron', 'IdEscuadron'), null, ['class' => 'form-control', 'id' => 'IdEscuadron'])); ?>

                                <label for="IdEscuadron">Escuadron</label>
                            </div>
                        </div>  
                    </div>

                     <div class="row">
                         <div class="col-xs-3">
                            <div class="form-group">
                                <?php echo e(Form::select('IdCarreraProfesion', $profesiones->pluck('CarreraProfesion', 'IdCarreraProfesion'), null, ['class' => 'form-control', 'id' => 'IdCarreraProfesionMil'])); ?>

                                <label for="IdCarreraProfesionMil"> Profesion </label>
                            </div>
                        </div>
                         <div class="col-xs-3">
                            <div class="form-group">
                                <?php echo e(Form::select('IdCargo', $cargos->pluck('Cargo', 'IdCargo'), null, ['class' => 'form-control', 'id' => 'IdCargoMil'])); ?>

                                <label for="IdCargoMil"> Cargo </label>
                            </div>
                        </div> 
                         <div class="col-xs-3">
                            <div class="form-group">
                               <?php echo e(Form::select('IdEspecialidadCertificacion', $espeCert->pluck('Especialidad', 'IdEspecialidadCertificacion'), null, ['class' => 'form-control', 'id' => 'IdEspecialidadCertificacion'])); ?>

                                <label for="IdEspecialidadCertificacion"> Especialidad Certificación </label>
                            </div>
                        </div>
                        <div class="col-xs-3">
                            <div class="form-group">
                                <?php echo e(Form::select('IdNivelCompetencia', $nivelCompetencias->pluck('Denominacion', 'IdNivelCompetencia'), null, ['class' => 'form-control', 'id' => 'IdNivelCompetenciaMil'])); ?>

                                <label for="IdNivelCompetenciaMil"> Nivel de competencia</label>
                            </div>
                        </div>  
                        
                    </div>
                    <input type="hidden" id="cuerpoId" value="<?php echo e($personal->IdCuerpo); ?>">
                </div>
			</div>

		  
		
			<div class="form-group">
				<div class="row">
					<div class="col-sm-6">
						<button type="submit" style="" class="btn btn-info btn-block">Actualizar</button>
					</div>
					<div class="col-sm-6">
						<button type="button" onclick="window.location='<?php echo e(route("personal.index")); ?>'" style="" class="btn btn-danger btn-block">Cancelar</button>
					</div>
				</div>
			</div>
			</div>

		<?php echo Form::close(); ?>


		<script type="text/javascript">
			$(window).bind("load", function() {
			   	var tipoPersonal = $( "#Categoria option:selected" ).val();
                $('#Categoria').attr('readonly', true);

                if(tipoPersonal == 'Militar'){
                    $('#infoMilitar').show();
                    $('#infoCivil').hide();

                    $("#infoMilitar input").prop('required',true);
                    $("#infoMilitar select").prop('required',true);
                    $('.select2-container input').prop('required',false);
                    $('#IdEspecialidad2').prop('required',false);
                    $('#IdEscuadron').prop('required',false);

                    $("#infoCivil input").prop('required',false);
                    $("#infoCivil select").prop('required',false);
                }
                else
                {
                    $('#infoMilitar').hide();
                    $('#infoCivil').show();

                    $("#infoMilitar input").prop('required',false);
                    $("#infoMilitar select").prop('required',false);

                    $("#infoCivil input").prop('required',true);
                    $("#infoCivil select").prop('required',true);
                    $('.select2-container input').prop('required',false);
                }

                if(tipoPersonal == ''){
                    $('#infoMilitar').hide();
                    $('#infoCivil').hide();

                    $("#infoMilitar input").prop('required',false);
                    $("#infoMilitar select").prop('required',false);

                    $("#infoCivil input").prop('required',false);
                    $("#infoCivil select").prop('required',false);

                    $('.select2-container input').prop('required',false);
                }

                var idgrado = $( "#IdGrado option:selected" ).val();
                $.get("../Cuerpos/" + idgrado + "", function(response, state){

                    $('#IdCuerpo').empty();
                    $('#IdCuerpo').append('<option value="" selected="selected"></option>');

                    for(i=0; i<response.length; i++){
                        $('#IdCuerpo').append('<option value="' + response[i].IdCuerpo + '">' +  response[i].NombreCuerpo + '</option>');
                    }

                var cuerpoId = $('#cuerpoId').val();
                $("#IdCuerpo option[value='" + cuerpoId + "']").attr("selected", true);

                var cuerpo = $( "#IdCuerpo option:selected" ).text();
                $("#select2-chosen-12").text(cuerpo);
                $("#lblCuerpo").css( "font-size", "12px" );
                });
			});


			$('#Categoria').change(function(event) {

                console.log(event.target.value);
                var tipoPersonal = event.target.value;

                if(tipoPersonal == 'Militar'){
                    $('#infoMilitar').show();
                    $('#infoCivil').hide();

                    $("#infoMilitar input").prop('required',true);
                    $("#infoMilitar select").prop('required',true);
                    $('.select2-container input').prop('required',false);
                    $('#IdEspecialidad2').prop('required',false);
                    $('#IdEscuadron').prop('required',false);

                    $("#infoCivil input").prop('required',false);
                    $("#infoCivil select").prop('required',false);
                }
                else
                {
                    $('#infoMilitar').hide();
                    $('#infoCivil').show();

                    $("#infoMilitar input").prop('required',false);
                    $("#infoMilitar select").prop('required',false);

                    $("#infoCivil input").prop('required',true);
                    $("#infoCivil select").prop('required',true);
                    $('.select2-container input').prop('required',false);
                }

                if(tipoPersonal == ''){
                    $('#infoMilitar').hide();
                    $('#infoCivil').hide();

                    $("#infoMilitar input").prop('required',false);
                    $("#infoMilitar select").prop('required',false);

                    $("#infoCivil input").prop('required',false);
                    $("#infoCivil select").prop('required',false);

                    $('.select2-container input').prop('required',false);
                }
			});

            /*GET Cuerpos By Grado*/
            $('#IdGrado').change(function(event) {

                $.get("../Cuerpos/" + event.target.value + "", function(response, state){

                    $('#IdCuerpo').empty();
                    $('#IdCuerpo').append('<option value="" selected="selected"></option>');

                    for(i=0; i<response.length; i++){
                        $('#IdCuerpo').append('<option value="' + response[i].IdCuerpo + '">' +  response[i].NombreCuerpo + '</option>');
                    }
                });
            });

			// Previw Img
            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();

                    reader.onload = function (e) {
                        $('#image_upload_preview').attr('src', e.target.result);
                    }

                    reader.readAsDataURL(input.files[0]);
                }
            }

            $("#inputFile").change(function () {
                readURL(this);
            });

            $("#Edad").focusin(function(){
                var fecha = $('#FechaNacim').val();
                var edad = calcularEdad(fecha);
                $('#Edad').val(edad);
            });

            // GET EDAD
            function calcularEdad(fecha) {
                var hoy = new Date();
                var cumpleanos = new Date(fecha);
                var edad = hoy.getFullYear() - cumpleanos.getFullYear();
                var m = hoy.getMonth() - cumpleanos.getMonth();

                if (m < 0 || (m === 0 && hoy.getDate() < cumpleanos.getDate())) {
                    edad--;
                }

                return edad;
            }

            $('#IdEspecialidad2').change(function(event) {
                var espP = $('#IdEspecialidad1').val();
                var espS = event.target.value;
                if(espP == espS)
                {
                    toastr.warning('Seleccione otra Especialidad Secundaria');
                    $('#IdEspecialidad2').val($("#IdEspecialidad2 option:first").val());
                }
            });

            $('#IdEspecialidad1').change(function(event) {
                var espS = $('#IdEspecialidad2').val();
                var espP = event.target.value;
                if(espP == espS)
                {
                    toastr.warning('Seleccione otra Especialidad Primaria');
                    $('#IdEspecialidad1').val($("#IdEspecialidad1 option:first").val());
                }
            });
		</script>

		<script type="text/javascript">
			$('select').select2();
		</script>		

			
		<?php $__env->stopSection(); ?>

	<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/gestionRecursos/recursoHumano/editar_personal.blade.php ENDPATH**/ ?>