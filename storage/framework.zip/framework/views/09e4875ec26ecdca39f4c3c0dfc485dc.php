<div id="content">
	<div class="section-body contain-lg" style="margin-top: -64px !important;">
	<!-- BEGIN VERTICAL FORM -->
	<div class="row">
		<div class="col-lg-offset-0 col-md-12">
			
			<?php echo $__env->yieldContent('form-tag'); ?>
			
				<div class="card">


					<div class="card-body">

						<?php echo $__env->yieldContent('card-content'); ?>

					</div><!--end .card-body -->

					
				</div><!--end .card -->
				
			</form>
		</div><!--end .col -->

	</div> <!-- End row -->

</div> <!-- End section container for card -->

</div>
<?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/partials/card_big_no_h.blade.php ENDPATH**/ ?>