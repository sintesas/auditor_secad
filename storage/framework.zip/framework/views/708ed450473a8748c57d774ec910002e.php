<?php $__env->startSection('title'); ?>
	Tablas Crear Producto
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>
		<?php $__env->startSection('card-title'); ?>
			<?php echo e(Breadcrumbs::render('productos')); ?>


		<!-- The Modal -->
		<?php if($permiso->crear == 1): ?>
		<button type="button" onclick="window.location='<?php echo e(route("productos.create")); ?>'" class="btn btn-info ink-reaction btn-primary addbutton" id="myBtn"><span class="fa fa-plus"></span></button>
		<?php endif; ?>

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>


			<div class="col-lg-12">
			<div class="table-responsive">
				<table id="datatable1" class="table table-striped table-hover">
					<thead>
						<tr>
							<th><b>Año</b></th>
							<th><b>Nombre</b></th>
							<th><b>ParteNumero</b></th>
							<th><b>NSN</b></th>
							<th><b>CodigoSAP</b></th>
							<th><b>Unidad</b></th>
							
							<th style="width: 120px;"><b>Acción</b></th>
							<th style="width: 120px;"><b>PCA</b></th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($permiso->consultar == 1): ?>
						<tr>
							<td><?php echo e($producto->Anio); ?></td>
							<td><?php echo e($producto->Nombre); ?></td>
							<td><?php echo e($producto->ParteNumero); ?></td>
							<td><?php echo e($producto->NSN); ?></td>
							<td><?php echo e($producto->CodigoSAP); ?></td>
							<td><?php echo e($producto->NombreUnidad); ?></td>
							
							<td>
							<?php if($permiso->eliminar == 1): ?>
								<div class="col-sm-4">
									<?php if($producto->Activo): ?>
									<?php echo Form::open(['route' => ['productos.destroy', $producto->IdDemandaPotencial], 'method' => 'DELETE']); ?>


									<?php echo Form::submit('x', ['class' => 'btn btn-danger deleteButton','style'=>'height: 36px;width: 36px;', 'title' =>'Eliminar']); ?>


									<?php echo Form::close(); ?>

									<?php else: ?>
									<?php echo Form::open(['route' => ['productos.show', $producto->IdDemandaPotencial], 'method' => 'GET']); ?>


									<?php echo Form::submit('✓', ['class' => 'btn btn-success','style'=>'height: 36px;width: 36px;', 'title' =>'Mostrar']); ?>


									<?php echo Form::close(); ?>

									<?php endif; ?>
								</div>
								<?php endif; ?>

								<?php if($permiso->actualizar == 1): ?>
								<div class="col-sm-4">

									<a href="<?php echo e(route('productos.edit', $producto->IdDemandaPotencial)); ?>" class="btn btn-primary btn-block editbutton" title="Editar"><div class="gui-icon"><i class="fa fa-pencil"></i></div></a>

								</div>
								<?php endif; ?>
								<div class="col-sm-4">

									<a href="<?php echo e(route('productos.notas', $producto->IdDemandaPotencial)); ?>" class="btn btn-primary btn-block editbutton" title="Ver notas"><div class="gui-icon"><i class="fa fa-clipboard"></i></div></a>

								</div>


							</td>
							
							<td>
									<div class="form-group">
										<?php echo Form::model($producto, ['route' => ['productos.pca'], 'method' => 'POST', 'id' => 'form_pca_'.$producto->IdDemandaPotencial]); ?>

										<input type="hidden" name="producto" value="<?php echo e($producto->IdDemandaPotencial); ?>">
										<select class="form-control" name="pca" id="pca_<?php echo e($producto->IdDemandaPotencial); ?>" onchange="cambiar_pca('<?php echo e($producto->IdDemandaPotencial); ?>')">
											<option value="">Seleccionar PCA</option>
											<?php $__currentLoopData = $pca; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pca_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($pca_item->id); ?>" <?php if($pca_item->id == $producto->id_pca): ?> selected <?php endif; ?>><?php echo e($pca_item->anio); ?> <?php echo e($pca_item->edicion); ?></option>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
										<?php echo Form::close(); ?>

									</div>
							</td>
						</tr>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div><!--end .table-responsive -->
		</div><!--end .col -->
		<?php $__env->stopSection(); ?>

	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>
<script>
	$(document).ready(function(){
		$('#datatable1').DataTable().column( '0:visible' ).order( 'desc' ).draw();
	});
</script>
<script type="text/javascript">
	function cambiar_pca(valor) {
		$('#form_pca_'+valor).submit();
	}
</script>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/certificacion/productosAeronauticos/ver_productos.blade.php ENDPATH**/ ?>