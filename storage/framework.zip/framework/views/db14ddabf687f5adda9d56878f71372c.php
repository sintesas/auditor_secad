<!-- BEGIN HEADER-->
<header id="header" style="background: #0f1f31" >
	<div class="headerbar">
		<div class="headerbar-left">
			<ul class="header-nav header-nav-options">
				<li class="header-nav-brand" >
					<div class="brand-holder">
						<a href="javascript:void(0)">
							<span class="text-lg text-bold text-primary">Auditor <strong>Plus</strong></span>
						</a>
					</div>
				</li>
			</ul>
		</div>
		<div class="title-fac">
			<div class="col-sm-4 div-img-right" style="">
				<img src="<?php echo e(asset('img/logo_fac.png')); ?>">
			</div>
			<div class="col-sm-4">				
				<h5 class="tittleHeadFAC">FUERZA AEROESPACIAL COLOMBIANA</h5>
				<h5 class="subTittleHeadFAC">Oficina de Certificación Aeronáutica de la Defensa - SECAD</h5>				
			</div>
			<div class="col-sm-4 div-img-left">
				<img src="<?php echo e(asset('img/logo_secad.png')); ?>">
			</div>
		</div>
		<div class="headerbar-right">
			<ul class="header-nav header-nav-profile">
				<li class="dropdown">
					<a href="javascript:void(0);" class="dropdown-toggle ink-reaction" data-toggle="dropdown">
						<span class="profile-info">							
							<?php echo e(auth()->user()->nombre_completo); ?>

							<small>SECAD-FAC</small>							
						</span>
					</a>
					<ul class="dropdown-menu animation-dock">
						<!--<li class="dropdown-header">Configuración</li>-->
						<!--<li><a href="javascript:void(0)">Mi Perfil</a></li>
						<li class="divider"></li>-->
						<div class="panel-footer">
							<form action="<?php echo e(route('logout')); ?>" method="POST">
								<?php echo e(csrf_field()); ?>

								<button class="btn btn-danger btn-xs btn-block">Cerrar sesión</button>
							</form>
						</div>
					</ul>
				</li>
			</ul>
		</div>
	</div>
</header>
<!-- END HEADER--><?php /**PATH D:\SINTE DESARROLLO - 5 de Junio\Auditor Secad\auditor_secad\resources\views/partials/header.blade.php ENDPATH**/ ?>