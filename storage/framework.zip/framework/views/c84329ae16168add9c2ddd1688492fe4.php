<?php $__env->startSection('title'); ?>
Informe Hoja de Vida
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('card-content'); ?>
<?php $__env->startSection('card-title'); ?>
<?php echo e(Breadcrumbs::render('informecursosfuncionario')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('card-content'); ?>


<div class="col-lg-12">
	<div class="table-responsive">
		<table id="datatable1" class="table table-striped table-hover">
			<thead>
				<tr>
					<th><b>Grado / Nombres</b></th>
					
					<th style="width: 120px;"><b>Acción</b></th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($permiso->consultar == 1): ?>
				<tr>
					<td><?php echo e($personals->Nombres); ?></td>
					

					<td>
						<div class="col-sm-6">
							<a href="<?php echo e(route('informecursosfuncionario.show', $personals->IdPersonal)); ?>" class="btn btn-primary btn-block editbutton" ><div class="gui-icon"><i class="fa fa-search"></i></div></a>
						</div>
						
					</td>
					
				</tr>
				<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div><!--end .table-responsive -->
</div><!--end .col -->

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>

<script>
	$(document).ready(function(){
		$('#datatable1').DataTable();
	});
</script>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/gestionRecursos/capacitacionPersonalSecad/informes/ver_informe_cursos_funcionarios.blade.php ENDPATH**/ ?>