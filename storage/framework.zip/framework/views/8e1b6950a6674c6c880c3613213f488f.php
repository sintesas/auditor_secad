<div id="menubar" class="menubar-inverse">
    <div class="menubar-fixed-panel">
		<div>
			<a class="btn btn-icon-toggle btn-default menubar-toggle" data-toggle="menubar" href="javascript:void(0);">
				<i class="fa fa-bars"></i>
			</a>
		</div>
		<div class="expanded">
			<a href="../../html/dashboards/dashboard.html">
				<span class="text-lg text-bold text-primary ">Fuerza Aérea</span>
			</a>
		</div>
	</div>

    <div class="menubar-scroll-panel">
        <ul id="main-menu" class="gui-controls">
		<?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($menu->menu_padre_id == null && empty($menu->submenus)): ?>
            <li>
				<a href="<?php echo e(route($menu->link)); ?>" class="active">
					<div class="gui-icon"><i class="<?php echo e($menu->icono); ?>"></i></div>
					<span class="title"><?php echo e($menu->titulo); ?></span>
				</a>
			</li>
			<?php endif; ?>
			<?php if(!empty($menu->submenus)): ?>
            <li class="gui-folder">
				<a>
					<div class="gui-icon"><i class="<?php echo e($menu->icono); ?>"></i></div>
					<span class="title"><?php echo e($menu->titulo); ?></span>
				</a>
				<ul>
				<?php $__currentLoopData = $menu->submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($submenu1->tipo_menu == 'I'): ?>
					<li><a href="<?php echo e(route($submenu1->link)); ?>"><span class="title"><?php echo e($submenu1->titulo); ?></span></a></li>
					<?php endif; ?>
					<?php if($submenu1->tipo_menu == 'M'): ?>
					<li class="gui-folder">
						<a href="javascript:void(0);"><span class="title"><?php echo e($submenu1->titulo); ?></span></a>
						<ul>
						<?php $__currentLoopData = $submenu1->submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php if($submenu2->tipo_menu == 'I'): ?>
								<li><a href="<?php echo e(route($submenu2->link)); ?>"><span class="title"><?php echo e($submenu2->titulo); ?></span></a></li>
							<?php endif; ?>
							<?php if($submenu2->tipo_menu == 'M'): ?>
								<li class="gui-folder">
									<a href="javascript:void(0);"><span class="title"><?php echo e($submenu2->titulo); ?></span></a>
									<ul>
									<?php $__currentLoopData = $submenu2->submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($submenu3->tipo_menu == 'I'): ?>
										<li><a href="<?php echo e(route($submenu3->link)); ?>"><span class="title"><?php echo e($submenu3->titulo); ?></span></a></li>
										<?php endif; ?>
										<?php if($submenu3->tipo_menu == 'M'): ?>
										<li class="gui-folder">
											<a href="javascript:void(0);"><span class="title"><?php echo e($submenu3->titulo); ?></span></a>											
											<ul>
											<?php $__currentLoopData = $submenu3->submenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($submenu4->tipo_menu == 'I'): ?>
												<li><a href="<?php echo e(route($submenu4->link)); ?>"><span class="title"><?php echo e($submenu4->titulo); ?></span></a></li>
												<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>											
											</ul>
										</li>
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</ul>
								</li>
							<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</ul>
					</li>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</li>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/partials/menu.blade.php ENDPATH**/ ?>