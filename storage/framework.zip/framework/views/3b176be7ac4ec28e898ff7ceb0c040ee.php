<?php $__env->startSection('title'); ?>
Roles Personal
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addcss'); ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"> </script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('card-content'); ?>

<?php $__env->startSection('card-title'); ?>

<?php echo e(Breadcrumbs::render('lista_personal')); ?>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('card-content'); ?>

<div class="col-lg-12">
	<div class="table-responsive">
		<table id="datatable1" class="table table-striped table-hover">
			<thead>
				<tr>
					<th><b>Nombre</b></th>
					<th><b>Email</b></th>
				
						<th style="width: 160px;"><b>Acción</b></th>
					
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $personal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($permiso->consultar == 1): ?>
				<tr>
					<td><?php echo e($persona->Abreviatura); ?> | <?php echo e($persona->Nombres . $persona->Apellidos); ?></td>

					<td><?php echo e($persona->Email); ?></td>

					
						<td>
						<?php if($permiso->eliminar == 1): ?>
							<div class="col-sm-4">

								<?php echo Form::open(['route' => ['asignarusuario.destroy', $persona->IdPersonal], 'method' => 'DELETE']); ?>


								<?php echo Form::submit('x', ['class' => 'btn btn-danger deleteButton']); ?>


								<?php echo Form::close(); ?>

							</div>
						<?php endif; ?>

						<?php if($permiso->actualizar == 1): ?>
							
						<?php endif; ?>

						<?php if($permiso->crear == 1): ?>
						
							<div class="col-sm-4">

								<button type="button" onclick="window.location='<?php echo e(route("asignarusuario.show", $persona->IdPersonal)); ?>'" class="btn btn-info ink-reaction btn-primary" id="myBtn"><span class="fa fa-plus"></span></button>

							</div>
						<?php endif; ?>
						</td>
				
				</tr>
				<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>

	</div><!--end .table-responsive -->
</div><!--end .col -->





<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('addjs'); ?>


<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>

<script src="<?php echo e(URL::asset('js/edit.js')); ?>"></script>

<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>



<script>
	$(document).ready(function(){
		$('#datatable1').DataTable();
	});




</script>



<?php $__env->stopSection(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card_big', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/gestionRecursos/recursoHumano/ver_personal_asignar.blade.php ENDPATH**/ ?>