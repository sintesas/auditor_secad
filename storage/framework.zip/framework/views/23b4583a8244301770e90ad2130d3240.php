<?php $__env->startSection('title'); ?>
	Informe Ofertas Sector Aeronautico
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>

		<?php $__env->startSection('form-tag'); ?>

	    <?php echo Form::model($ofertasPorCiudad); ?>

        <?php echo e(csrf_field()); ?>


		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-title'); ?>
			
            <?php echo e(Breadcrumbs::render('informe_ofertas_sector_aeronautico')); ?>

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>       

		<div class="card-body floating-label">
		<!-- BEGIN BASE-->
		<div id="">

			<!-- BEGIN OFFCANVAS LEFT -->
			<div class="offcanvas">
			</div><!--end .offcanvas-->
			<!-- END OFFCANVAS LEFT -->

			<!-- BEGIN CONTENT-->
            <div id="">
                <section>                   
                    <div class="section-body">
                       <!-- PRIMER BLOQUE DE INFOMACION -->
                        <div class="row">                            
                            <div class="col-xs-12 text-center">
                                <h3> INFORME DE EMPRESAS POR CIUDAD </h3>
                            </div>                            
                            
                            <!-- Responsable Proceso -->
                            <div class="col-xs-12 filaFormulario table-fixed " style="overflow: scroll; overflow-y:hidden;  height:100%;
     width:1000px;">
                                <table class="col-xs-1 table-responsive" style="font-size: 8px; width:100%;">
                                  <tr>
                                      <th class="th-x text-center"> Ciudad</th>                                    
                                      <th class="th-x text-center"> Nombre Empresa</th>
                                      <th class="th-x text-center" > Correo Electronico</th>
                                      <th class="th-x text-center" > Nit</th>  
                                      <th class="th-x text-center" > Pagina Web</th>
                                      <th class="th-x text-center" > Telefono</th>                   
                                      <th class="th-x text-center" > Dirección</th>                   
                                      <th class="th-x text-center" > Razón Social</th>                   
                                      
                                      
                                  </tr>                                  
                                    
                                    <?php if($permiso->consultar == 1): ?>
                                     <?php if(count($ofertasPorCiudad) != 1): ?>
                                     <?php $__currentLoopData = $ofertasPorCiudad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ofertasPorCiudadR): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="line-b">  
                                        <th class="text-center"><?php echo e($ofertasPorCiudadR->Ciudad); ?></th>
                                        <th class="text-center"><?php echo e($ofertasPorCiudadR->NombreEmpresa); ?></th>                             
                                        <th class="text-center"><?php echo e($ofertasPorCiudadR->Email); ?></th>
                                        <th class="text-center"><?php echo e($ofertasPorCiudadR->Nit); ?></th>                             
                                        <th class="text-center"><?php echo e($ofertasPorCiudadR->PaginaWeb); ?></th>
                                        <th class="text-center"><?php echo e($ofertasPorCiudadR->Telefono); ?></th>                             
                                        <th class="text-center"><?php echo e($ofertasPorCiudadR->Direccion); ?></th>
                                        <th class="text-center"><?php echo e($ofertasPorCiudadR->RazonSocial); ?></th>                                                                    
                                  </tr>                                  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                      <div class="section-body">
                                        <div class="text-center">
                                            <h3>No hay datos para mostrar informe</h3>
                                        </div>
                                      </div>
                                    <?php endif; ?>
                                    <?php endif; ?>
                                    <!--<tr class="line-b" id="filaFinal">  
                                        <th class="">TOTAL(Capacidades x Empresas)=</th>               <th class="">...</th>
                                                                          
                                  </tr>-->
                                </table>
                            </div>
                        </div><!--end .row -->                  
                    </div><!--end .section-body -->                   
                </section>
            </div><!--end #content-->
            <!-- END CONTENT -->
            <?php if($permiso->consultar == 1): ?>
            <a href="<?php echo e(route('informeofertasporciudad.create')); ?>" style="width: 150px; font-style: Roboto;" class="btn btn-primary btn-block editbutton pull-left"><span class="fa fa-download">    Descargar PDF</span></a>	
            <?php endif; ?>
        </div>
    </div>

        

		<?php echo Form::close(); ?>

		<?php $__env->stopSection(); ?>

	<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/fomento/sectorAeronautico/informes/visual_informe_ofertas_total_ciudad.blade.php ENDPATH**/ ?>