<?php $__env->startSection('title'); ?>
	Crear Rol
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startSection('card-content'); ?>

        <?php $__env->startSection('form-tag'); ?>
			<?php echo Form::open(['route' => 'rol.store']); ?>


            <?php echo e(csrf_field()); ?>

		
        <?php $__env->stopSection(); ?>				

        <?php $__env->startSection('card-title'); ?>
			
            <?php echo e(Breadcrumbs::render('crear_rol')); ?>


		<?php $__env->stopSection(); ?>

        <?php $__env->startSection('card-content'); ?>

            <div class="card-body floating-label">
                <div class="card">
                    <div class="card-head card-head-sm style-primary">
                        <header>
                            Crear Rol
                        </header>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input type="text" class="form-control" id="rol" name="rol" style="text-transform:uppercase" required>
                                    <label for="usuario">Rol</label>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <input type="checkbox" id="activo" name="activo" checked>
                                    <label for="activo">Activo</label>                            
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col-sm-6">
                            <button type="submit" style="" class="btn btn-info btn-block">Crear</button>
                        </div>
                        <div class="col-sm-6">
                            <button type="button" onclick="window.location='<?php echo e(route("rol.index")); ?>'" style="" class="btn btn-danger btn-block">Cancelar</button>
                        </div>
                    </div>
                </div>
            </div>

        <?php $__env->stopSection(); ?>

    <?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/admin/crear_rol.blade.php ENDPATH**/ ?>