<?php $__env->startSection('title'); ?>
    Informe Áreas x cooperación industrial
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>

		<?php $__env->startSection('form-tag'); ?>

	    <?php echo Form::model($empresas); ?>

        <?php echo e(csrf_field()); ?>


		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-title'); ?>
			
            <?php echo e(Breadcrumbs::render('ver_informe_areas_x_cooperacion_industrial')); ?>

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>       
        <?php if($permiso->consultar == 1): ?>

		<div class="card-body floating-label">
		<!-- BEGIN BASE-->
		<div id="">

			<!-- BEGIN OFFCANVAS LEFT -->
			<div class="offcanvas">
			</div><!--end .offcanvas-->
			<!-- END OFFCANVAS LEFT -->

			<div class="card-body floating-label">
                <!-- BEGIN BASE-->
                <div id="">
        
                    <!-- BEGIN OFFCANVAS LEFT -->
                    <div class="offcanvas">
                    </div><!--end .offcanvas-->
                    <!-- END OFFCANVAS LEFT -->
        
                    <!-- BEGIN CONTENT-->
                    <div id="">
                        <section>                   
                            <div class="section-body">                      
                               <!--  BLOQUE DE INFOMACION -->
                                <div class="row">                                                       
                                    <div class="col-xs-12 filaFormulario table-fixed">
                                        <table class="table  table-x" id="table1">
                                          
                                            <tr class="fondoAzulClaro">
                                                <th colspan="3" class="text-center"> <h3> INFORME DE ÁREAS CLAVES DE COOPERACIÓN INDUSTRIAL EN LA CADENA DE SUMINISTROS </h3></th>
                                            </tr>
                                            <tr>
                                                <th class="th-x" > Área </th>
                                                <th class="th-x" > SubÁreas </th>
                                                <th class="th-x" > Nombre Empresa </th>                          
                                            </tr>  
                                          <?php if(count($empresas) != 1): ?>
                                          <?php $areaOld = 0;
                                                $subAreaOld = 0;
                                                $tmpCt = 1; ?> 
                                          <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                                             <?php $area = $item->areasEmpresa;
                                                   $subAreaTmp = $item->subAreasEmpresa;
                                             ?> 
                                             <?php if((($area) != ($areaOld)) || (($areaOld) === 0)): ?>
                                              <tr class="line-bt"> 
                                                <th><?php echo e($item->areasEmpresa); ?></th> 
                                                <?php if((($subAreaTmp) != ($subAreaOld)) || (($subAreaOld) === 0)): ?>
                                                    <th><?php echo e($item->subAreasEmpresa); ?></th> 
                                                <?php endif; ?>
                                                <th><?php echo e($item->NombreEmpresa); ?></th>                                                                         
                                              </tr>
                                              <?php else: ?>
                                              <tr>  
                                                  <th></th>               
                                                  <?php if((($subAreaTmp) != ($subAreaOld)) || (($subAreaOld) === 0)): ?>
                                                    <th><?php echo e($item->subAreasEmpresa); ?></th> 
                                                  <?php else: ?>
                                                    <th></th>
                                                  <?php endif; ?>
                                                  <th><?php echo e($item->NombreEmpresa); ?></th>       
                                              </tr>
                                             <?php endif; ?> 
                                             <?php 
                                                $areaOld = $item->areasEmpresa;
                                                $subAreaOld = $item->subAreasEmpresa;
                                             ?> 
                                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                          <?php else: ?>
                                          <div class="section-body">
                                            <div class="text-center">
                                                <h3>No hay datos para mostrar informe</h3>
                                            </div>
                                          </div>
                                          <?php endif; ?>     
                                        </table>
                                    </div>
                                </div><!--end .row -->
                                
                               <!--  BLOQUE FIRMAS -->
                                <div class="row">                         
                                        <div class="col-xs-12 firmaFormulario">
                                             <div class="col-xs-offset-8 fecha">
                                        <div class="col-xs-6 " > Suma Total</div>
                                        <div class="col-xs-6"><?php echo e(count($empresas)); ?></div>   
                                    </div>      
                                        </div>
                                </div><!--end .row -->                                
                                           
                                               
                            </div><!--end .section-body -->                   
                        </section>
                    </div><!--end #content-->
                    <!-- END CONTENT -->
        
                    <a id="pdfAction" href="<?php echo e(route('informeareasxcoopindustri.create')); ?>"  style="width: 150px; font-style: Roboto;" class="btn btn-primary btn-block editbutton pull-left"><span class="fa fa-download">    Descargar PDF</span></a>
                      
                </div>
            </div>
            <!-- END CONTENT -->



		<?php echo Form::close(); ?>

        <?php endif; ?>
        <?php $__env->stopSection(); ?>

	<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/fomento/empresas/informes/visual_informe_areas_x_cooperacion_industrial.blade.php ENDPATH**/ ?>