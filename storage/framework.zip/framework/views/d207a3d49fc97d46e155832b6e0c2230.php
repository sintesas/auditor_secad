<?php if(Session::has('toastr.alerts')): ?>
    <div id="toastr">
    <?php $__currentLoopData = Session::get('toastr.alerts'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class='alert alert-<?php echo e($alert['type']); ?> <?php if(array_get($alert,'params.important') == true): ?> important <?php endif; ?>'>
            <button class="close" type="button" data-dismiss="alert" aria-hidden="true">&times;</button>

            <?php if( ! empty($alert['title'])): ?>
                <div><strong><?php echo e($alert['title']); ?></strong></div>                
            <?php endif; ?>

            <?php echo e($alert['message']); ?>


        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?><?php /**PATH C:\Users\ASUS-PC\Desktop\SINTE DESARROLLO - 1 de Julio\Auditor Secad\auditor_secad\resources\views/vendor/toastr/alerts.blade.php ENDPATH**/ ?>