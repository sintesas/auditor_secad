<?php $__env->startSection('title'); ?>
    
    Informe Hallazgos Generados

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>

		<?php $__env->startSection('form-tag'); ?>

			

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-title'); ?>
            <?php echo e(Breadcrumbs::render('informehallazgosgenerados')); ?>

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>       

		<div class="card-body floating-label">
		<!-- BEGIN BASE-->
		<div id="">

			<!-- BEGIN OFFCANVAS LEFT -->
			<div class="offcanvas">
			</div><!--end .offcanvas-->
			<!-- END OFFCANVAS LEFT -->

			<!-- BEGIN CONTENT-->
            <div id="">
                <section>
                    <?php if(count($informehallazgosgenerados) == 1): ?>
                    <?php $__currentLoopData = $informehallazgosgenerados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $informehallazgosgeneradosR): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="section-body">
                        <div class="row encabezadoPlanInspeccion">                                                   
                            <!-- titulo Formulario -->
                            <div class="col-xs-12 text-center">
                                <h3 class="line-b">HALLAZGOS GENERADOS INSPECCION INTERNA </h3>
                            </div>
                        </div>
                        
                        <!-- Primer BLOQUE DE INFOMACION -->                       
                        <div class="row">                            
                            <!-- Proceso -->
                            <div class="col-xs-12 filaFormulario table-fixed">
                                <table class="table  table-x" id="table1">
                                <?php if($permiso->consultar == 1): ?>
                                  <tr>
                                        <th class="th-x"> No Anota</th>
                                      
                                        <th  > Organización </th>
                                      
                                        <th class="th-x" > Proceso </th>
                                      
                                        <th class="th-x" > Codigo</th>
                                      
                                        <th class="th-x" > Fecha Inicio </th>
                                      
                                        <th class="th-x" > Descripcion </th>
                                      
                                        <th class="th-x"> Tipo</th>
                                      
                                        <th class="th-x"> Estado </th>
                                      
                                        <th class="th-x" > Fecha Avance</th>
                                        
                                        <th class="th-x" > Avance </th>
                                      
                                        <th class="th-x" > Anexo </th>                              
                                  </tr>                                  
                                    <tr class="line-b">  
                                        <th class=""> Hola manonla me dijeron por ahi que nadie te para bolas...</th>
                                        <th class=""> Hola manonla me dijeron por ahi que nadie te para bolas...</th>
                                        <th class=""> Hola manonla me dijeron por ahi que nadie te para bolas...</th>
                                        <th class=""> Hola manonla me dijeron por ahi que nadie te para bolas...</th>
                                        <th class="">. Hola manonla me dijeron por ahi que nadie te para bolas..</th>
                                        <th class="">.Hola manonla me dijeron por ahi que nadie te para bolas..</th>
                                        <th class="">.Hola manonla me dijeron por ahi que nadie te para bolas..</th>
                                        <th class="">..Hola manonla me dijeron por ahi que nadie te para bolas.</th>
                                        <th class="">..Hola manonla me dijeron por ahi que nadie te para bolas.</th>
                                        <th class="">.Hola manonla me dijeron por ahi que nadie te para bolas..</th>
                                        <th class="">.Hola manonla me dijeron por ahi que nadie te para bolas..</th>                                        
                                  </tr>
                                  <?php endif; ?>
                                </table>
                            </div>
                            <!-- FIN Div-->
                        </div><!--end .row -->                                                  
                    </div><!--end .section-body --> 
                </section>
                <?php if($permiso->consultar == 1): ?>

                <a href="<?php echo e(route('informehallazgosgenerados.create')); ?>" style="width: 150px; font-style: Roboto;" class="btn btn-primary btn-block editbutton pull-right"><span class="fa fa-download"> Descargar PDF</span></a>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <div class="section-body">
                    <div class="text-center">
                        <h3>No hay datos para mostrar informe</h3>
                    </div>
                  </div>
                <?php endif; ?>
            </div><!--end #content-->
            <!-- END CONTENT -->	
        </div>
    </div>

        

		<?php echo Form::close(); ?>

		<?php $__env->stopSection(); ?>

	<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SINTE DESARROLLO - 5 de Junio\Auditor Secad\auditor_secad\resources\views/auditoria/informes/visual_informe_hallazgos_generados.blade.php ENDPATH**/ ?>