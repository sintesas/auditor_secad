<?php $__env->startSection('title'); ?>
	Seguimiento Causa Raiz
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addcss'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<style>
	.cal {
		  float: left;
		  width: 20px;
		  height: 20px;
		  margin: 5px;
		  border: 1px solid rgba(0, 0, 0, .2);
		}

		.green {
		  background: #00B050;
		}

		.orange {
		  background: #ff6b16;
		}

		.red {
		  background: #DA9694;
		}
		.btn-view{
			padding: 0;
			margin-left: 15px;
			margin-top: 10px;
		}
		#acciones-btn{
			padding: 0;
			margin: 0;
		}

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>
		<?php $__env->startSection('card-title'); ?>
			<?php echo e(Breadcrumbs::render('seguimientocausaraiz')); ?>


			<!-- The Modal -->
			<?php if($permiso->crear == 1): ?>
			<button type="button" onclick="window.location='<?php echo e(route("seguimientoCausaRaiz.create")); ?>'" class="btn btn-info ink-reaction btn-primary addbutton" id="myBtn"><span class="fa fa-plus"></span></button>
			<?php endif; ?>
		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>

		<div class="total-card">
			<div class="table-responsive col-lg-12">		
			<?php if($permiso->consultar == 1): ?>		
			<a href="<?php echo e(url('exportSeguimientoCausaRaiz')); ?>" class="btn btn-md btn-info pull-left">Descargar EXCEL</a>
			<?php endif; ?>
				<table id="datatable1" class="table table-striped table-hover table-responsive">
					<thead style="font-size: 12px;">
						<tr>
							<th style="width: 50px;padding-left: 0px; padding-right: 0px; text-align: center;">Estado</th>
							<th style="width: 50px;padding-left: 0px; padding-right: 0px; text-align: center;" >Porcentaje</th>
							<th style="width: 50px;padding-left: 0px; padding-right: 0px; text-align: center;" >En curso</th>
							<th style="width: 100px;padding-left: 0px; padding-right: 0px; text-align: center;" >Codigo Auditoria</th>
							<th style="width: 100px;padding-left: 0px; padding-right: 0px; text-align: center;" >Responsable</th>
							<th style="width: 100px;padding-left: 0px; padding-right: 0px; text-align: center;" >Anotación</th>
							<th style="width: 100px;padding-left: 0px; padding-right: 0px; text-align: center;" >Actividad</th>
							<th style="width: 100px;padding-left: 0px; padding-right: 0px; text-align: center;" >Acciones Mejora</th>
							<th style="width: 100px;padding-left: 0px; padding-right: 0px; text-align: center;" >Fecha Seguimiento</th>
							<th style="width: 100px;padding-left: 0px; padding-right: 0px; text-align: center;" >Dias Restantes</th>
							<th style="width: 120px;padding-left: 0px; padding-right: 0px; text-align: center;" >Acción</th>
						</tr>
					</thead>
					<tbody id="data_table" name="data_table">

						<?php $__currentLoopData = $seguimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seguimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($permiso->consultar == 1): ?>

						<tr style="font-size: 12px;">
							<td>
								<?php if($seguimiento->Porcentaje < 100): ?>
									<i class="cal red"></i>
								<?php else: ?>
									<i class="cal green"></i>
								<?php endif; ?>
							</td>
							<td><?php echo e($seguimiento->Porcentaje); ?> %</td>
							<td><?php echo e($seguimiento->NombreEstado); ?></td>
							<td><?php echo e($seguimiento->Codigo); ?></td>
							<td><?php echo e($seguimiento->Name); ?></td>
							<td><?php echo e($seguimiento->NoAnota); ?></td>
							<td><?php echo e($seguimiento->AccionTarea); ?></td>
							<td><?php echo e($seguimiento->AccionSeguimiento); ?></td>
							<td><?php echo e($seguimiento->FechaSeguimiento); ?></td>
							<td>
								<?php
									$fecha_actual = date('Y-m-d');
									$s = strtotime($seguimiento->FechaFinal) - strtotime($fecha_actual);
									$d = intval($s/86400);
									echo $d . ' Dias'
								?>
							</td>
							<td id="acciones-btn">

								<div class="col">

								<?php if($permiso->actualizar == 1): ?>
										<a style="padding:5px 10px" href="<?php echo e(route('seguimientoCausaRaiz.edit', $seguimiento->IdSeguimiento)); ?>" class="btn btn-primary " ><div class="gui-icon-view"><i class="fa fa-pencil"></i></div></a>

										<a style="padding:5px 10px" href="<?php echo e(route('seguimientoCausaRaiz.edit', $seguimiento->IdSeguimiento)); ?>" class="btn btn-primary " ><div class="gui-icon-view"><i class="fa fa-eye"></i></div></a>
							    <?php endif; ?>
										<a style="padding:5px 10px" href="<?php echo e(route('seguimientoCausaRaiz.show', $seguimiento->IdSeguimiento)); ?>" class="btn btn-success " ><div class="gui-icon-view"><i class="fa fa-check"></i></div></a>

							
									<!--RESPONSABLE-->
									<?php if($seguimiento->IdEstadoSeguimiento == 1 || $seguimiento->IdEstadoSeguimiento == 4): ?>

											<?php if(strcmp(trim($email),trim($seguimiento->Email)) == 0): ?>

												<a href="<?php echo e(route('seguimientoCausaRaiz.edit', $seguimiento->IdSeguimiento)); ?>" class="btn btn-primary" ><div class="gui-icon-view"><i class="fa fa-pencil"></i></div></>

											<?php endif; ?>
											<?php if(strcmp(trim($email),trim($seguimiento->Email)) == 1): ?>

												<a style="padding:5px 10px" href="<?php echo e(route('seguimientoCausaRaiz.edit', $seguimiento->IdSeguimiento)); ?>" class="btn btn-primary" ><div class="gui-icon-view"><i class="fa fa-eye"></i></div></a>

											<?php endif; ?>

									<?php else: ?>
											style="padding:5px 10px" href="<?php echo e(route('seguimientoCausaRaiz.edit', $seguimiento->IdSeguimiento)); ?>" class="btn btn-primary" ><div class="gui-icon-view"><i class="fa fa-eye"></i></div></a>
									<?php endif; ?>

									<?php if($seguimiento->IdEstadoSeguimiento != 8): ?>

										
										<?php if($seguimiento->IdEstadoSeguimiento == 1 || $seguimiento->IdEstadoSeguimiento == 4): ?>

												<?php if(strcmp(trim($email),trim($seguimiento->Email)) == 0 && $rolAdmin != true): ?>

													<a style="padding:5px 10px" href="<?php echo e(route('seguimientoCausaRaiz.show', $seguimiento->IdSeguimiento)); ?>" class="btn btn-success" ><div class="gui-icon-view"><i class="fa fa-check"></i></div></a>

												<?php endif; ?>

										
										<?php elseif($seguimiento->IdEstadoSeguimiento == 3 || $seguimiento->IdEstadoSeguimiento == 7): ?>
											<?php if($rol_CEOAF != true): ?>

												<a style="padding:5px 10px" href="<?php echo e(route('seguimientoCausaRaiz.show', $seguimiento->IdSeguimiento)); ?>" class="btn btn-success" ><div class="gui-icon-view"><i class="fa fa-check"></i></div></a>

											<?php endif; ?>

										

										<?php elseif($seguimiento->IdEstadoSeguimiento == 5): ?>
											<?php if($rol_IGEFA != true): ?>

													<a style="padding:5px 10px" href="<?php echo e(route('seguimientoCausaRaiz.show', $seguimiento->IdSeguimiento)); ?>" class="btn btn-success" ><div class="gui-icon-view"><i class="fa fa-check"></i></div></a>

											<?php endif; ?>
										<?php endif; ?>

									<?php endif; ?>

								</div>
							</td>
						</tr>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
				<h5 id="conteo"></h5>
				<input type="hidden" id="tablehtml">

				
			</div><!--end .table-responsive -->
		</div><!--end .col -->
		<?php $__env->stopSection(); ?>

	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('addjs'); ?>

		<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('js/libs/DataTables/dataTables.buttons.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('js/libs/DataTables/jszip.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('js/libs/DataTables/buttons.html5.min.js')); ?>"></script>

		<script>

			function aprobarSeguimiento(ev){
				var dato = confirm('Aprobar Seguimiento');
				if(dato){
					if(ev != ''){
						$.get("seguimientoCausaRaiz/AprobarSeguimiento/" + ev + "", function(response, state){
							if(response == 1){
								window.location = '<?php echo e(route("seguimientoCausaRaiz.index")); ?>';
							}else{
								alert('No fue posible actualizar el seguimiento');
							}
						});
					}
				}
			}
			/*setTimeout(function(){
                $('#datatable1').DataTable(
					{
						//Excel
						dom: 'Bfrtip',
						buttons: [
							{
								extend: 'excelHtml5',
								text: 'Excel',
								title: 'Seguimientos',
								download: 'open',
								orientation:'landscape',
								exportOptions: {
									columns: ':visible'
								},
								className: "btn btn-primary"
							}
						]
					}
				);
				//PDF
				//$('.dt-buttons').prepend('<button type="button" onclick="return exportFile(\'build\');" style="padding: 4.5px 14px; width: 60px; font-style: Roboto;" class="btn btn-primary pull-left"> PDF </button>&nbsp;');
            }, 100);	*/


			/*function exportFile(type){
                location.href='<?php echo e(url("filterDinamicCompanyReportCreator")); ?>' + '?data=' + dinamicDataConfig(type);
            }

			function dinamicDataConfig(type){
                var dt = {
                    "type" : type
                }
                return encodeURIComponent(JSON.stringify(dt));
            }*/

			var filtros = [];
			var pdfexport;
			$(document).ready(function() {

				$('#datatable1').DataTable({
					paging: true,
					info:false,
//					ordering: false,
					initComplete: function () {
						this.api().columns().every( function () {
							var column = this;
							if (column[0] != 11 && column[0] != 12) {
								var select = $('<br><select style="color:#000; width:90%;"><option value=""></option></select>')
								.appendTo( $(column.header()) )
								.on( 'change', function () {
									var val = $.fn.dataTable.util.escapeRegex(
										$(this).val(),
										filtros.push($(this).val()));

									column.search( val ? '^'+val+'$' : '', true, false ).draw();
									var pdfexport = $('#data_table').html().trim();
									var cantidad = ($('#datatable1').rowCount());
									savedataPDf(pdfexport,cantidad);
									$('#conteo').html('Cantidad de seguimientos ' + $('#datatable1').rowCount());
								} );

								column.data().unique().sort().each( function ( d, j ) {
									select.append( '<option value="'+d+'">'+d+'</option>' )
									});
							}
					});
				},
				"order": [[ 1, "asc" ]],
				});
				if ( ! $('#datatable1').rowCount() ) {
					$('#conteo').html('0');
				}
				else
				{
					console.log($('#datatable1').rowCount());
					$('#conteo').html('Cantidad de seguimientos ' + $('#datatable1').rowCount());
				}
			});



			$(window).bind("load", function() {
			var pdfexport = $('#data_table').html().trim();
				var cantidad = ($('#datatable1').rowCount());
				//savedataPDf(pdfexport,cantidad);
			});

			$.fn.rowCount = function() {
				return $('tr', $(this).find('tbody')).length;
			};


			/*function savedataPDf(pdfexport,cantidad){
				$.ajaxSetup({
				headers: {
					'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
				}
				});

				$.ajax({

					type: 'post',
					url: 'pdftodb',
					data: {
						'table' : pdfexport,
						'cantidad':cantidad,
					},
					success: function(data){
						// alert("Saved to db");
					}
				});
			}*/

		</script>

		<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card_big', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\SINTE DESARROLLO - 5 de Junio\Auditor Secad\auditor_secad\resources\views/auditoria/ver_seguimiento_causa_raiz.blade.php ENDPATH**/ ?>