<?php $__env->startSection('title'); ?>
	Informe H/H Auditorias por func.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>

		<?php $__env->startSection('form-tag'); ?>

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-title'); ?>
			<?php echo e(Breadcrumbs::render('informeFuncionarioAuditoriaVisual')); ?>

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>


			<div class="card-body floating-label">
				<div style="overflow-x: auto;" id="output"></div>
			</div>

			 <script type="text/javascript">

				$( document ).ready(function() {
				    var derivers = $.pivotUtilities.derivers;
				    var renderers = $.extend($.pivotUtilities.renderers, $.pivotUtilities.plotly_renderers);	
				    // This example is the most basic usage of pivotUI()
				    $.ajax( {
					   url: '<?php echo e(URL::route('getHHAuditoria')); ?>', 
					   success: function(results) {
						   $("#output").pivotUI(
						   results,
							   {	
								   renderers: renderers,
								   rows: ["Funcionario", "NombreAuditoria", "codigo","TipoAuditoria" ,"totalHoras"],
								   cols: [],
								   aggregatorName: "Last",
								   vals: ["totalHoras"]
							   }
						   );
					   }
				   });
				});
        	</script>
		<?php $__env->stopSection(); ?>

	<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card_big', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/auditoria/informes/visual_informe_funcionarios.blade.php ENDPATH**/ ?>