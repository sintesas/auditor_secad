<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?php echo e(asset('/img/favicon.ico')); ?>" type="image/vnd.microsoft.icon">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'SECAD - Auditor')); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <style>
        @font-face {
            font-family: 'Eras Demi ITC';
            font-style: normal;
            font-weight: normal;
            src: url('<?php echo e(asset('css/fonts/ERASDEMI.woff')); ?>') format('woff');
        }
    </style>
</head>
<body class="bodyLogin" style="background: #d2f1f7 url(<?php echo e(asset('img/header-top.png')); ?>) repeat-x 0 0;">
    <div id="app">
        <nav class="navbar navbar-default navbar-static-top" style="background-color: #0f1f31; border-color: #0f1f31;">
            <div class="container" style="">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>" style="color:#cccccc; font-weight: 700; font-size: 16.25px;">
                        Auditor <strong>Plus</strong>
                    </a>
                </div>
                <div style="height:64px; padding-left: 18%; float: left;">
                    <img style="height:64px; padding-right: 15px;" src="<?php echo e(asset('img/logo_fac.png')); ?> ">
                    <span style="font-family: Eras Demi ITC; font-size: 24px; font-weight:400; color: #fff;">FUERZA AEROESPACIAL COLOMBIANA</span>
                    <img style="height:64px; padding-left: 15px;" src="<?php echo e(asset('img/logo_secad.png')); ?>">
                </div>
                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <ul class="nav navbar-nav">
                        &nbsp;
                    </ul>
                </div>
            </div>
        </nav>
        <?php echo $__env->yieldContent('content'); ?>

        <!-- <?php echo $__env->make('toastr::alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> -->

        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if(session()->has('flash')): ?>        
            <center>  <div class="alert alert-info" style="width: 50%; text-align: center;"> <b style="color:red;">Acceso Restringido </b> <br> <?php echo e(session('flash')); ?></div> </center>
        <?php endif; ?>
    </div>
    
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html><?php /**PATH C:\Users\jcmor\Desktop\SINTE DESARROLLO\Auditor Secad\auditor_secad\resources\views/layouts/app.blade.php ENDPATH**/ ?>