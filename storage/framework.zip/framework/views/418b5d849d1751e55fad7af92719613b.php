<?php $__env->startSection('title'); ?>
	Seguimiento Actividades
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('card-content'); ?>
<?php $__env->startSection('card-title'); ?>
<?php echo e(Breadcrumbs::render('especialistassegui', $programa->IdPrograma, $actividad->IdActividad.'&'.$programa->IdPrograma)); ?>



<!-- The Modal -->

<button type="button" onclick="document.getElementById('id1').style.display='block'" class="btn btn-info ink-reaction btn-primary addbutton" id="myBtn"><span class="fa fa-plus"></span></button>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('card-content'); ?>

<div class="col-lg-12">
	<div class="table-responsive">
		<h4><strong>Programa:</strong> <?php echo e($programa->Consecutivo); ?> / <strong>Tipo Programa:</strong> <?php echo e($tipoPrograma->Tipo); ?></h4>
		<h4><strong>Actividad:</strong> <?php echo e($actividad->Actividad); ?></h4>
		<h4><strong>Seguimiento:</strong> <?php echo e($seguimiento->Evidencias); ?></h4>
		<table id="datatable1" class="table table-striped table-hover">
			<thead>
				<tr>
					<th><b>Fecha</b></th>
					<th><b>Especialista</b></th>
					<th><b>Horas</b></th>
					
					<th style="width: 120px;"><b>Acciones</b></th>
	
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $especialistas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($especialista->Fecha); ?></td>
					<td><?php echo e($especialista->Nombres); ?></td>
					<td><?php echo e($especialista->Horas); ?></td>
					
					<td>
						<div class="col-sm-6">

							<?php echo Form::open(['route' => ['especialistasSeg.destroy', $especialista->IdEspecialistaSeguimiento], 'method' => 'DELETE']); ?>


							<?php echo Form::submit('x', ['class' => 'btn btn-danger deleteButton']); ?>


							<?php echo Form::close(); ?>

						</div>
					</td>
		
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div><!--end .table-responsive -->
</div><!--end .col -->


<div id="id1" class="modal" style="padding-top:135px;">
	<div class="modal-content">
		<div class="card-head style-primary">
			<header>Asignar Especialistas</header>
			<span style="margin-right: 20px;" onclick="document.getElementById('id1').style.display='none'"
			class="close">x</span>
		</div>

		<div class="card">
			<div class="card-body floating-label">
				<?php echo Form::open(array('route' => 'especialistasSeg.store')); ?>


				<?php echo e(csrf_field()); ?>


				<div class="row">
					<div class="col-sm-12">
						<div class="form-group">
							<?php echo e(Form::select('IdPersonal', $personal->pluck('Nombres' , 'IdPersonal'), null, ['class' => 'form-control', 'id' => 'IdPersonal'])); ?>

							<label for="Codigo">Especialista</label>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-sm-6">
						<div class="form-group">
							<div class="input-group date" id="demo-date-format">
								<div class="input-group-content">
									<input type="text" class="form-control" id="Fecha" name="Fecha" required>
									<label for="Fecha">Fecha</label>
								</div>
								<span class="input-group-addon"></span>
							</div>
						</div>
					</div>
					<div class="col-sm-6">
						<div class="form-group">
							<input type="number" class="form-control" id="Horas" name="Horas" required  onKeyPress="return soloNumeros(event)">
							<label for="Horas">Horas</label>
						</div>
					</div>
				</div>


				<div class="form-group">
					<div class="row">
						<div class="col-sm-6">
							<button type="submit" style="" class="btn btn-info btn-block">Crear</button>
						</div>
						<div class="col-sm-6">
							<button type="button" onclick="window.location='<?php echo e(route("especialistasSeg.show", $seguimiento->IdListaSeguimiento)); ?>'" style="" class="btn btn-danger btn-block">Cancelar</button>
						</div>
					</div>
				</div>

				<input type="hidden" id="IdListaSeguimiento" name="IdListaSeguimiento" value="<?php echo e($seguimiento->IdListaSeguimiento); ?>">
			</div>

		</div>
	</div>
	<?php echo Form::close(); ?>

	<script src="<?php echo e(asset('js/soloNumeros.js')); ?>"></script>
	<script>
		$(".delete").on("submit", function(){
			return confirm("Esta seguro que desea borrar este codigo?");
		});
	</script>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>

<script>
	$(document).ready(function(){
		$('#datatable1').DataTable();
	});
</script>

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/certificacion/programasSECAD/seguimientoProgramas/ver_lista_seguimiento_especialistas.blade.php ENDPATH**/ ?>