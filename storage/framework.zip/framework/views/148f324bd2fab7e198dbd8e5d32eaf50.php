<?php $__env->startSection('title'); ?>
	Ver Programas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>
		<?php $__env->startSection('card-title'); ?>

		<?php echo e(Breadcrumbs::render('Observaciones212')); ?>


		<button type="button" onclick="document.getElementById('id1').style.display='block'" style="margin-left:800px;" class="btn btn-info ink-reaction btn-primary addbutton" id="myBtn"><span class="fa fa-plus"></span></button>
		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>
			<h4><strong>Programa: </strong> <?php echo e($programa->Proyecto); ?></h4>
			<h4><strong>Código: </strong> <?php echo e($programa->Consecutivo); ?></h4>
			<br>

			<div class="col-lg-12">
			<div class="table-responsive">
				<table id="datatable1" class="table table-striped table-hover">
					<thead>
						<tr>
							<th><b>Observación</b></th>
							<th><b>Fecha</b></th>
							<th style="width: 120px;"><b>Acciones</b></th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $observaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $observacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($observacion->Observacion); ?></td>
							<td><?php echo e($observacion->Fecha); ?></td>
							<td>

								<div class="col-sm-6">
									<?php echo Form::open(['route' => ['obsercavionesfr212.destroy', $observacion->IdLAFR212Obs], 'method' => 'DELETE']); ?>

										<?php echo Form::submit('x', ['class' => 'btn btn-danger btn-default', 'onsubmit' => 'return ConfirmDelete()']); ?>

									<?php echo Form::close(); ?>

								</div>

							</td>

							</td>						

							
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>

				<div class="text-center">
				
				</div>



			</div><!--end .table-responsive -->
		</div><!--end .col -->
		
		<div id="id1" class="modal" style="padding-top:135px;">

				<div class="modal-content">

					<div class="card-head style-primary">
						<header>Creación observaciones Informe LAFR212</header>
						 <span style="margin-right: 20px;" onclick="document.getElementById('id1').style.display='none'"
						class="close">x</span>
					</div>
					<div class="card">
						<div class="card-body floating-label">
							<?php echo Form::open(array('route' => 'obsercavionesfr212.store')); ?>

							<?php echo e(csrf_field()); ?>

							<div class="row">
								<div class="col-sm-12">
									<div class="form-group">
										<textarea name="Observacion" id="Observacion" rows="3" class="form-control"></textarea>
										<?php echo e(Form::label('Observacion', 'Observacion')); ?>

									</div>
								</div>

							</div>
							<input type="hidden" value="<?php echo e($programa->IdPrograma); ?>" id="IdPrograma" name="IdPrograma">
							<div class="form-group">
								<div class="row">
									<div class="col-sm-6">
										<button type="submit" style="" class="btn btn-info btn-block">Crear</button>
									</div>
									<div class="col-sm-6">
										<button type="button" onclick="document.getElementById('id1').style.display='none'" style="" class="btn btn-danger btn-block">Cancelar</button>
									</div>
								</div>
							</div>
							<?php echo Form::close(); ?>

						</div>
					</div>
					<script>
						function ConfirmDelete()
						{
							var x = confirm("Esta seguro de elminar el registro?");
							if (x)
								return true;
							else
								return false;
						}
					</script>
				</div>
			</div>


		
		<?php $__env->stopSection(); ?>


	<?php $__env->stopSection(); ?>

<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>

<script>
	$(document).ready(function(){
		$('#datatable1').DataTable();
	});
</script>

<?php $__env->stopSection(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/certificacion/programasSECAD/seguimientoProgramas/ver_observacionesLAFR212.blade.php ENDPATH**/ ?>