<div id="content">
	<div class="section-body contain-lg">
		<!-- BEGIN VERTICAL FORM -->
		<div class="row">
			<div class="col-lg-offset-0 col-md-12">
				
				<?php echo $__env->yieldContent('form-tag'); ?>
				
					<div class="card">
						<div class="card-head style-primary">
							<header><?php echo $__env->yieldContent('card-title'); ?></header>
						</div>

						<div class="card-body">

							<?php echo $__env->yieldContent('card-content'); ?>

						</div><!--end .card-body -->						
					</div><!--end .card -->
							
				</form>
			</div><!--end .col -->
		</div> <!-- End row -->
	</div> <!-- End section container for card -->
</div>
<?php /**PATH C:\Users\jcmor\Desktop\SINTE DESARROLLO\Auditor Secad\auditor_secad\resources\views/partials/card_big.blade.php ENDPATH**/ ?>