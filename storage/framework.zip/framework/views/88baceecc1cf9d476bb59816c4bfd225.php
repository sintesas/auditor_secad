<?php $__env->startSection('title'); ?>
    Roles
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startSection('card-content'); ?>

        <?php $__env->startSection('card-title'); ?>
            <?php echo e(Breadcrumbs::render('rol')); ?>

            <?php if($permiso->crear == 1): ?>
            <button type="button" onclick="window.location='<?php echo e(route("rol.create")); ?>'" class="btn btn-info ink-reaction btn-primary addbutton" id="myBtn"><span class="fa fa-plus"></span></button>
            <?php endif; ?>        
            <?php $__env->stopSection(); ?>

        <?php $__env->startSection('card-content'); ?>

            <div class="col-lg-12">
                <div class="table-responsive">
                    <table id="datatable1" class="table table-striped table-hover">
                        <thead>
                            <th><b>Rol</b></th>
                            <th><b>Estado</b></th>
                            <th style="width: 120px;"><b>Acción</b></th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($permiso->consultar == 1): ?>
                                <tr>
                                    <td><?php echo e($item->rol); ?></td>
                                    <td style="text-align: center;">
                                        <?php if($item->activo == 1): ?>
                                            <div class="gui-td-icon"> <i class="fa fa-check-circle" style="color: green;"></i></div>
                                        <?php else: ?>
                                            <div class="gui-td-icon"> <i class="fa fa-times-circle" style="color: red;"></i></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($item->rol != 'ROL_ADMINISTRADOR'): ?>
                                        <?php if($permiso->actualizar == 1): ?>
                                            <div class="col-sm-6">
                                                <a href="<?php echo e(route('rol.edit', $item->rol_id)); ?>" class="btn btn-primary btn-block editbutton" ><div class="gui-icon"><i class="fa fa-pencil"></i></div></a>
                                            </div>
                                        <?php endif; ?>
                                            <div class="col-sm-6">
                                                <a href="<?php echo e(route('rolprivilegio.indice', $item->rol_id)); ?>" class="btn btn-primary btn-block editbutton" ><div class="gui-icon"><i class="fa fa-shield"></i></div></a>
                                            </div>
                                        <?php endif; ?>
                                    </td>                                                              
                                </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        <?php $__env->stopSection(); ?>
    
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('addjs'); ?>

        <script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>
        <script>
            $(document).ready(function(){
                $('#datatable1').DataTable();
            });
        </script>

    <?php $__env->stopSection(); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/admin/roles.blade.php ENDPATH**/ ?>