<?php $__env->startSection('title'); ?>
	Cantidad Anotaciones
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>

		<?php $__env->startSection('form-tag'); ?>

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-title'); ?>
			CantidadS Anotaciones
			

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>

	
		<?php if($permiso->consultar == 1): ?>
			<div class="card-body floating-label">
				<div style="overflow-x: auto;" id="output"></div>
			</div>

			 <script type="text/javascript">
			 	var derivers = $.pivotUtilities.derivers;
		        var renderers = $.extend($.pivotUtilities.renderers, $.pivotUtilities.plotly_renderers);

			    // This example is the most basic usage of pivotUI()
				$.get('anotacionesXEstadoParcial/vistaAuditorias/', function(response, state){				
					$("#output").pivotUI(
			            response,
			            {	
			            	renderers: renderers,
			                rows: ["TipoAuditoria"],
			                cols: ["Año", "NombreEmpresa"],
			            }
			        );
				});
        	</script>
		<?php endif; ?>
		<?php $__env->stopSection(); ?>

	<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card_big', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/auditoria/tablasDinamicas/TDINCantidadAnotaciones.blade.php ENDPATH**/ ?>