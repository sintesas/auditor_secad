<?php $__env->startSection('title'); ?>
	Tablas Crear Personal
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>
		<?php $__env->startSection('card-title'); ?>
		<?php echo e(Breadcrumbs::render('personal')); ?>


		<!-- The Modal -->
		
		<?php if($permiso->crear == 1): ?>
			<button type="button" onclick="window.location='<?php echo e(route("personal.create")); ?>'" class="btn btn-info ink-reaction btn-primary addbutton" id="myBtn"><span class="fa fa-plus"></span></button>
		<?php endif; ?>
		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>

		<div class="col-lg-12">
			<div class="table-responsive">
				<table id="datatable1" class="table table-striped table-hover">
					<thead>
						<tr>
							<th><b>Grado</b></th>
							<th><b>Nombres</b></th>
							<th><b>Apellidos</b></th>
							<th><b>Cedula</b></th>
							
									<th style="width: 100px;"><b>Familiares</b></th>
									<th style="width: 100px;"><b>Cursos</b></th>
									<th style="width: 120px;"><b>Acción</b></th>
								
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $personales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($permiso->consultar == 1): ?>
						<tr>
							<td><?php echo e($personal->Abreviatura); ?></td>
							<td><?php echo e($personal->Nombres); ?></td>
							<td><?php echo e($personal->Apellidos); ?></td>
							<td><?php echo e($personal->Cedula); ?></td>

							
									<td>

										<div class="col-sm-1">
											<a href="<?php echo e(route('familiares.show', $personal->IdPersonal)); ?>" class="btn btn-default btn-group-xs"><span class="fa fa-plus-square"></span></a>
										</div>

									</td>
									<td>

										<div class="col-sm-1">
											<a href="<?php echo e(route('cursosPersonal.show', $personal->IdPersonal)); ?>" class="btn btn-default btn-group-xs"><span class="fa fa-plus-square"></span></a>
										</div>

									</td>
									<td>
									<?php if($permiso->eliminar == 1): ?>
										<div class="col-sm-6">

											<?php echo Form::open(['route' => ['personal.destroy', $personal->IdPersonal], 'method' => 'DELETE']); ?>


											<?php echo Form::submit('x', ['class' => 'btn btn-danger deleteButton']); ?>


											<?php echo Form::close(); ?>

										</div>
									<?php endif; ?>

									<?php if($permiso->actualizar == 1): ?>
										<div class="col-sm-6">

											<a href="<?php echo e(route('personal.edit', $personal->IdPersonal)); ?>" class="btn btn-primary btn-block editbutton" ><div class="gui-icon"><i class="fa fa-pencil"></i></div></a>

										</div>
									<?php endif; ?>

									</td>
						
						</tr>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div><!--end .table-responsive -->
		</div><!--end .col -->
		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('addjs'); ?>

			<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>

			<script>
				$(document).ready(function(){
					$('#datatable1').DataTable();
				});
			</script>
		<?php $__env->stopSection(); ?>
	<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/gestionRecursos/recursoHumano/ver_personal.blade.php ENDPATH**/ ?>