<body style="background-color: white">
	


<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>
		<div class="row encabezadoPlanInspeccion">

            <!-- titulo Formulario -->
            <div class="col-xs-12 text-center">
                
                <div>
                    <h4>Observaciones del Programa</h4>
                    <h5><?php echo e($programa->Consecutivo); ?></h5>
                    <h5><?php echo e($programa->Proyecto); ?></h5>
                </div>                        
           </div>                              
        </div>
		<table id="datatable1" class="table table-striped table-hover" style="font-size: 10px;">
			<thead  style="font-size: 9.5px;">
				<tr>
					<th style="width:10%; padding-left: 0px; padding-right: 0px; text-align: center;"><b>Fecha</b></th>
				<th style="width: 90%; padding-left: 0px; padding-right: 0px; text-align: center;"><b>Observacion</b></th>
				</tr>
			</thead>
			
			<tbody id="data_table" name="data_table">
				<?php $__currentLoopData = $observaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $observacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td style="font-size: 8px;"><?php echo e($observacion->Fecha); ?></td>
					<td style="font-size: 9px;"><?php echo e($observacion->Observacion); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
			 
	<?php $__env->stopSection(); ?>

<?php $__env->startSection('addjs'); ?>

<?php $__env->stopSection(); ?>
	

<?php $__env->stopSection(); ?>

</body>
<?php echo $__env->make('partials.pdf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card_big_no_h', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/certificacion/programasSECAD/seguimientoProgramas/pdf_InformeObservacionesLAFR212Progamas.blade.php ENDPATH**/ ?>