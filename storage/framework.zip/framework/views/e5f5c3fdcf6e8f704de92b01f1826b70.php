<?php $__env->startSection('title'); ?>
	Informe Capacidad total por ciudad
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>

		<?php $__env->startSection('form-tag'); ?>

	    <?php echo Form::model($cantidadesTotalCiudad); ?>

        <?php echo e(csrf_field()); ?>


		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-title'); ?>
			
            <?php echo e(Breadcrumbs::render('informe_ofertas_sector_aeronautico')); ?>

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>       

		<div class="card-body floating-label">
		<!-- BEGIN BASE-->
		<div id="">

			<!-- BEGIN OFFCANVAS LEFT -->
			<div class="offcanvas">
			</div><!--end .offcanvas-->
			<!-- END OFFCANVAS LEFT -->

			<!-- BEGIN CONTENT-->
            <div id="">
                <section>                   
                    <div class="section-body">                      
                        
                         

                                     <!--  BLOQUE DE INFOMACION -->
                        <div class="row">                                                       
                            <div class="col-xs-12 filaFormulario table-fixed">
                                <table class="table  table-x" id="table1">
                                  
                                    <tr class="fondoAzulClaro">
                                        <th colspan="3" class="text-center"> <h3> OFERTA DE CAPACIDADES POR CIUDAD </h3></th>
                                    </tr>
                                    
                                    <tr>
                                        
                                        <th class="th-x" >  Ciudad </th>
                                      
                                        <th class="th-x" > Oferta Comercial </th>
                                      
                                        <th class="th-x" > Cantidad de Empresas </th>
                                                                              
                                    </tr>  
                                    <?php if($permiso->consultar == 1): ?>
                                  <?php if(count($cantidadesTotalCiudad) != 1): ?>
                                  <?php $ciudadOld = 0;?> 
                                  <?php $__currentLoopData = $cantidadesTotalCiudad; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cantidadesTotalCiudadR): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>     
                                     <?php $ciudad = $cantidadesTotalCiudadR->Ciudad;?> 
                                     <?php if((($ciudad) != ($ciudadOld)) || (($ciudadOld) === 0)): ?>
                                      <tr class="line-bt">  
                                          <th><?php echo e($cantidadesTotalCiudadR->Ciudad); ?></th> 
                                          <th></th> 
                                          <th></th>                                                                       
                                      </tr>
                                       <tr>      
                                          <th></th>                                      
                                          <th><?php echo e($cantidadesTotalCiudadR->OfertaComercial); ?></th>
                                          <th><?php echo e($cantidadesTotalCiudadR->cnt); ?></th>                                        
                                      </tr>
                                      <?php else: ?>
                                      <tr>  
                                          <th></th>                                          
                                          <th><?php echo e($cantidadesTotalCiudadR->OfertaComercial); ?></th>
                                          <th><?php echo e($cantidadesTotalCiudadR->cnt); ?></th>                                        
                                      </tr>
                                     <?php endif; ?> 
                                     <?php $ciudadOld = $cantidadesTotalCiudadR->Ciudad;?> 
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                  <?php else: ?>
                                  <div class="section-body">
                                    <div class="text-center">
                                        <h3>No hay datos para mostrar informe</h3>
                                    </div>
                                  </div>
                                  <?php endif; ?>    
                                  <?php endif; ?> 
                                </table>
                            </div>
                        </div><!--end .row -->
                        <?php if($permiso->consultar == 1): ?>
                       <!--  BLOQUE FIRMAS -->
                        <div class="row">                         
                                <div class="col-xs-12 firmaFormulario">
                                     <div class="col-xs-offset-8 fecha">
                                <div class="col-xs-6 " > Suma Total</div>
                                <div class="col-xs-6"><?php echo e($cantidadesTotalCiudadR->Total); ?></div>   
                            </div>      
                                </div>
                        </div><!--end .row -->                                
                          <?php endif; ?>         
                                       
                    </div><!--end .section-body -->                   
                </section>
            </div><!--end #content-->
            <!-- END CONTENT -->
            <?php if($permiso->consultar == 1): ?>
             <a href="<?php echo e(route('informecapacidadtotalciudad.create')); ?>" style="width: 150px; font-style: Roboto;" class="btn btn-primary btn-block editbutton pull-left"><span class="fa fa-download">    Descargar PDF</span></a>
            <?php endif; ?>
        </div>
    </div>

        
		<?php echo Form::close(); ?>

		<?php $__env->stopSection(); ?>

	<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/fomento/sectorAeronautico/informes/visual_informe_capacidad_total_ciudad.blade.php ENDPATH**/ ?>