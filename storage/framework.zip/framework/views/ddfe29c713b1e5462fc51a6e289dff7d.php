<div id="content">
	<div class="section-body container-fluid">
		<!-- BEGIN VERTICAL FORM -->
		<div class="row">
			<div class="col-lg-offset-1 col-md-10">

				<?php echo $__env->yieldContent('form-tag'); ?>

					<div class="card">
						<div class="card-head style-primary">
							<header><?php echo $__env->yieldContent('card-title'); ?></header>
						</div>

						<div class="card-body">

							<?php echo $__env->yieldContent('card-content'); ?>

						</div><!--end .card-body -->
					</div><!--end .card -->

				</form>
			</div><!--end .col -->
		</div> <!-- End row -->
	</div> <!-- End section container for card -->
</div>
<?php /**PATH C:\Users\jcmor\Desktop\SINTE DESARROLLO\Auditor Secad\auditor_secad\resources\views/partials/card.blade.php ENDPATH**/ ?>