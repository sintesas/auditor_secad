<?php $__env->startSection('title'); ?>
Estados Programas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('addcss'); ?>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"> </script>
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('card-content'); ?>

<?php $__env->startSection('card-title'); ?>
<?php echo e(Breadcrumbs::render('estadosprograma')); ?>


<?php if($permiso->crear == 1): ?>
<?php if(count($estadosprograma)>0): ?>
<button type="button" onclick="document.getElementById('id1').style.display='block'" style="margin-left:800px;" class="btn btn-info ink-reaction btn-primary addbutton" id="myBtn"><span class="fa fa-plus"></span></button>
<?php endif; ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>



<div class="col-lg-12">

	<?php if(count($estadosprograma)==0): ?>
	<div style="text-align: center;" id="lunch">
		<center> <h2> No existen estados, Haga click en el boton <button style="right: 0px !important; position: relative !important; top: 0px !important;" type="button" onclick="document.getElementById('id1').style.display='block'" class="btn btn-info ink-reaction btn-primary addbutton" id="myBtn"><span class="fa fa-plus"></span></button> </h2> </center>
	</div>
	<?php else: ?>

	<div class="table-responsive">
		<table id="datatable1" class="table table-striped table-hover">
			<thead>
				<tr>
					<th><b>Descripción</b></th>
					<th><b>Acción</b></th>
				</tr>
			</thead>

			<tbody>

				<?php $__currentLoopData = $estadosprograma; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($permiso->consultar == 1): ?>
				<tr class="estadoprograma<?php echo e($estado->IdEstadoPrograma); ?>">
					<td><?php echo e($estado->Descripcion); ?></td>
					<td class="idestadoprograma<?php echo e($estado->IdEstadoPrograma); ?>">
						<div class="col-sm-10">
						<?php if($permiso->eliminar == 1): ?>
							<button class="btn btn-danger btn-delete delete-record pull-right" value="<?php echo e($estado->IdEstadoPrograma); ?>"><span class="glyphicon glyphicon-trash"></span></button>
						<?php endif; ?>
						</div>
						<div class="col-sm-2">
						<?php if($permiso->actualizar == 1): ?>
							<button class="btn btn-primary btn-default edit-modal pull-right" data-id="<?php echo e($estado->IdEstadoPrograma); ?>" data-descripcion="<?php echo e($estado->Descripcion); ?>">
                    			<span class="glyphicon glyphicon-edit"></span>
                			</button>
						<?php endif; ?>
						</div>
					</td>
				</tr>
				<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</tbody>
		</table>
	</div>
	<?php endif; ?>
</div>


<div id="id1" class="modal" style="padding-top:80px;">

	<div class="modal-content" style="width:60%;">

		<div class="card-head style-primary">
			<header>Crear Nuevo Estado Programa</header>
			<span style="margin-right: 20px;" onclick="document.getElementById('id1').style.display='none'"
			class="close">x</span> 
		</div>

		<div class="card">
			<div class="card-body floating-label">

				<?php echo Form::open(array('route' => 'estadosprograma.store')); ?>

				
				<?php echo e(csrf_field()); ?>


				<div class="card">
					<div class="card-body">

						<div class="row">

							<div class="col-sm-6">
								<div class="form-group">
									<input type="text" class="form-control" id="cDescripcion" name="Descripcion" required>
									<label for="Descripcion">Descripción</label>
								</div>
							</div>
						</div>
					</div>
				</div>


				<div class="row">
					<div class="col-sm-6">
						<button type="submit" style="" class="btn btn-info btn-block">Crear</button>
					</div>
					<div class="col-sm-6">
						<button type="button" onclick="document.getElementById('id1').style.display='none'" style="" class="btn btn-danger btn-block">Cancelar</button>
					</div>
				</div>
				
				<?php echo Form::close(); ?>


			</div>
		</div>

	</div>
</div>




<div id="myModal" class="modal" style="padding-top:80px;">

	<div class="modal-content" style="width:60%;">

		<div class="card-head style-primary">
			<header>Editar Estado Programa</header>
		</div>

		<div class="card">
			<div class="card-body floating-label">


				<form class="form-horizontal" role="form">

					<div class="card">
						<div class="card-body">
							<input type="hidden" name="IdEstadoPrograma" id="IdEstadoPrograma">
						<div class="row">
							<div class="col-sm-6">
								<div class="form-group">
									<input type="text" class="form-control" id="Descripcion" name="Descripcion" required>
									<label for="Descripción">Descripción</label>
								</div>
							</div>
						</div>
						</div>  
					</div>

				</form>

				<div class="modalfooter">
					<div class="col-sm-6">
						<button type="button" class="btn actionBtn" data-dismiss="modal">
							<span id="footer_action_button" class="glyphicon"></span>
						</button>
					</div>
					<div class="col-sm-6">
						<button type="button" class="btn cancelBtn" data-dismiss="modal">
							<span class="glyphicon glyphicon-remove"></span>
						</button>
					</div>
				</div>


			</div>
		</div>

	</div>
</div>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>

<script>

	$(document).ready(function(){

		function RefreshTable() {
				$( "#datatable1" ).load( "<?php echo e(route('estadosprograma.index')); ?> #datatable1");
			}



		$(document).on('click', '.edit-modal', function(){
        $('#footer_action_button').text("Actualizar");
        $('#footer_action_button').addClass('glyphicon-check');
        $('#footer_action_button').removeClass('glyphicon-trash');
        $('.actionBtn').addClass('btn-info');
        $('.actionBtn').addClass('btn-block');    
        $('.actionBtn').removeClass('btn-danger');
        $('.actionBtn').addClass('edit');
        $('.cancelBtn').addClass('btn-danger');
        $('.cancelBtn').addClass('btn-block');    
        $('.modal-title').text('Edit');
        $('.deleteContent').hide();
        $('.form-horizontal').show();


        $('#IdEstadoPrograma').val($(this).data('id'));
        $('#Descripcion').val($(this).data('descripcion'));
        $('#myModal').modal('show');

    });


    $('.modalfooter').on('click', '.edit', function(){

        $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
        });

    	$.ajax({

    		type: 'post',
    		url: '/editestadoprograma',
    		data: {
    			
			'id': $("#IdEstadoPrograma").val(),
			'descripcion': $("#Descripcion").val(),
			
    		},
    		success: function(data){
                toastr.success("Informacion Actualizada");
                RefreshTable();
    		}
        
    	});

    });




    // END EDIT 



    // DELETE


    $(document).on('click','.delete-record',function(){
        
        var idestadoprograma = $(this).val();
         
         $.ajaxSetup({
          headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
        });


        $.ajax({
            type: "DELETE",
            url: '/deleteestadoprograma' + '/' + idestadoprograma,
            success: function (data) {
                console.log(data);
                $(".estadoprograma" + idestadoprograma).remove();
            },
            error: function (data) {
                console.log('Error:', data);
            }
        });
    });


    // END DELETE


	});

</script>



<script>
	$(document).ready(function(){
		$('#datatable1').DataTable();
	});
</script>

<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/certificacion/informacionprevia/ver_tablas_estadosprogramas.blade.php ENDPATH**/ ?>