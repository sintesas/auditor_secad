<?php $__env->startSection('title'); ?>
	Informe Plan de Mejora (Hallazgos)
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>

		<?php $__env->startSection('form-tag'); ?>

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-title'); ?>
			
            <?php echo e(Breadcrumbs::render('ver_planmejora')); ?>

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>
        <div class="card-body floating-label">
        <!-- BEGIN BASE-->
        <div id="">

            <!-- BEGIN OFFCANVAS LEFT -->
            <div class="offcanvas">
            </div><!--end .offcanvas-->
            <!-- END OFFCANVAS LEFT -->
        <!-- BEGIN CONTENT-->
            <div id="">
                <section>                   
                    <div class="section-body">
                        <div class="row encabezadoPlanInspeccion">
                                <!-- Logo FARC -->
                                <div class="col-xs-2 logoFac letraGris">
                                    <img src="../img/logoFac.png"/>
                                </div>
                                <!-- titulo Formulario -->
                                <div class="col-xs-6 titulo letraGris">
                                    <ul class="tituloFormularioFuerzaArea none-space">
                                        <li><h4>FUERZA AÉREA COLOMBIANA</h4></li>
                                    </ul>
                                    <ul class="none-space">
                                        <li style="list-style: none;"><h3>FORMATO PLAN DE MEJORAMIENTO</h3></li>
                                    </ul>
                                </div>
                                <!-- Datos del formulario -->
                                <div class="col-xs-4 datosFormulario letraGris">  
                                    <ul class="caracterisicasFormulario none-space">
                                        <li>Código:</li>
                                        <li id="codigoEnc">IS-DIINS-FR-006</li>
                                    </ul>                          
                                    <ul class="caracterisicasFormulario none-space">
                                        <li>Versión N°:</li>
                                        <li id="versionEnc">02</li>
                                    </ul>
                                    <ul class="caracterisicasFormulario none-space">
                                        <li>Vigencia:</li>
                                        <li id="implementacionEnc">31-ENE-2019</li>
                                    </ul>
                                </div>                      
                            </div>
                        </div><!--end .row -->  
                         <?php if(count($informemejora) == 1): ?>
                         <?php $__currentLoopData = $informemejora; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $informemejoraR): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- FECHA -->
                        <div class="row">
                            <!-- Div Fecha -->
                            <div class="col-xs-offset-8 fecha">
                                <div class="col-xs-6 gris" > FECHA</div>
                                <div class="col-xs-6 negro"> </div>   
                            </div>                          
                        </div><!--end .row -->
                    
                    
                        <!-- PRIMER BLOQUE DE INFOMACION -->
                        <div class="row">                            
                            <!-- Proceso -->
                            <div class="col-xs-12 filaFormulario">
                                <div class="col-xs-4 gris" >
                                    <div class="col-xs-12 gris">
                                        PROCESO/UNIDAD:
                                    </div>
                                </div>
                                <div class="col-xs-8">
                                    <div class="col-xs-6 negro"> <?php echo e($informemejoraR->NombreProceso); ?>

                                    </div>
                                    <div class="col-xs-6 negro"> <?php echo e($informemejoraR->Codigo); ?>

                                    </div>
                                </div>   
                            </div>
                            <!-- FIN Div-->
                            <!-- Responsable Proceso -->
                            <div class="col-xs-12 filaFormulario">
                                <div class="col-xs-4 gris" >
                                    <div class="col-xs-12 gris">
                                        RESPONSABLE DEL PROCESO:
                                    </div>
                                </div>
                                <div class="col-xs-8 negro">
                                    <div class="col-xs-12 ">
                                        <?php echo e($informemejoraR->ResponsableProceso); ?>

                                    </div>
                                </div>   
                            </div>
                            <!-- FIN Div-->                          
                        </div><!--end .row -->
                        
                        <!-- SEGUNDO BLOQUE DE INFOMACION -->
                        <div class="row">
                            <!-- Titulo -->
                            <div class="col-xs-12 filaFormulario">
                                <div class="col-xs-12 gris text-center" > TIPO DE ACCIÓN: (Marque con una X el tipo de acción y numerela para establecer un control)  </div>         
                            </div>                            
                            <!-- Primer cuadro de informacion -->
                            <div class="col-xs-12 filaFormulario">
                                    <div class="col-xs-4">
                                        <div class="col-xs-8">
                                            ACCIÓN CORRECTIVA
                                        </div>
                                        <div class="col-xs-4">
                                          <?php if(($informemejoraR->IdTipoAnotacion) == 2): ?>
                                           X                                           
                                           <?php endif; ?>
                                        </div>                  
                                    </div>
                                    
                                    <div class="col-xs-4">
                                        <div class="col-xs-8">
                                            ACCIÓN PREVENTIVA
                                        </div>
                                        <div class="col-xs-4">
                                           <?php if(($informemejoraR->IdTipoAnotacion)== 3): ?>
                                           X
                                           <?php endif; ?>
                                        </div>                  
                                    </div>
                                    
                                    <div class="col-xs-4">
                                        <div class="col-xs-4">
                                            NO:
                                        </div>
                                        <div class="col-xs-8">
                                            
                                        </div>
                                    </div>
                            </div>                            
                        </div><!--end .row -->
                        
                        <!-- TERCER BLOQUE DE INFOMACION -->
                        <div class="row">                                 
                            <!-- Titulo -->
                            <div class="col-xs-12 filaFormulario">
                                <div class="col-xs-12 gris text-center" > FUENTE (Marque con una X el origen de la No Conformidad Real o Poténcial )  </div>         
                            </div>                            
                                
                                <div class="col-xs-12 filaFormulario">
                                    <!-- FILA 1 -->
                                    <ul class="menu-tipoAcc">
                                            <li class="br-solid">
                                                <div class="col-xs-2 br-solid">
                                                    <span></span><br><br>
                                                </div>
                                                <div class="col-xs-10 br-solid">
                                                    <div class="col-xs-4">
                                                        INSPECCIÓN:
                                                    </div>    
                                                    <div class="col-xs-8">
                                                        
                                                    </div>
                                                </div>
                                            </li>
                                            <li class="br-solid">
                                                <div class="col-xs-2 br-solid">
                                                    <br><br>
                                                </div>
                                                <div class="col-xs-8">
                                                    QUEJAS, RECLAMACIONES, SUGERENCIAS
                                                </div>
                                            </li>
                                            
                                            <li class="br-solid">
                                                <div class="col-xs-2 br-solid">
                                                    <br><br>
                                                </div>
                                                <div class="col-xs-8">
                                                    <div class="col-xs-4">
                                                        OTROS:
                                                    </div>    
                                                    <div class="col-xs-8">
                                                        
                                                    </div>
                                                </div>    
                                            </li>
                                    
                                        </ul>                        
                                    <!-- FILA 2 -->
                                    <ul class="menu-tipoAcc">
                                        <li class="br-solid">
                                            <div class="col-xs-2 br-solid">
                                                <br><br>
                                            </div>
                                            <div class="col-xs-8">
                                                REVISIÓN DEL PROCESO
                                            </div>
                                        </li>
                                        
                                        <li class="br-solid">
                                            <div class="col-xs-2 br-solid" >
                                                <br><br>
                                            </div>
                                            <div class="col-xs-8">
                                                ANALISIS DE DATOS INDICADOREES
                                            </div>     
                                        </li>
                                        
                                        <li class="br-solid">             
                                            <div class="col-xs-8">
                                                
                                            </div>                  
                                        </li>                             
                                    </ul>        
                                    <!-- FILA 3 -->
                                    <ul class="menu-tipoAcc">
                                        <li class="br-solid">
                                            <div class="col-xs-2 br-solid">
                                                <br><br>
                                            </div>
                                            <div class="col-xs-8">
                                                REVISION POR LA DIRECCIÓN
                                            </div>                  
                                        </li>
                                        
                                        <li class="br-solid">
                                            <div class="col-xs-2 br-solid">
                                                <br><br>
                                            </div>
                                            <div class="col-xs-8">
                                                PRODUCTOS SERVICIOS NO CONFORME
                                            </div>                  
                                        </li>
                                        
                                        
                                        <li class="">                                            
                                            <div class="col-xs-8">
                                                
                                            </div>                      
                                        </li>
                                    </ul>                                     
                            </div><!--end .row -->
                               
                        </div><!--end .row -->
                        
                        <!--  BLOQUE DE INFOMACION -->
                        <div class="row">                                                       
                            <div class="col-xs-12 filaFormulario table-fixed">
                                <table class="table table-x" id="table1">                 
                                    <tr class="filaFormulario bold">
                                        <th class="borderL borderT borderB gris text-center"> No</th>

                                        <th class="gris text-center borderT borderB"> CODIGO DE HALLAZGO (Aplica solo para Inspecciones) </th>
                                      
                                        <th class="th-x gris text-center borderT borderB" >DESCRICION NO CONFORMIDAD<br> (Se debe anexar el formato de Correcion IC_FR_14) </th>  
                                    </tr>                                  
                                    <tr class="line-b">  
                                        <th><?php echo e($informemejoraR->IdAuditoria); ?></th>
                                        <th><?php echo e($informemejoraR->NoAnota); ?></th>
                                        <th><?php echo e($informemejoraR->DescripcionEvidencia); ?></th>                                        
                                  </tr>
                                </table>
                            </div>
                        </div><!--end .row -->
                        <!--  BLOQUE DE INFOMACION -->
                        <br>
                        <div class="row">                                                       
                            <div class="col-xs-12  table-fixed">
                                <table class="table  table-x" id="table1">
                                  
                                    <tr>
                                        <th colspan="7" class="gris text-center borderL borderT borderB"> ACCIONES A EJECUTAR </th>
                                    </tr>
                                    
                                    <tr>
                                        <th class="th-x  gris text-center borderL borderB"> No</th>
                                      
                                        <th class="th-x gris text-center borderB"> DEFINICION DE CAUSAS <br>(Adjunte formato de Analisis de Causas IC-FR-008) </th>
                                      
                                        <th class="th-x gris text-center borderB" >ACCIÓN / ACTIVIDAD / TAREA </th>
                                      
                                        <th class="th-x gris text-center borderB" >  ENTREGABLE </th>

                                        <th class="th-x gris text-center borderB" > CANTIDAD  ENTREGABLE </th>
                                      
                                        <th class="th-x gris text-center borderB" > FECHA INICIO Y TERMINO </th>
                                      
                                        <th class="th-x gris text-center borderB" > RESPONSABLE <br> (Cargo responsable de Ejecuar la tarea) </th>
                                                                              
                                    </tr>        

                                    <?php $__currentLoopData = $tareas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $tarea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="line-b" >  
                                            <th><?php echo e($key); ?></th>
                                            <th><?php echo e($tarea->CausaRaiz); ?></th>
                                            <th><?php echo e($tarea->AccionTarea); ?></th>
                                            <th><?php echo e($tarea->Entregable); ?></th>
                                            <th><?php echo e($tarea->CantidadEntregable); ?></th>
                                            <th><?php echo e($tarea->FechaInicio); ?> - <?php echo e($tarea->FechaFinal); ?></th>
                                            <th><?php echo e($tarea->Name); ?></th>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        </div><!--end .row -->
                        
                       <!--  BLOQUE FIRMAS -->
                        <div class="row">                         
                                <div class="col-xs-12 firmaFormulario" >
                                    <div class="col-xs-4" >
                                        <h5> Firma </h5>
                                        <div class="col-xs-12 espacioFirma">
                                            
                                        </div>
                                        <div class="col-xs-12 infoFirma">
                                            Grado y Nombre Responsable Proceso:
                                        </div>                                        

                                    </div>
                                    
                                </div>
                        </div><!--end .row -->
                        
                    </div><!--end .section-body -->                   
                </section>
                


                    <a href="<?php echo e(route('informeplanmejora.edit', $idanotacion)); ?>" style="width: 150px; font-style: Roboto;" class="btn btn-primary btn-block editbutton pull-left"><span class="fa fa-download">    Descargar PDF</span></a>


                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <div class="section-body">
                    <div class="text-center">
                        <h3>No hay datos para mostrar informe</h3>
                    </div>
                  </div>
                <?php endif; ?>
            </div><!--end #content-->
            <!-- END CONTENT -->
           
		    </div>
        </div>

		<?php echo Form::close(); ?>

		<?php $__env->stopSection(); ?>

	<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/auditoria/informes/visual_informe_plan_mejora.blade.php ENDPATH**/ ?>