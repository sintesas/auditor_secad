<?php $__env->startSection('title'); ?>
	Tablas Crear Auditoria
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<?php $__env->startSection('card-content'); ?>
		<?php $__env->startSection('card-title'); ?>
			<?php echo e(Breadcrumbs::render('auditoria')); ?>


		<!-- The Modal -->
		<?php if($permiso->crear == 1): ?>
		<button type="button" onclick="window.location='<?php echo e(route("auditoria.create")); ?>'" class="btn btn-info ink-reaction btn-primary addbutton" id="myBtn"><span class="fa fa-plus"></span></button>
		<?php endif; ?>

		<?php $__env->stopSection(); ?>

		<?php $__env->startSection('card-content'); ?>


			<div class="col-lg-12">
			<div class="table-responsive">
				<table id="datatable1" class="table table-striped table-hover">
					<thead>
						<tr>
							<th><b>Codigo</b></th>
							<th><b>Organización que audita</b></th>
							<th><b>Nombre Auditoria</b></th>
							<th style="width: 120px;"><b>Acción</b></th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $audiorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audioria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($permiso->consultar == 1): ?>
						<tr>
							<td><?php echo e($audioria->Codigo); ?></td>
						<?php if($audioria->EmpresaAudita != '' || $audioria->EmpresaAudita != null): ?>
							<td><?php echo e($audioria->EmpresaAudita); ?></td>
						<?php else: ?>
							<td style="color:red">Ninguna</td>
						<?php endif; ?>

							<td><?php echo e($audioria->NombreAuditoria); ?></td>

							<td>
							<?php if($permiso->eliminar == 1): ?>
								<div class="col-sm-6">

									<?php echo Form::open(['route' => ['auditoria.destroy', $audioria->IdAuditoria], 'method' => 'DELETE']); ?>


									<?php echo Form::submit('x', ['class' => 'btn btn-danger deleteButton']); ?>


									<?php echo Form::close(); ?>

								</div>
							<?php endif; ?>
							<?php if($permiso->actualizar == 1): ?>
								<div class="col-sm-6">

									<a href="<?php echo e(route('auditoria.edit', $audioria->IdAuditoria)); ?>" class="btn btn-primary btn-block editbutton" ><div class="gui-icon"><i class="fa fa-pencil"></i></div></a>

								</div>
							<?php endif; ?>
							</td>
							
						</tr>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div><!--end .table-responsive -->
		</div><!--end .col -->
		<?php $__env->stopSection(); ?>

	<?php $__env->stopSection(); ?>
	<?php $__env->startSection('addjs'); ?>

<script src="<?php echo e(URL::asset('js/libs/DataTables/jquery.dataTables.js')); ?>"></script>
<script>
	$(document).ready(function(){
		$('#datatable1').DataTable({
			"order": [[ 1, "asc" ],[ 2, "asc" ]]
		});
	});
</script>

<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('partials.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SINTE\auditor_secad\resources\views/auditoria/ver_auditoria.blade.php ENDPATH**/ ?>